# REVIEW_PACKAGE_MANIFEST_v01_6_7.md — independent-verification package

Additive. `REVIEW_PACKAGE_MANIFEST.md` (v01.4),
`REVIEW_PACKAGE_MANIFEST_v01_5.md` and `REVIEW_PACKAGE_MANIFEST_v12.md`
stay unchanged and hash-pinned. Every claim below is independently
re-runnable. **THIS PROJECT DOES NOT AUTHORIZE LIVE TRADING.**

## New in this delivery

```
cb1ac7fa10b59955a467d140e7c17b9318eea525adb29b42c07cb15f64de1057  mrofyt_swings_v016.py
001d80630f0561749899f2ea46707bc339dd91435e082bad6da963c394d8b9de  mrofyt_engine_v016.py
84a0ca89b93eea041a82da37e5afb87c91072d3c8ed75ff77ced17706126b963  tests_mrofyt_v01_6.py
2b1f9f9159fcda2b76d5f9ac16e53771f473278bf7009b98de51cec37c95e17b  MROF_YT_OF01_6_SUCCESSOR_FREEZE.md
b6bd0b05f48a6e26871df69c97fde97112a19d3f4b17da7edf280caa5bdc354d  mrofyt_exits_v017.py
0df5357cce0d0c77c6f38759c757086a067ea90aef8efc1d373a766bbc8fe7f9  tests_mrofyt_v01_7.py
cbd25e6df806db216cf480a3445f1628fc56dff95ea0d903dc197b91ac7b4791  MROF_YT_OF01_7_EXIT_FREEZE.md
51c2996ffcd15faeca7670864cecb51de26d9741c2903abcd2fe572af43ade80  mrofyt_pilot.py (MROF-YT-PILOT-1.2; supersedes b955ea9d… — an unreadable or empty capture STOPS the pilot before anything is written, so no report and no exposure label from a pass that did not complete; io-error skip reason reported; Amendment 11. Earlier 3bd2b115…: validation blind (BLIND_FROM=20260921, markouts withheld, monotone exposure ledger), seeded bootstrap 95% intervals, skip reasons + book-integrity counters; 1.1 a6504d0f…: event de-duplication and the 300/600/1800 s horizons)
3f118e151d4634a177a148df9f26dc45dc5e94037bbe9f39b0796d205a1d4d9e  tests_mrofyt_pilot.py (45 tests; supersedes d174d26a… — P13 the level snapshot is kept only for non-blind windows; earlier a9bacd64… → P12: a stopped pass leaves the exposure ledger byte-identical)
6af137d68f1feb4f39206056534952712fe9468cc4818f0a409a26cb726692fa  MROF_YT_WAVE2_REGISTRATION.md (DRAFT — pending operator sign-off; supersedes 4e398285… — §11 implementation record and two implementation-precision notes in §4.1/§4.2, no hypothesis parameter changed; earlier: §8.1 interim-monitoring rule; re-hash on sign-off)
ada1320a067c3fad9582f6f216b5ecc4a2d352b69dc5bcdf3f99e4b0ae9cc04a  mrofyt_wave2.py (MROF-YT-WAVE2-1.1; supersedes 24103422… — a run the runner abandons mid-stream is wound back whole in wave two too (fires, counters, per-instrument state incl. the residual history); 53 fires from the two 20260917 runs skipped as corrupt had stayed in the 2026-10-10 report, Amendment 21; earlier MROF-YT-WAVE2-1.0; supersedes 18ba3b83… — an unreadable or empty capture folder STOPS the pass with no report instead of printing zero fires on zero sessions, Amendment 11. The registration as running code: W2-A1, W2-A4r, W2-A4f, W2-A4-OPEN, W2-A4r-z15, W2-A4r-HC, arm B, arm C placebo; subclass of the pilot runner via the runner's observation hooks; wave one untouched; §4.3 CAUSAL_SWING declared not-in-this-version)
2a88d57eedc0ae3219c199cdc38c83509bd640e865fc93ec45bda98d57c352d8  tests_mrofyt_wave2.py (30 tests; supersedes 50158d03… — W9 the abandoned-run wind-back, with a control showing the 1.0 behaviour leaked; earlier 29 tests; supersedes fbeb2623… — W8)
c162abe1587a67a99e64795766cefda28d7198640e0123a6f68ad2de53dc6fa6  MROF_YT_WAVE3_BIGMOVE_REGISTRATION.md (supersedes ea3ec303… — §3 and §10: baseline cells by (instrument, ET hour, direction), a pre-run correction made before any recorded session was read, Amendment 20; earlier FROZEN 2026-10-03 before any run, committed at 85084ff5… and then completed with its §10 implementation record: eight big-move patterns on the frozen grid and approach windows, a 100-tick target with 40/60/80-tick stops and an 1800 s limit, hour-matched baseline, the wave-two placebo arm, 24 tests under Holm, DEV sessions <= 20260918 only; Amendment 18)
ac7b874886f0b672383fea24e32caf154904d0ca08022aefbdda0471e777569c  mrofyt_bigmove.py (supersedes 88499404… — the abandoned-run wind-back also restores wave three's pattern state and counters, Amendment 21; earlier supersedes 1059327c… — direction-matched baseline cells; report_from_runner split out so wave four gets wave three's report from the same read, Amendment 20; earlier MROF-YT-W3-BIGMOVE-1.0: the registration as code on the pilot runner's hooks only; refuses every session after 20260918 unless --unblind, which announces itself and exposes permanently; the path score by a Fenwick first-touch sweep checked against a plain scan; no fill, slippage, commission or order; Amendment 18)
d5dd23f6d1edafeae27b2d437d765a3fe99b1eaa17619d579b851d72822ca2de  tests_mrofyt_bigmove.py (28 tests; supersedes 4f4a173d… — B12 the abandoned-run wind-back; earlier 27 tests; supersedes cf2cef7f… — B5e recomputes the lift from direction-matched cells; earlier 27 tests, B1–B11: the score against a forward scan on 8 904 random-walk checks, hand paths, every pattern condition load-bearing, Holm, the refusal gate, the hour-matched lift recomputed from the report, placebo offsets identical to wave two, the unblind ledger, wave-one ledger identity, frozen-hash pins, the census)
853d80e2a9baaa0b627a2fe0a9f27390d7bbf30945543721b558acd19dc5f9ed  MROF_YT_WAVE4_DISCOVERY_REGISTRATION.md (FROZEN 2026-10-09 before any run, committed at 9d35c018… and then completed with its §10 implementation record and one pre-run correction (direction-matched baseline cells): fourteen causal grid features, 736 rules, 2 208 tests, session-clustered t, Benjamini–Hochberg over all 2 208, both DEV halves, at most five nominated rules frozen with numeric cut-points and judged once on the validation sessions; Amendment 20)
3500fcc3ce7255331602a8d284c813a7d9edd8344d57f3cdc251579c6ddca175  mrofyt_discover.py (supersedes b4a54b4b… — the abandoned-run wind-back restores the wave-four feature history, Amendment 21; earlier MROF-YT-W4-DISCOVER-1.0: the counted search and the checkpoint evaluator on wave three's runner, hooks only; one read of DEV yields wave four's report and wave three's real-level report; --unblind only with --evaluate; no fill, slippage, commission or order; Amendment 20)
5a90b1794603789322fe3ad4525e5564e03166addb91c93c619b67e7c1943709  tests_mrofyt_discover.py (17 tests; supersedes b1eb6395… — F14 the abandoned-run wind-back; earlier 16 tests, F1–F13: Student t, BH and the clustered SE against references, the 736-rule grammar, the anchored cooldown, a planted effect found and pure noise rejected, degenerate tails counted, nominee overlap, frozen cut-points reproduce the search, the unblind refusal, one read for two waves, the features causal under a cut tape, evaluate's two modes and the ledger, wave-one ledger identity and frozen hashes)
6b0eb7ea4a9bc5deb48eec7e461b03c36d509defeb9a28023b104b489f929538  MROF_YT_PILOT_DIAGNOSTIC_FINDINGS.md (supersedes 4624b199… — Amendment 2: the validation blind; Amendment 1 supersedes 8ab588fa…)
aaf1f1f91e33ecd14b81b3b5d58f750acd0800fc57059b1a861b2c950e73edda  mrofyt_recover.py (MROF-YT-RECOVER-1.6; supersedes 962f7319… — a file whose date Windows will not return (error 1392 on a damaged directory entry) is set aside as SKIPPED_UNREADABLE_FILE inside the live-run check instead of stopping the whole dry run before any run is listed, Amendment 17. 1.5 (962f7319…) supersedes 3bed26e0… — a real pass prints each run as it starts, its phases and its outcome, oldest session first; after a failed read or write it asks the drive root and the folder separately and names which stopped answering (DRIVE_GONE, FOLDER_UNREADABLE, WRITE_REFUSED, READ_REFUSED) instead of guessing "disconnected"; a refused write stops the pass after taking back that run's unfinished copies; the folder must take a small check file before anything is read in bulk; an earlier pass's manifest whose files are missing or not the size it records marks the run for redoing; a run the probe found unreadable is not read again; declared fields are borrowed from recorder-written manifests only; Amendment 16. 1.4 (3bed26e0…) supersedes bc2d60d5… — every read is memory-bounded (a zero-filled file with no line break, what a drive drop leaves, no longer pulls its whole size into memory: MAX_LINE_BYTES), and one unreadable file (the first real 1.3 dry run died on OSError 22) is named with its Windows error and set aside as SKIPPED_UNREADABLE_FILE, never repaired, and the pass carries on; 1.3 (bc2d60d5…) supersedes dcd01f4a… — a repair must not fill the drive the recorder writes to: the dry run states what --repair would write against the free space, a pass that would leave under 40 GB free is refused before writing anything, and each run is re-checked; Amendment 14. 1.2 (dcd01f4a…) supersedes 0e73abfb… — asks Windows directly whether the recorder still holds a run (file-sharing check), the only sign that holds over a weekend; anything held or unanswerable is refused; Amendment 11. 1.1 (0e73abfb…): indirect live-run signs; 1.0 (a8b637a5…): manifest reconstruction, instant --dry-run)
1143117b906ace167869d2cf336add6ffb1f21048a9132ec672f6298f422cf2e  tests_mrofyt_recover.py (51 tests; supersedes d65c1740… — V17 a .partial file whose date Windows refuses; earlier d65c1740… supersedes 1a91fed7… — V13–V13b progress lines, oldest-first order, the earlier-pass count; V14–V14d a refused write, an unlistable folder, a vanished drive (each named, the stopped run's copies taken back where the drive answers, the re-run finishing); V15–V15b the check file before any bulk read; V16–V16d the earlier-pass manifest check, recorder-only declarations, no second read of an unreadable file; earlier 1a91fed7… → V11–V12b; earlier 7960bb10… → V11 the unreadable file, V12–V12b bounded reads of zero-filled files (peak memory asserted); earlier 04f7d842… → V10–V10c the free-space guard, each test stating the drive it simulates; earlier ed72a3fd… → V9–V9g: the direct check with an injected answer, the closing-window veto, the recorder-source premise, the atomic manifest write)
f61a1f23fe31a479d04d4fd98cd59c66a9b018e0ef6c5f52459e2bea4094f84c  MROF_ACTUAL_STATE_INVENTORY.md (supersedes 50d0ddc7… — row 7 records the W2-A4f wiring, row 20 the wave-two module)
```

God's Eye View — the read-only dashboard (`analysis/godseye/`, Amendment 12):

```
e79dd336adfea628846db28c3d4019ea0b4f2fad72aa00d6fac5cc1e3da78bf0  ../godseye/godseye_registry.py (MROF-GODSEYE-REGISTRY-1.0; supersedes f7c4d222… — resolve() judges each wave-two family exactly as mrofyt_wave2 does (G11d), and DEMOS: one scripted mechanism scenario per hypothesis with a counter-example, every one run through the frozen detector by G11–G11c; Amendment 13. Earlier: hypotheses, levels, context and the discrepancy record as the frozen code has them; G1b reproduces every frozen detector from its written conditions)
71126ff55621e752576179e7e6f937b0410dc76eedb5bde56a4487507ca82aaf  ../godseye/godseye_policy.py (MROF-GODSEYE-POLICY-1.0: EXPOSED / BLIND / PROTECTED_UNLISTED / UNKNOWN, fail closed; event-level field list; strip-and-scan boundary; outcome lock read only)
bb5ce978700145faebd3d211ebbe4232c55e5081661363eaf9255b9827a3a328  ../godseye/godseye_replay.py (bounded raw reads: byte-offset search, 250,000-row cap that says truncated, book rebuilt with the runner's frozen KLevelBook, depth never invented)
b88ac63e1a71741587956e4f5b21c81145975a3dd78e222cae49c2fa9b4ab040  ../godseye/godseye_export.py (MROF-GODSEYE-EXPORT-1.0; supersedes dc4d9793… — a file found unreadable is remembered in out_dir and not opened again until its size or time changes; earlier 7fb480f5… — a run set aside by recover 1.4 as SKIPPED_UNREADABLE_FILE carries the file name and the Windows error into the health and session sections; earlier 60e463e3… → the replay windows file is split once per pilot run into one piece per (session, instrument) of inspectable sessions, so a routine export reads a small index instead of ~100 MB; a session whose only audit flag is RECONSTRUCTED_RUN_NOT_SELF_VERIFYING counts as complete, labelled; Amendment 14. Earlier 16aa4c57… → progress section (complete-session rule, runbook milestones, checkpoint clock, accrual counts), disk runway, next scheduled market change, resolved conditions for wave-two families; Amendment 13. Earlier: reports + bounded capture tail -> one sanitized snapshot, atomic, refuses to write on any event-level key outside the exposed section, refuses an out_dir inside the capture folder)
8b61f9abbf5b7db3aae302f086038f02d8b57713822d4341a86993a4824ffa9c  ../godseye/godseye_server.py (the evidence endpoint matches the approach id as well as the time (two levels approached at one instant no longer swap evidence); MROF-GODSEYE-SERVER-1.0; supersedes 775e412f… — serves replay windows one (session, instrument) piece at a time, at most four held; re-reads the exposure ledger when it changes; --open opens the browser once listening; --refresh N re-runs the export every N s as a separate below-normal-priority process (the launchers use 300); Amendment 14. Earlier: stdlib HTTP on 127.0.0.1; policy re-checked on every replay request; stale after 15 min; last good snapshot kept)
b0aaf0743b2f87c3661bfeaa9fc02caeb24b6c81da6dafd650e97147f9588de1  ../godseye/godseye_demo.py (MROF-GODSEYE-DEMO-1.0: labelled synthetic capture + reports through library entry points only; its own ledger, inside the demo folder)
3791e3ad53aa37436c9a6e7badc54500c448212bed7ebcccdef69c0e9ac3152d  ../godseye/tests_godseye.py (46 tests, G1–G14c + G8f; supersedes 041eaffd… — G14c no re-read of a known-unreadable file; earlier a264c7de… — G14 the unreadable-file verdict reaches the page, alerted, capture untouched; G14b shared-gap alerts capped; earlier edc2d6bf… → G12e reconstructed-only sessions complete and labelled, G13–G13d the replay split, the server's bounded pieces and ledger re-read, the launcher, the refresher; earlier 3d2d5111… → G11–G11d theatre scripts vs the frozen code, G12–G12d study progress, clock, runway)
23517ae39a7fbb6a7cb4a271c858057e2c02033105fefaa9f9beb870179ee39a  ../godseye/static/app.js (supersedes a19771cc… — alerts name a run the drive cannot read and cap shared-gap warnings at the five largest plus one summary line; the orphan table shows the unreadable file; replay level labels drawn over the candles on a dark box; earlier a19771cc… → the page sends the approach id with every evidence request; earlier 44bfe9ea… → the progress rail names sessions relying on reconstructed manifests; earlier 0fd3a368… → progress rail, schedule-aware alerts, runway, watchdog notifications, funnel bars)
c0d29207c0b283751bd38e5b4c614b3f4e86025c4b0c09ae3e9f40ac8a0a27e3  ../godseye/static/theatre.js (the Mechanism theatre view and keyboard shortcuts; Amendment 13)
b65447cb56b2ef6e8067095adf094413f4ffc5094c450771b530577021fd7c69  ../godseye/static/index.html
c3dd56058931c0f773d15648e5de1ce659c722d390d81a99ff6c87063c3e44a3  ../godseye/static/style.css
ea11ca5285b42825ad3f272b38a3903274849d3713aefa3a1fe5e7a4752c8762  ../godseye/GODS_EYE_README.md (architecture, permission model, setup, the four views, blind enforcement, discrepancy record, adapters, verification, blockers, user guide)
8169159cbf3444a82bc59538d6053fc4c693606c7d4c6f7f73e811f42fb635f6  ../godseye/launch_godseye.bat (supersedes a3cf2105… — the server opens the browser once listening instead of racing it; reviewed, not executed: no Windows here)
6d52566b3cd6dcc310517733fc94b4cdc355beecd10fe3ff7260082040420b36  ../godseye/export_godseye.bat
8799ff3dc698a7f2a186be1dc18c3c35e1697bce554f350b9f77f74ca17fd21e  ../godseye/godseye.config.example.json
ec8366a0e493efe33963a227bda8084e9f5a1e7123de66687b6881387d511c00  ../godseye/pinokio/pinokio.js (optional Pinokio launcher, dashboard only; NOT exercised here — no Pinokio)
31526b3cee7dfe325758e4eb321134897a1f52232cd4094d73581e58df480b3f  ../godseye/pinokio/install.js
e89a18767df0469c2c15262f90937e19a9577f453b9070cfc63064829fa118c1  ../godseye/pinokio/start.js
451a3544e1a854195bdb62b247186cfc15eaf70aedc49a9d0b270f63f537eb83  ../godseye/pinokio/stop.js
8d1b123206885250b9a9b21951b58e37ed318fd0d2f93656c91926135b097e16  ../godseye/pinokio/export.js
```

Modified (one file, additively — a skip path, observation hooks and a
run-id field):

```
280ad72892ec992a36cf6762d45580a3608095bc9914ee6b301452cc540710af  mrofyt_runner.py (MROF-YT-RUNNER-1.2.2; supersedes 86180aec… — reads a capture spanning two folders as one study in session order (a run present in both is read once and named), Amendment 23; earlier MROF-YT-RUNNER-1.2.2; supersedes 228d48c6… — a stat() refused in the size pre-flight is that run's IO_ERROR skip (or a STOP when the folder is gone), not a TypeError: the call lacked its wind-back argument since the 9/19 merge, Amendment 22; earlier MROF-YT-RUNNER-1.2.2; supersedes a382df95… — the quote fields are assigned in their own order (st.ask held the bid size and st.bsz the ask price; nothing read either, so no result changed), Amendment 20; earlier MROF-YT-RUNNER-1.2.2; supersedes a4a518b7… — a folder with manifest files that gives no plan stops with a count and the reasons (unreadable, other instrument, other schema) instead of "wrong folder", Amendment 19; earlier MROF-YT-RUNNER-1.2.2; supersedes 10485b66… — every row-decoding failure is CORRUPT_STREAM, and an abandoned run -- corrupt row or device error -- is wound back whole, Amendment 15; earlier supersedes c48dfe9e… — a capture folder that cannot be read, or stops answering mid-pass, STOPS the pass with no ledger; a read error on one run while the folder answers is that run's IO_ERROR skip; a run carrying both the recorder's manifest and a reconstructed one is ingested once; Amendment 11. Earlier c48dfe9e…: two no-op observation hooks for wave two; 99c9b277…: truncated/corrupt streams skipped whole; earlier: retroactive disconnect-gap correction. See REVIEW_PACKAGE_MANIFEST_v12.md)
eeb866c96f064519c34c35ef68981a2effd7db9cf4406800ae4b92e83fc04bdb  tests_mrofyt_runner.py (39 tests; supersedes 5b81b237… — R19 two folders read as one; earlier 38 tests; supersedes e01bf9b1… — R18–R18b the refused size check; earlier 36 tests; supersedes 0eb00b3b… — R17 the quote fields; earlier 35 tests; supersedes a8737602… — R16–R16b the stated no-plan reason; earlier 33 tests; supersedes 8ea5c6be… — R13f–R13j merged, R15e, R15b/R15c inject at the row-reading boundary; earlier supersedes 51e08e10… — R15–R15d)
f21c6f66a0f07e58b8e71af173e6acd6c43b1ef74e66343314739cc0ace43dff  tests_mrofyt_ingest.py (69 tests; merged from the 9/19 parallel session: adapter parse, merge and pairing paths; G6 ages its partial, Amendment 15)
146802326c487518dafab38dd8395fd51dad2bd674115ccba7b1a460d68706ba  RUNNER_GUIDE.md (merged from the 9/19 parallel session: how to run the outcome-blind ingest runner; brought up to runner 1.2.2 on merge -- IO_ERROR, STOPPED on an unreadable capture, the wider CORRUPT_STREAM catch and the wind-back)
a0db13fcd5b083706fb74d7ead792674949c895accafc7ad3a8a20f1fe5d965d  mles_v12_audit.py (supersedes 1159f125… — one capture may span two folders ("D:\\MLES_Capture;E:\\MLES_Capture"): audited as one, a run present in both audited once and reported, one folder gone is the capture gone, Amendment 23; earlier supersedes 6b522644… — discover_manifests enumerates with os.listdir and raises CaptureUnavailable with the Windows error when the listing fails, never an empty list (glob swallowed a cut-short listing on 2026-10-03 and three tools read it as the wrong folder), Amendment 19; earlier supersedes 003f03b8… — `--out FILE` writes the audit report as JSON for the dashboard, Amendment 12; no rule changed. 003f03b8…: a run still being recorded is OPEN, not failed; damaged originals kept beside recovered copies are KEPT, not failed; unreadable capture stops the audit; per-build disconnect evidence says whether the 1.2.2 repair was exercised or merely not contradicted; Amendment 11. See REVIEW_PACKAGE_MANIFEST_v12.md)
2cbb2a07ea1809f895c8ed96fb942c4bd481bdcbd4f72b299bf6d4a8add920f0  tests_mles_v12.py (56 tests; supersedes c50f7573… — T37 two folders audit as one; earlier 55 tests; supersedes 1c9b8973… — T36 the cut-short listing; earlier 54 tests; supersedes 665b0a06… — T30c, T34–T34c, T35–T35b; T30's orphan fixture is now aged, because a file written a second ago is what a live run looks like)
cdf6d14cfd324225340795932eac96c830e4eb936a3d7dee686141fd9e6fd534  NT8_RECORDING_RUNBOOK.md (supersedes 1c47b9c9… — §8 names the dashboard and the `--out` files it reads; earlier: §8 lists the wave-two command)
```

The pilot line above (51c2996f…) is superseded in Amendment 12 by:

```
b598a10e9b7790c46462f85c8a3f5114c4d913b21100b0e4bc10ed9444204381  mrofyt_pilot.py (MROF-YT-PILOT-1.2; supersedes 2b6efce2… — merged 9/19 work: PilotRunner winds its own observation buffers back with an abandoned run, Amendment 15; earlier supersedes f81c6b14… — a window keeps the level snapshot only when its session is not blind (the validation sessions grow weekly and are never written); Amendment 14. f81c6b14… supersedes 51c2996f… — `--windows-out FILE` writes the decision windows of EXPOSED sessions only (MROF-PILOT-WINDOWS-1) for the dashboard's replay, and each window record carries the approach id, side and the runner's levels; no detector, threshold, level, window, baseline or feature definition touched — P10d re-pins the frozen signal hash; Amendment 12)
eee416353fd6b94f932fee21f5d0368f186e4ede75a1e15bcb8b4fd625113e44  mrofyt_costs.py (MROF-YT-COSTS-1.0: what a mid-to-mid path result keeps after commission, spread and stop slippage, every event and one position at a time, with a spread x slippage sensitivity grid; accounting, never a rule; Amendment 25)
fd1755fb3607509b0d3e06dc8c6d6dc4e3712d7b23c74801567efde10bd6d192  mrofyt_risk.py (MROF-YT-RISK-1.0: drawdowns, losing streaks, bad days and contracts for a risk budget, resampled from the trades one account could take, in three scenarios -- as sampled, half the edge, no edge -- and sized on the half-edge one; a sample with under 20 trading sessions is flagged; Amendment 25)
8799e95096901f05d71b6e3cb86a2c4ad392465419b1e39eb7a7a3baea43b1b8  tests_mrofyt_costs_risk.py (15 tests: the cost and path arithmetic, the daily stop, the scenarios, the seed, streaks beyond the recorded days, sizing, and the frozen DEV report reproduced; Amendment 25)
43513abb03041ca34b426ad82fc434ed49997cef2dfb26b3e2765b1ee8180426  mrofyt_exitstudy.py (MROF-YT-W5-EXIT-1.0: wave five, when a winning run is ending -- eight tape signs against a plain 10-point trail on every 20-point run of the DEV tape, Holm over eight, at most three nominated; and the half-life curves 5 s .. 3 h of every wave-one and wave-three family; DEV only unless --evaluate --unblind; wave four's runner, hooks only; Amendment 25)
755d5e9c574a661cc7da557f24db7810db5c3bcbf5762539e68f1457ae9ea460  tests_mrofyt_exitstudy.py (19 tests: the trail against a re-implementation, the run state, each sign, a planted exit edge found and noise rejected, the cooldown, the unblind refusal, causality under a cut tape, the abandoned-run wind-back, evaluate's two modes and the ledger, the half-life curve by hand, wave-one ledger identity and the frozen hash; Amendment 25)
3bcd8c642dc8cf478d81cdd611bc594245dc489e95d8923696c2c3d1be6299b8  MROF_YT_WAVE5_EXIT_REGISTRATION.md (FROZEN 2026-10-26 before any recorded session was read by it; Amendment 25)
708c38efec9338ac2f8748f8920bcf5153772f63f5e4ac995d2dd0c60009d5df  mrofyt_context.py (supersedes 09bf75a6… — the stamp check ranks only minutes at or above half the peak average volume, so a thin minute with a sharp jump cannot outrank the cash open; BOM-tolerant reading; one parsing loop shared with mrofyt_smt; a Tick export stops with that reason, Amendment 27; earlier MROF-YT-CTX-1.0: long, short or neither by 10:30 ET from NinjaTrader minute exports -- 13 features, 676 rules, month-clustered t, Benjamini-Hochberg; searched on 2019-06-01 .. 2026-06-30, judged on every session before 2019-06-01, which no study in this repository has read; each mode drops the other's bars unread; nothing from 2026-07-01; Amendment 25)
7fbdefccf00b7a618788402aa21cf62c32177fabd7037f943913162f9a7a321a  tests_mrofyt_context.py (21 tests; supersedes fc334024… — X6a the peak filter of the stamp check, Amendment 27; earlier 20 tests: both DST regimes, end-of-bar UTC stamps, contract names, the value area, a day's statistics, the stamp check and its two refusals, the front contract and the same-contract gap across a roll, a planted context edge found and the noise rate bounded over 40 datasets, the split never crossed, the July 2026 refusal, evaluate's two modes, causality; Amendment 25)
55539749c0d916c6035b443c125fb5e41a4e445bc1235f837c3334486372aed5  MROF_YT_CONTEXT_REGISTRATION.md (supersedes 2a62f740… — §1 and §10 state the stamp check's peak filter, a precision of the implementation made before any real bar was read, Amendment 27; FROZEN 2026-10-26; Amendment 25)
9a2aca7a98aa2237dafc1520e51a993bcb48be872ec8954bc32f5d177adefb2e  mrofyt_levelbreak.py (MROF-YT-W6-LEVELBREAK-1.0: wave six part A -- L2 with a fixed, a STRUCTURAL and a FLOW-INVALIDATION stop, L4, and L2 filtered by TRAPPED volume, net of costs, Holm over five; DEV describes, a replay holdout folder (sessions before 2026-09-01 only) or the --unblind checkpoint judges; wave three's runner, hooks only; Amendment 26)
1e2a0b8a6696c4b5be78dd5a16e9ffe61d2022755e1133972e6b45f9f22a4737  tests_mrofyt_levelbreak.py (11 tests: the path exit against wave three's reference scan, the structural stop, the flow invalidation, the trapped-volume hook, end to end with a suite-only plumbing detector, the trapped filter, evaluate's modes, the holdout folder rule, wave three unchanged, the wind-back; Amendment 26)
24ce2cc539a662ce34fdf8ede80e718b2b548144ebf3fe2e3cf0e7ff8ee7c212  mrofyt_smt.py (supersedes d518956b… — reads through mrofyt_context's parsing loop (an aggregator class, no second copy of the loop), Amendment 27; earlier MROF-YT-W6B-SMT-1.0: wave six part B -- NQ failed and held breaks of yesterday's high and low on minute bars, ES confirming or not, four fixed tests, month-clustered, Holm; read on 2019-06 .. 2026-06, judged on the years before 2019-06-01; Amendment 26)
d1d50f8506448287dada036d413f60ab162bf25fe12f2740752d548b2714cd64  tests_mrofyt_smt.py (6 tests: events, ES timing, the outcome, the clustered difference by hand, a planted edge found and the noise rate bounded, the split end to end; Amendment 26)
bfb34438a90a5335df8a2265bced46d51ff40acf8bf560b7f16595249a69993b  MROF_YT_WAVE6_LEVELBREAK_REGISTRATION.md (FROZEN 2026-10-26 before either tool read real data; Amendment 26)
759f808b16eec78bc3edf15fa8cce7f72e3e049c6303762816629089069d5063  mrofyt_flowlevels.py (supersedes d25b41dd… — yesterday's POC / VAH / VAL count in every recording run of the session from the run's first mid (they had never been reachable after the session's first run), and a HELD entry must still be beyond the level at its entry tick; the ledgers through mrofyt_ledgers; Amendment 36; earlier MROF-YT-W7-FLOWLEVELS-1.0: wave seven -- failed and held breaks of the levels the order flow builds every day (one-minute swing highs and lows, absorption prices, yesterday's value area), graded A+ / A / B / skip on five order-flow points, with a structural stop and four exits: the next level ahead, a tape exit with no target, half and half, and the original 25 / 15; nine tests, net R after costs, one position at a time, Holm over nine; DEV describes and freezes two cuts, a replay holdout folder (sessions before 2026-09-01 only) or the --unblind checkpoint judges; wave four's runner, hooks only; Amendment 28)
02e2922721070580af1e51d4ce53ac606c5b19b092c509cf454d11f543eb9e01  tests_mrofyt_flowlevels.py (20 tests: the search tree against a brute-force scan, swing / absorption / value-area levels and merging, FAILED and HELD by hand with their stops and trapped volume, which way a level breaks, fresh and absorption, the grade and confluence, E1's target rule, the bracket, the tape exit sign by sign, E2 / E3 / E4, costs and the hybrid's halves, one position at a time, the grade slope on planted and flat data, end to end, evaluate's modes, the holdout folder rule, wave four unchanged, the wind-back; Amendment 28)
c59c4a02e5d8e1124ab7ae7276ba362f8e4243b963f3f6cc29d4f2da7c99f63f  MROF_YT_WAVE7_FLOWLEVELS_REGISTRATION.md (FROZEN 2026-10-30 before the tool read real data; Amendment 28)
1d60048710432ba4302b6c8c85bf4c333bb1b3b4ad264c72a319ffc9408168e7  mrofyt_l2variants.py (supersedes 7773c52c… — compressed_paths: one set of compressed mid paths per read, shared by every wave that scores it; the wind-back logs only the run's own test-number writes instead of copying the whole dict; the ledgers through mrofyt_ledgers; no result changed; Amendment 36; earlier MROF-YT-W8-L2VARIANTS-1.0: wave eight -- wave six's L2 trades restricted to the first test of the level that session (V1), the 09:30-11:30 ET window (V2), both (V3, the operator's pick), or held at most 5 minutes (V4); every L2 (wave six's T1) beside as the reference; net of costs, session-clustered, Holm over four; nothing frozen from DEV; a replay holdout folder or the --unblind checkpoint judges; wave six's runner, hooks only; Amendment 30)
657cac9741b66a043e79bf91420f82de53f6d4608a9a496113254d104ec59723  tests_mrofyt_l2variants.py (7 tests: the per-level test count, the variant rules and window edges, the 5-minute exit, end to end with wave six's suite-only plumbing detector, the holdout folder rule, wave six unchanged, the wind-back and the registration; Amendment 30)
dd79fdbb059236200a87088d178c606c9b01baa3a83ec20f2d2a88d3fde85ec3  MROF_YT_WAVE8_L2VARIANTS_REGISTRATION.md (FROZEN 2026-10-31 before any held-out session was read; Amendment 30)
202ba97eaa51b597558ded7181d9b46b41df32816dab2686fddef805372a9ed9  mrofyt_l2targets.py (supersedes e05963e7… — the shared compressed paths and ledgers; no result changed; Amendment 36; earlier MROF-YT-W9-L2TARGETS-1.0: wave nine -- wave eight's L2 trades, same 15-point stop and 30 minutes, with three targets on the same trades: FIXED 25 points, NEXT LEVEL (the nearest of the six daily range levels and the session VWAP at least 10 points ahead, 2 ticks short), SCALED (25 points x the recent average daily range over its DEV median, 10-75 points); four paired tests against FIXED on every L2 and on the first test, session-clustered, Holm over four; the uncapped excursion described; DEV describes and freezes the median range, a replay holdout folder or the --unblind checkpoint judges; wave eight's runner, hooks only; Amendment 31)
47c8833f66443b4b398103fe3add634f5376f0e82b2ea3d2440d9302f9ae2911  tests_mrofyt_l2targets.py (10 tests: the two targets and their fallbacks, the uncapped excursion, the recent range, the paired test on planted and null records, end to end with wave six's suite-only plumbing detector, evaluate's modes, the holdout folder rule, wave eight unchanged, the wind-back and the registration; Amendment 31)
e1f651a02feb7fdb80de6ecaed00b55f69f5477911a379ac8bcb395380bde683  MROF_YT_WAVE9_L2TARGETS_REGISTRATION.md (FROZEN 2026-10-31 before any held-out session was read; Amendment 31)
205aaeedb5eca77b530c873546dd48e02675ba403c6ed3f878cf9094065aec61  mrofyt_closereclaim.py (supersedes a73c599d… — the shared compressed paths and ledgers; no result changed; Amendment 36; earlier MROF-YT-W10-CLOSERECLAIM-1.0: wave ten -- break and reclaim on one-minute candle closes at the six daily range levels: a close a tick or more through, a close back within 5 candles, the order flow confirming the reclaim (the candle's net aggression and the last 10 s, z >= 1.0); faded at the reclaim close with wave six's T1 exit; every filtered reclaim and the first test, Holm over two; the unfiltered reclaims and L2 (wave eight V0 / V1) beside from the same read; nothing frozen from DEV; wave nine's runner, hooks only; Amendment 32)
40f149d5d8126c42b1079839912973ffb03686a73cd3af84997352ad367d46b8  tests_mrofyt_closereclaim.py (8 tests: sides and minute closes, the episode by hand (reclaim, held break, the break the other way, numbering), the order-flow filter, clock-minute counting across skipped minutes, end to end, the holdout folder rule, wave nine unchanged, the wind-back and the registration; Amendment 32)
3a79729e9dddee1dd341187c6182fef39c093ba684781a3abfa4834f6f05cd64  MROF_YT_WAVE10_CLOSERECLAIM_REGISTRATION.md (FROZEN 2026-10-31 before any held-out session was read; Amendment 32)
b7d56c9108472df1c1df199a14ee7d923d16e66a89341a48fcc0f65f71659a10  mrofyt_earlylevels.py (supersedes 17b13bc9… — a WICK window that runs out on the far side of the level starts the next break at that tick, as EARLY and CLOSE do; the hourly Eastern offset is public (et_offset_hourly); the shared compressed paths and ledgers; Amendment 36; earlier MROF-YT-W11-EARLYLEVELS-1.0: wave eleven -- an EARLY entry after a one-minute close through a level (the first 10 s tick back through with aggression against the break, z >= 1.0, within 5 candles) on the six daily range levels, E1 / E2 under Holm over two with L2, wave ten and a 10 s WICK analogue beside; and four more level groups judged apart, each with WICK, EARLY and CLOSE entries: A confirmed 1-hour and 4-hour swings (with first tests), B the opens, C VWAP and its bands, D PP / R1 / S1 / M2 / M3, Holm within each group; fixed 25 / 15 tested, wave nine's scaled target beside; nothing frozen from DEV; wave ten's runner, hooks only; Amendment 33)
bf60724e3d51adb5d973915ce8498f079d12448394d7db12bd9403d8a7390a9e  tests_mrofyt_earlylevels.py (10 tests: candle buckets in Eastern time, confirmed swings and their expiry, the swing session limit, the three entries by hand, CLOSE on the MAIN levels equal to wave ten, end to end with the scaled column, unblind, the holdout folder and A_ref refusals, wave ten unchanged, the wind-back and the registration; Amendment 33)
a00d0f9d6accf7fb6d220093a9a824d442c3bd463cba79f9b8959eeed9925063  MROF_YT_WAVE11_EARLY_LEVELS_REGISTRATION.md (FROZEN 2026-11-01 before any held-out session was read; Amendment 33)
ae021dd8fdf07ef955345df002c0c7d1fff580270c9812a1a9cb34204d4ca0b8  mrofyt_l2context.py (supersedes cc648ca1… — the shared compressed paths and ledgers; no result changed; Amendment 36; earlier MROF-YT-W12-L2CONTEXT-1.0: wave twelve -- two day-context filters on L2 fixed in advance and known at each trade, any hour: TREND removes a fade against a strong day trend (price at least 0.25 x the recent average daily range from the session VWAP, the trade against that side), BIG DAY removes trades once the session range so far reaches 1.0 x that range; kept minus removed on every L2 and the first test, session-clustered, Holm over four; an event-calendar split described when given; nothing frozen from DEV; wave eleven's runner, hooks only; Amendment 34)
0aaa060d73a5f96739412ad7b0dd08a52797949e24b8e6020c11dd07d465f079  tests_mrofyt_l2context.py (7 tests: both filters and their boundaries, the kept-minus-removed test on planted, null and thin records, the calendar file, end to end with the calendar split, the holdout folder and calendar refusals, wave eleven unchanged, the wind-back and the registration; Amendment 34)
7c1c23907426610b2e2b9d6315961e6ec988ba82780cda30493272fbd441265a  MROF_YT_WAVE12_L2CONTEXT_REGISTRATION.md (FROZEN 2026-11-01 before any held-out session was read; Amendment 34)
907340ac90c1d3bef162d5149d82da5e5985c9b2965cdbacf13addc35d3ba95a  calendar_2026_events.csv (FOMC, CPI and jobs-report days July-December 2026 for wave twelve's described event split; taken from several published calendars that agree, the official Fed and BLS pages being unreachable from the build environment, so to be checked against them; Amendment 34)
1b547f5622603f4bec4ebb4f43959e9aa6ea081fce58cd738a0fe26e5131e349  mrofyt_valuearea.py (supersedes 771a4458… — yesterday's value area looked up once per run and session instead of on every 10 s tick; the Eastern offset from wave eleven's public helper; the shared compressed paths and ledgers; no result changed; Amendment 36; earlier MROF-YT-W13-VALUEAREA-1.0: wave thirteen -- back into yesterday's value area with speed: the cash-session volume profile from real trades (1-point bins, 70 %), out 2 points beyond VAH or VAL, back in by a tick after a 4-point move in 30 s with aggression into value at z >= 2.0, faded into value 09:30-15:30 ET; VA1 the fixed 25 / 15, VA2 the POC, VA3 the far edge and VA4 wave nine's scaled target each against the fixed 25 on the same trades, Holm over four; nothing frozen from DEV; wave twelve's runner, hooks only; Amendment 35)
5a041781ff76ee7fa3991a8ad68b1b3d57a9fa6e588b1cfeeab45e06d5b25402  tests_mrofyt_valuearea.py (8 tests: the cash profile and value area with the completeness rule, yesterday's value area, the re-entry by hand (fast, slow, weak, late, none), the targets, end to end with suite-only plumbing (completeness, speed and flow relaxed and restored), the holdout folder and A_ref refusals, wave twelve unchanged, the wind-back of the profile and the registration; Amendment 35)
a9ec51fe4a27cf49c78093f84788ef749d96bd1e8c1e89999beceb95812ea0a0  MROF_YT_WAVE13_VALUEAREA_REGISTRATION.md (FROZEN 2026-11-01 before any held-out session was read; Amendment 35)
a9b761f0bee073d9ecf6a1a827a2ed74667922a60ca6414e305b21e00bc881bd  mrofyt_ledgers.py (supersedes b4aa4bc9… — every ledger is written and closed before the call returns, and read back through a closed file: the checkpoint records the exposure ledger once per wave, each call reading the one before, which under a Python without reference counting (PyPy) read an unwritten file and lost the ledger; the bytes written are the same; Amendment 44; earlier supersedes bd8b8e7c… — adds record_history_read for the one-time reads of the minute-export years before 2019-06-01 (MROF_MINUTE_HISTORY_EXPOSURE.json); the two existing functions unchanged; Amendment 39; earlier the replay-holdout and EXPOSED_PILOT_DEV ledgers that waves seven to thirteen write, one copy keyed by the wave's version string; byte-for-byte the records the seven copies wrote; Amendment 36)
6ff7f5f868a703599368f023b31478bd1adba5e5e6c08c53e8f895d7b7d06c55  tests_mrofyt_shared.py (8 tests, SH1–SH8, one per code-review finding: the shared ledgers, yesterday's value levels in a later run, HELD still beyond at its entry, the WICK window that runs out on the far side, one value-area lookup per session, the public Eastern offset across both clock changes, the shared compressed paths, the wind-back log with a reused approach number; SH3 and SH4 fail on the code before the fix; Amendment 36)
18785d76963af6ce89225931def167a4a7dff2a83c08425d4821fe4c8b8c202d  mrofyt_l2firstsignal.py (MROF-YT-W14-L2FIRSTSIGNAL-1.0: wave fourteen -- the primary test on the unseen days: wave six's L2, only the first L2 signal at each level per CME session, any hour, target 25 / stop 15 / 30 min, one position at a time, net of costs; NQ PASS = 30+ trades, the session-clustered 95 % interval of net a trade above 0 and still > 0 without the best day, else NOT PROVEN with the reason; a held-out read under 30 trades shows the count only and withholds every result; MNQ described; wave eight's runner, hooks only; Amendment 37)
ab77fef39512cac5b9673138a46715d49a0359069d5457e75ec3ba2d70830566  tests_mrofyt_l2firstsignal.py (6 tests: the first-signal rule by hand (shared levels, used-up levels, no level, sessions and instruments apart), the verdict by hand (too few, PASS, one big day, a loss, MNQ), the registration's DEV row from the saved DEV report (12 / 7 / +9.44, and 13 by the earlier set-of-levels key), end to end with wave six's suite-only plumbing detector, the withheld held-out report (nothing but the count on screen or in the file) and the shown verdict, wave eight's runner unchanged, the refusals, the exposure ledger and the registration; Amendment 37)
ee8b0729b8f25ff269cb4278d63f08522363135a99f1cc32522aa6c1fc0bb8ce  MROF_YT_WAVE14_L2FIRSTSIGNAL_REGISTRATION.md (FROZEN 2026-11-01 before any validation or replay holdout session was read by any tool; Amendment 37)
fdc359e0cea63fc5c591619b1ac001fcb23f660cb55beb5a7e2f4c9125dae2cf  mrofyt_obviouslevels.py (MROF-YT-W15-OBVIOUSLEVELS-1.0: wave fifteen -- L2's 10-second analogue (wave eleven's WICK entry) at three more obvious level groups, each judged alone: IB the 09:30-10:30 ET high and low (known 10:30-17:00, the window covered or none), ROUND every 100 points, EQUAL two 15-minute swing highs (lows) within 4 ticks; the first signal at each level per session, 25 / 15 / 30 min, one position at a time per group, net of costs; NQ PASS = 30+ trades, Holm over the three, the 95 % interval above 0 and a profit without the best day; a held-out read withholds a group under 30 trades; secondary to wave fourteen on sessions >= 20260921; wave fourteen's runner, no new hooks; Amendment 38)
e37724ce6404e6c72e4f6107270ad7a6aa866afd6c71ea9df9ff55107947768d  tests_mrofyt_obviouslevels.py (7 tests: the IB in summer and winter time with its coverage rule, round numbers per session, equal highs and lows from 15-minute candles (tolerance, merge, the 5-session limit), the WICK entry at these levels only and the first signal, the verdicts with Holm over the three (a group that passes alone fails after Holm), end to end on synthetic tape poking through 15,000, the withheld held-out report, wave fourteen's runner unchanged, the refusals, the ledger and the registration; Amendment 38)
e1b25326b08db205d03c7096099736e221356684ff67b182931fa6e56ee06f5e  MROF_YT_WAVE15_OBVIOUSLEVELS_REGISTRATION.md (FROZEN 2026-11-01 before any validation or replay holdout session was read by any tool and before these levels were computed on any recorded session; Amendment 38)
3cd96ddf4c48e8cdfeab672394865c26dff6ee0f5c86a8296b61d21d169f0efb  MROF_YT_WAVE16_REGISTRATION.md (FROZEN 2026-11-02 before any part was computed on any data: 16A L2's six levels without order flow on NQ minute bars (history, month-clustered, judged once before 2019-06-01) and on the recordings beside wave fourteen; 16B a limit entry 2 / 4 ticks better for 60 s against the market entry; 16C intraday momentum (Gao, Han, Li and Zhou 2018) on NQ minute bars; Amendment 39)
2e3bf5111d2e5be37448be9f5f4d5a4fa22e088a317acdcefb1f5c16d128e01e  mrofyt_minutelevels.py (MROF-YT-W16A-MINUTELEVELS-1.0: a bar 2 ticks through one of the six levels closed back within 5 bars, first per level per session, 25 / 15 / 30 min, one at a time, net of costs; --history reads NQ minute exports with the context study's reader keeping every bar (yesterday's full-session range, last ISO week, the overnight from 09:30), month-clustered, PASS at 100+ trades with the 95 % interval above 0 and a profit without the best month; on recordings, minute bars of the mid beside wave fourteen's first L2 signals, the difference session-clustered, withheld under 30; wave ten's runner, no new hooks; Amendment 39)
d4986ef5b7e7228c028775d69839549e41897ac69c144018779a9e967e59793a  tests_mrofyt_minutelevels.py (7 tests: the minute-bar signal (wick, late close back, held and flipped, a 1-tick poke, first per level), the trade on bars (a bar touching both is a stop, the 30-minute close, a session that ends first), the month-clustered verdict, the history reader across the 2019-06-01 split with its levels checked against the written bars, the history read and its ledger, minute bars of the mid and the recordings comparison end to end with wave ten's runner unchanged, the withheld report and the registration; Amendment 39)
d7e43d4b1c44bcf76b8fb3b2222d8ffa90ffc9aa09005a192955c0363991fa8b  mrofyt_limitentry.py (MROF-YT-W16B-LIMITENTRY-1.0: on wave fourteen's signals, a limit 2 / 4 ticks better than the signal mid for 60 s, filled only when the mid trades a full tick through it, then 25 / 15 / 30 min from the limit price, missed = 0, no spread saving credited; each signal's limit minus market result, session-clustered, Holm over the two, 30+ signals; fill rate and missed winners beside; withheld under 30; wave fourteen's runner; Amendment 39)
573bf262eddbe5ded45f6fc34d899617ef7d59e37a1e44ffd2ae8517a56557de  tests_mrofyt_limitentry.py (4 tests: the fill only through the limit, the bracket from the limit price, unresolved paths; the comparison with Holm on hand-built records (a steady gain passes, missed winners do not); end to end with wave six's suite-only plumbing detector, wave fourteen's runner unchanged; the withheld report, the refusal and the registration; Amendment 39)
2921692eda2053a004de7593d020c385047047049da4e40567675c40feb470ce  mrofyt_intradaymom.py (MROF-YT-W16C-INTRADAYMOM-1.0: the side from yesterday's cash close to the 10:00 price, in at 15:30, out at 16:00, no stop or target, net of 0.50 points; month-clustered, PASS at 250+ days with the 95 % interval above 0 and a profit without the best month; described on 2019-06 .. 2026-06, judged once before 2019-06-01; the context study's reader; Amendment 39)
d1fd66618d7dc5aba9e30240fdbb63a5b5c160fb1f3971cf3043a12166293cd8  tests_mrofyt_intradaymom.py (3 tests: the side, the trade and the costs against hand-set prices, early-close and no-move days, the years never mixing; a planted effect in the judged years passes while the DEV years only describe; the missing-folder stop and the registration; Amendment 39)
4da7a9c6f65e8402e0186cf48fda81eb7a53065fc1bf08a81c6b1f6c548273de  mrofyt_checkpoint.py (MROF-YT-CHECKPOINT-1.3; supersedes 2676f61a… — wave twenty-one joins the one read, which is now made by wave twenty-one's runner (wave twenty's plus hooks); every earlier wave's report still byte-identical to its own command (CP1, CP2); Amendment 47; earlier MROF-YT-CHECKPOINT-1.2; supersedes 676af266… — wave twenty joins the one read, which is now made by wave twenty's runner (wave thirteen's plus hooks); every earlier wave's report still byte-identical to its own command (CP1, CP2); Amendment 46; earlier MROF-YT-CHECKPOINT-1.1; supersedes ca0a03fa… — --nq-only reads NQ's recordings only (the runner's instruments), every test being judged on NQ and each instrument's state kept apart; the report names the instruments read; the report file written and closed at once; Amendment 44; earlier supersedes dae80758… — wave nineteen joins the one read; Amendment 43; earlier supersedes 3c0d3373… — wave eighteen joins the one read when --a-ref is given; Amendment 42; earlier supersedes b11cc1c6… — wave seventeen joins the one read; Amendment 41; earlier MROF-YT-CHECKPOINT-1.0: every registered recordings test in one read -- waves 6, 8-15, 16A and 16B; the recordings are read once by wave thirteen's runner (every wave's hooks) and each wave's own, unchanged report code runs on that read, so every report is the one its own command gives; a headline (wave fourteen), a scorecard of every NQ row and the count of tests; wave seven and the minute-export parts named as not in the read; on --unblind every wave's version is written to the exposure ledger; no registration of its own, no rule added or changed; Amendment 40)
a6f2e87b6a66018cbf11c8ac5ae4c3330755ef904532847f64391957001e75c5  tests_mrofyt_checkpoint.py (supersedes cc11365c… — CP1 and CP2 also compare wave twenty-one; the header names CHECKPOINT-1.3; Amendment 47; earlier supersedes 60534dfd… — CP1 and CP2 also compare wave twenty; the header names CHECKPOINT-1.2; Amendment 46; earlier supersedes cb2c089d… — its header names CHECKPOINT-1.1; no test changed; Amendment 44; earlier supersedes 55ef3651… — CP1 and CP2 also compare wave nineteen; Amendment 43; earlier supersedes 7ec0df2a… — CP1 and CP2 also compare wave eighteen; Amendment 42; earlier supersedes 5cd55ce3… — CP1 and CP2 also compare wave seventeen; Amendment 41; earlier 4 tests: every wave's report from the one read byte-identical to its own command on DEV and on an unblind read, the runner classes and the frozen detector restored; the headline, scorecard, test count and the not-in-this-read list; the refusals and the frozen-file checks; Amendment 40)
b5429658b5b7660faf32b324dfbe7849afefeeb14ee87ca344e6a93e5d86696a  MROF_YT_WAVE17_CONFLUENCE_REGISTRATION.md (FROZEN 2026-11-03 before any validation or replay holdout session was read by any tool and before confluence was computed on any recorded session; Amendment 41)
1a7344acaac7fb1fd332a5a1ed8aa550211b95ac1d7e97588e46a718730a01f7  mrofyt_confluence.py (MROF-YT-W17-CONFLUENCE-1.0: wave eleven's WICK entry at every level of every family (yesterday, overnight, last week, the two opens, VWAP and bands, pivots, 1-hour and 4-hour swings, yesterday's value area, initial balance, round 100s, equal highs and lows); first signal per level per session, signals within 60 s one event; graded by the distinct families within 2 points: A+ 3 or more, A 2, B 1; FIXED 25 / 15 and WIDE 40 / 15, one at a time; C1 confluence minus none, C2 A+ minus A, C3 WIDE minus FIXED, C4 confluence makes money, Holm over four on NQ; the 1 / 2 / 3 contract ladder described, adoptable only after C1 passes; withheld under 30; wave thirteen's runner, hooks unchanged; Amendment 41)
bf663b027226849402ac411b01316fd73ba9af6a16a0943026f6be36ecfc61a0  tests_mrofyt_confluence.py (7 tests: the families, the zone and grade (two families from one price, a pivot inside 2 points, VWAP outside, a level not yet known), one event per zone, the four tests with Holm on hand-built trades, the ladder's totals and drawdown, end to end with wave thirteen's runner unchanged, the withheld report and the registration; Amendment 41)
b1b22c3207292f5dee117de243e1b778c0feb33f0bdeb7c767209c3532159dd7  MROF_YT_WAVE18_SCALEDBRACKET_REGISTRATION.md (FROZEN 2026-11-03 before any validation or replay holdout session was read by any tool; Amendment 42)
4efadd2e711e0790fe4543278a10af27c968910ba4af97c882f036ff4dae31ec  mrofyt_scaledbracket.py (MROF-YT-W18-SCALEDBRACKET-1.0: on wave fourteen's trades, stop 15 x k and target 25 x k with k = wave nine's recent 14-session range over its frozen A_ref, clamped 0.4 .. 3.0, against the fixed 25 / 15 on the same trades; B1 points a contract, B2 net in units of each trade's own stop (equal dollar risk); session-clustered, Holm over two, profitable without the best day; withheld under 30; the headline stays on the fixed bracket; wave nine's runner; Amendment 42)
69120db859ce3b02a333abb1762be0f698ee43ad6a2f301370ea992b68f0e58d  tests_mrofyt_scaledbracket.py (5 tests: the scale and its clamp, both brackets on one hand path (the fixed stopped, the scaled at its target, in points and R), the two tests on hand-built records, end to end with wave nine's runner unchanged, the withheld report, the refusals and the registration; Amendment 42)
0e68c099188dd60012c3399ae61154b46207a78880c2a17ccb94d606db087be6  MROF_YT_WAVE19_L2FIRSTSIDE_REGISTRATION.md (FROZEN 2026-11-05 before any validation or replay holdout session was read by any tool; Amendment 43)
f91da5a303ec706e6a5d7cf929ad1a1946bfcdc3d911bb0eb94c430a605c5275  mrofyt_l2firstside.py (MROF-YT-W19-L2FIRSTSIDE-1.0: wave fourteen's trades taken at the first L2 signal from EACH SIDE of each level per CME session -- the side is the trade's direction, so at most one short and one long per level; any hour, target 25 / stop 15 / 30 min, one position at a time, net of costs; wave fourteen's verdict (30+ trades, session-clustered interval above 0, profitable without the best day), withheld under 30; wave fourteen's per-level trades and the trades only this rule takes beside; a secondary test, wave fourteen stays the headline; wave fourteen's runner, hooks only; Amendment 43)
e22687052a1a635bb61cda19a6271a066015baf04569ccaa431ed53a754d5e70  tests_mrofyt_l2firstside.py (supersedes f1a589e1… — collects garbage after writing the synthetic runs, so the suite also runs under PyPy (mles_v12_synth leaves its manifests to be closed when collected); no test changed; Amendment 44; earlier 4 tests: the per-side rule on hand-built events with wave fourteen's picks among it, the registration's DEV rows reproduced from the saved DEV report (16 trades, 11 won, +13.20; 5 extra at +16.45; 10 at +10.45 without 16 September), end to end with wave fourteen's runner unchanged, the withheld report, the refusal and the registration; Amendment 43)
647f1896c2f25661032cb6efbbe9d761edbd8b83f284cc4fe7f23d83dd8aa2c6  mrofyt_cpcompare.py (supersedes 7025e135… — a wave only one of the two reports holds (a later package adds one) is named in a note and the waves both hold are compared, with the headline; the counts summed over every wave are then left out; Amendment 46; earlier MROF-YT-CPCOMPARE-1.0: compares the NQ results of two checkpoint reports value by value -- every wave's report, the scorecard and the headline -- leaving out everything MNQ's and the bookkeeping that counts both instruments together (the runner's ledger, the session lists, wave eighteen's count of trades without a recent range, the checkpoint version and the instruments read), a last-digit float difference counted as the same value; MATCH exit 0, DIFFERENT exit 1 with each differing value named, a different kind of read or an unreadable file exit 2; reads two report files only; Amendment 44)
005f175ed266484d472eba8fd1cc6ce010b691303fe67f188082a9188ae27a05  tests_mrofyt_nqonly.py (supersedes 29e46f38… — NQ3 also compares a report from before the last wave was added: MATCH on the waves both hold, the missing wave named, a changed number still found; Amendment 46; earlier 5 tests: on a two-instrument synthetic capture with a session MNQ alone recorded, the NQ-only read gives every NQ value of the full read on DEV and on an unblind read (MATCH, the same scorecard, headline and withholding, MNQ not read); the comparison names a changed NQ value, ignores MNQ's and last-digit float noise and refuses a DEV report against an unblind one; the two commands and their exit codes; sixteen exposure records in a row keep every earlier day; runs under CPython and PyPy; Amendment 44)
439b0aa173a761a5a7b1e5e039f0ce1538490a1bd33112c9884394e61cd25d5d  mrofyt_psycheck.py (MROF-YT-PSYCHECK-1.0: the Traders Reality weekly Psy-Hi / Psy-Lo, forex calc (Traders_Reality_Lib calcPsyLevels: time('240', '0000-0800:2', "GMT"), the highest high and lowest low while in it), rebuilt from the NQ trades of each Monday session for three candidate windows -- TR_CLOCK Monday 00:00-08:00 GMT on the chart's candles, TR_4H the CME 4-hour candles opening in it (22:00-06:00 New York), FIRST_8H the project's 18:00-02:00 adaptation -- and compared with the operator's chart numbers (--expect WEEK:HI:LO), naming the window that gives every week exactly; reads trades of DEV or EXPOSED sessions only, a held-out session listed and never opened; flagged trades left out; a window with a late first trade or a 10-minute hole marked INCOMPLETE; no outcome computed, no ledger written; Amendment 45)
2903c4769d0aa127a764ed6d0de13632357de94f983f821357059b77b48af709  tests_mrofyt_psycheck.py (6 tests: the three windows in New York summer and winter time; planted extremes each window alone contains, counted by hand from the trades file; the gate and the untouched ledger; the chart match, a quarter point off and a week not recorded; flagged trades and a 20-minute hole; the command; runs under CPython and PyPy; Amendment 45)
1b5905150a9d4bfa274858bdf13bbfabb6845eae88f075472e32c514dfbc6a81  MROF_YT_WAVE20_PROFILELEVELS_REGISTRATION.md (FROZEN 2026-11-10 before any result from a validation or replay holdout session existed; discloses the two interrupted held-out reads of 7-8 November, which wrote nothing, and the chart seen while matching the Psy levels; Amendment 46)
ba35747273d2594014fe37b583fbb64670ec434c50941bd4f5fb3b5f03d97a84  mrofyt_profilelevels.py (MROF-YT-W20-PROFILELEVELS-1.0: levels of the same kind as yesterday's value area -- ONVA the overnight (18:00-09:29:59 ET) value area known from 09:30, WKVA last ISO week's summed cash profiles (3+ complete sessions), CLOSE yesterday's last cash trade at or after 15:59, MID halfway between the runner's YDAY_HIGH and YDAY_LOW; four tests of the first WICK signal at each level per session (wave fifteen's code, 25 / 15 / 1 800 s, one at a time, Holm over four); two of wave thirteen's back-into-value event against the overnight and weekly value areas (Holm over two); two of an untested POC of the last 5 sessions, 10+ points ahead, as the target of an L2 trade against the fixed 25 on the same trades (every L2, wave fourteen's first signals; Holm over two); wave fourteen's verdict, withheld under 30; secondary tests, wave fourteen stays the headline; wave thirteen's runner plus the overnight profile, the complete cash bins and the 16:00 close, hooks only; Amendment 46)
e0f9107c6db115618351dcb06b3b9583560be3db2eefa879d9a5a30b098e0b81  tests_mrofyt_profilelevels.py (12 tests: the hooks by hand; the weekly value area and yesterday's close; the four groups' levels and the times each is known; wave thirteen's event reproduced tick for tick when handed yesterday's value, and a value area known late; untested POCs at, through and across a gap; the target rule; both versions on one path; the paired verdict and Holm; the runner leaving wave thirteen's fires, grid, value areas, ranges and ledger identical; end to end on two-run synthetic sessions with every target re-derived; the withheld report, the refusal and the registration; an abandoned run unwound; runs under CPython and PyPy; Amendment 46)
91123ee6d0c405a5a871af5f7962c69d6ab733ed4004c1cf472884653048b408  MROF_YT_WAVE21_SESSIONLEVELS_REGISTRATION.md (FROZEN 2026-11-13 before any result from a validation or replay holdout session existed; discloses the two interrupted held-out reads of 7-8 November, which wrote nothing, and the chart and the four Psy prices seen while matching the Psy levels; Amendment 47)
b6b51e63a5ea3cbecad52b2ba7019ea40d663c93b7ada3d9871ee3ecac94d4dd  mrofyt_sessionlevels.py (MROF-YT-W21-SESSIONLEVELS-1.0: three level kinds of the Traders Reality indicator -- PSYC the weekly Psy high and low of Monday 00:00-07:59:59 GMT and PSYH the same from the 4-hour candles, Sunday 22:00 - Monday 05:59:59 ET, both known from the window's end to Friday 17:00 ET (mrofyt_psycheck.py names the chart's one); ASIA the Tokyo session (00:00-05:59:59 GMT) high and low; LONDON the high and low from 08:00 London time to 09:29:59 ET, known from 09:30; ADR the session's lowest mid so far plus wave nine's recent range and its highest so far minus it, read on each grid record as wave eleven reads VWAP; window highs and lows from trades, a window complete with its first and last trade within 120 s of its edges and no gap over 600 s; five tests of the first WICK signal at each level per session (wave fifteen's code, 25 / 15 / 1 800 s, one at a time, Holm over five); wave fourteen's verdict, withheld under 30; secondary tests, wave fourteen stays the headline; wave twenty's runner plus the windows' trade extremes, hooks only; Amendment 47)
4c900aead502564987d962815c67af6ded948ed66199fb5c41f860acdc313a1a  tests_mrofyt_sessionlevels.py (11 tests: the window clocks in summer, in the week London is on GMT before New York, and in winter; the hooks by hand; completeness and the times each level is known; a Psy level traded all week, once a session, and not the week after; the ADR lines on each grid record and the signals at them, equal to a listed level where the line does not move; Holm over the five; the runner leaving wave twenty's fires, grid, profiles, value areas, ranges and ledger identical; end to end on three-run synthetic sessions with every window high and low re-read from the files, both Psy pairs equal to mrofyt_psycheck's and every ADR line re-derived; the withheld report, the refusal and the registration; an abandoned run unwound; runs under CPython and PyPy; Amendment 47)
b6fd5cede4b02adca0e9381f5fc46b68a964160169779a841fe9bb2bb8392bd4  MROF_EXPOSED_PILOT_DEV_DAYS.json (the operator's exposure ledger as the one-read checkpoint of 13-17 November wrote it: 55 sessions, 20260901-20261113, every one EXPOSED_PILOT_DEV for good; replaces the pilot's 5-day copy so that installing a package no longer rolls the ledger back; Amendment 48)
fe5fa0da48f92d2a8f49c47f05479037ca2a12501b3f517fe57118d74522755d  MROF_YT_WAVE22_STRETCHFADE_REGISTRATION.md (FROZEN 2026-11-17 before any minute export was read for this question; shows the cut it comes from and discloses the earlier minute-bar results that lower its prior; Amendment 48)
a7977d4c75a6fe1b392efc643f143350a16378cf693b505dce0ae3e78c42b6fc  mrofyt_stretchfade.py (MROF-YT-W22-STRETCHFADE-1.0: part 16A's one-minute failed break of yesterday's, last week's and the overnight high and low, every signal, split by wave twelve's rule unchanged -- STRETCHED when the close is 0.25 x A or more from the session VWAP and the fade trades back toward it, A the mean range of the last 14 sessions (5 at least), REST otherwise; 25 / 15 / 30 min on the next bars, one at a time within each group, net of costs; ST1 the stretched fade makes money and ST2 it beats the rest, month-clustered, 100+ trades, Holm over two; judged in each era, 2019-06 to 2026-06 without a flag and before 2019-06-01 once with --unblind (recorded in the minute-history ledger); beside: by year, direction and level, the first signal per level, the unsplit result; Amendment 48)
bce75cd7bced9af1bd3c47b8de5125718e0b4eb7f55cca888b6ecded01814993  tests_mrofyt_stretchfade.py (7 tests: the bar VWAP; the split equal to wave twelve's classify; one session by hand; the reader equal to part 16A's on one contract and across a roll, the unsplit trades part 16A's "every" trade for trade, A re-derived; the two verdicts and Holm; end to end on a planted export across 2019-06-01 with every count re-derived from the plan, the older era read only with --unblind and recorded; the command's stops and the registration; runs under CPython and PyPy; Amendment 48)
8e6a60210d84c69fa62cec784ac0fe5ba68b4f231e5267ce2a91f4d42e3a1950  MROF_YT_WAVE23_VWAPVALUE_REGISTRATION.md (FROZEN 2026-11-17 before any minute export was read for these questions; shows the reading of wave four's order-flow anatomy and the checkpoint results the three rules come from; Amendment 49)
5e9687c368d26734d81c9ddabd3118a00a2e594968d88e16bc09d2b5e39f08cb  mrofyt_vwapvalue.py (MROF-YT-W23-VWAPVALUE-1.0: three rules on NQ one-minute bars, with wave twenty-two's reader, VWAP and A -- RUBBER, a close 0.15 x A or more from the session VWAP with the last 30 minutes moving back toward it by 0.08 x A or more, traded toward VWAP, 25 / 15; MOMENTUM, a close 0.03 to 0.13 x A away with the 30 minutes moving further away by 0.03 x A or more, traded with it, 25 / 15; ACCEPT, part 16A's failed break of the overnight POC, VAH or VAL (the bars of 18:00-09:29, volume spread over each bar's range, 70 %) traded with the break, 15 / 25; first per direction (per level for ACCEPT) per session, 30 min, one at a time within each rule, net of costs; each rule month-clustered, 100+ trades, Holm over the three, judged in each era (2019-06 to 2026-06 without a flag, before 2019-06-01 once with --unblind); Amendment 49)
8e5f7f740ad58b1503a2e7f7f06c2b1f13f20e8520135649e349d582eb319bf8  tests_mrofyt_vwapvalue.py (8 tests: the overnight value area; the 30-minute move; the two zones and their edges; the brackets and costs; the accepted break against part 16A's fade; the verdicts and Holm; end to end on a synthetic export across 2019-06-01 with every trade re-derived without the module's helpers, the older era read only with --unblind and recorded, a read repeatable; the command's stops and the registration; runs under CPython and PyPy; Amendment 49)
```

Frozen DEV results (Amendment 24; shipped in the package from V26 because `tests_mrofyt_costs_risk.py` reproduces them):

```
e881a5bf9f9f72c201f7dd941cf9713713d7033c5452e2fba19e7bccbd72881a  MROF_YT_W3_W4_DEV_FREEZE.md (waves three and four on DEV, committed before any validation read: wave four's hypothesis set and wave three's carried pattern)
88a7caf41cd48e4a5440f3d4c8cd3ffb2ee9f61988b07a3f892015bdd1a92dad  frozen_dev_20261024/w4_nominated.json (the file --evaluate reads at the checkpoint; five LEAD rules with their numeric cut-points)
193ff50f5efc3dc96fac9ca15ee4305d9d84fb215d79a9c9e4913d4131e46252  frozen_dev_20261024/w4.json (the operator's wave-four search report)
18a576a8e787dae311ef0737b56d314e8e0ca57b3bdd9eca102bf75fef6859ac  frozen_dev_20261024/w3.json.gz (gzip -9 -n of the wave-three real-level report d37309f7…, 29 MB uncompressed)
```

Frozen DEV cuts of waves six and seven (Amendment 29; in the repository, read by `--evaluate` on held-out sessions):

```
d09cef66ac9d84a2f3df2713973990a19b6bd0ed8cfa8dd5d1426faee71d5689  frozen_dev_20261031/w6_frozen.json (wave six A4 trapped cut: NQ 0.0, MNQ 0.0)
030ee8bb3f7815ec6bd560a551615298060d812abb33101451eb32685cf798d3  frozen_dev_20261031/w7_frozen.json (wave seven trapped medians and |D| 90th percentiles; computed by the code before Amendment 36, whose two wave-seven fixes change the DEV events the trapped medians come from: to be replaced by a repeated DEV run before any held-out read by wave seven, and not to be used by --evaluate until then)
8acd658e36af878de088dae9aed7f78de9d7389e4b2eb35084a850f6703254a2  MROF_YT_W6_W7_DEV_FREEZE.md (the DEV runs of waves five to seven, the sessions read and refused, the frozen files, committed before any held-out read)
```

Archived source directives:

```
55d598a3c2e5453b9c47675f76932455dca8689084fddfd4535e5b4907def942  ../../docs/prompts/MROF_ONE_COMPLETE_CLAUDE_PROMPT_1.md
b2a0122b40e6ef140a1cb6fe7011068bfa3cc52039a75b19da54c9fc1e7ae389  ../../docs/prompts/MROF_GODS_EYE_VIEW_CLAUDE_PROMPT_PINOKIO.md (the dashboard directive, Amendment 12; archived from the upload as it was read — 166 lines — so the hash is of this archived copy)
```

Delivered package (204 files, repo layout preserved so every suite runs
from inside it unchanged):

```
b829733a84b0080aae76769122bd0f33e38a6588016a2f7c05fdc2a883f3e3f8  MROF_V1_Engine_v01_6_7.zip (supersedes deb0de66… — wave twenty-two: the stretched fade on years of NQ minute bars, its registration and 7-test suite, and the exposure ledger as the held-out checkpoint wrote it (55 days); 201 files, Amendment 48; earlier deb0de66… supersedes 58a9476a… — wave twenty-one: the Traders Reality levels (the weekly Psy high and low in two windows, the Tokyo and London highs and lows, the two ADR lines), its registration and 11-test suite, in the one-read checkpoint; 198 files, Amendment 47; earlier 58a9476a… supersedes b1bad147… — wave twenty: levels like the value area (the overnight and weekly value areas, yesterday's close and midpoint, untested POC targets), its registration and 12-test suite, in the one-read checkpoint; 195 files, Amendment 46; earlier b1bad147… supersedes 13a15dcb… — the Traders Reality Psy check against the operator's chart and its 6-test suite; 192 files, Amendment 45; earlier 13a15dcb… supersedes 0af9f5bc… — the checkpoint's --nq-only read, the comparison of two checkpoint reports, the ledgers written and closed at once (PyPy), and their 5-test suite; 190 files, Amendment 44; earlier 0af9f5bc… supersedes a0bb16ee… — wave nineteen: one first L2 signal from each side of a level, a secondary test beside the headline, its registration and 4-test suite, in the one-read checkpoint; 188 files, Amendment 43; earlier a0bb16ee… supersedes 101c43f4… — wave eighteen: the scaled bracket on the headline's trades, its registration and 5-test suite, in the one-read checkpoint; 185 files, Amendment 42; earlier 101c43f4… supersedes 5e2c3c74… — wave seventeen: confluence grades over every level family and the sizing ladder, its registration and 7-test suite, in the one-read checkpoint; 182 files, Amendment 41; earlier 5e2c3c74… supersedes 4684f71b… — the one-read checkpoint of every recordings test and its suite; 179 files, Amendment 40; earlier 4684f71b… supersedes 9f310251… — wave sixteen: L2's levels on years of minute bars and beside the order flow, a limit entry for L2, intraday momentum, their registration and three suites; 177 files, Amendment 39; earlier 9f310251… supersedes 378f7c15… — wave fifteen: the initial balance, round numbers and equal highs and lows, its registration and 7-test suite; 170 files, Amendment 38; earlier 378f7c15… supersedes 8a9eba41… — wave fourteen: the first L2 signal at each level as the primary test of the unseen days, its registration and 6-test suite; 167 files, Amendment 37; earlier 8a9eba41… supersedes 9b3f0f6a… — the eight code-review fixes to waves seven to thirteen, the shared ledgers module and the 8-test regression suite; 164 files, Amendment 36; earlier 9b3f0f6a… supersedes 551aa3bb… — wave thirteen: back into yesterday's value area with speed, its registration and 8-test suite; 162 files, Amendment 35; earlier 551aa3bb… supersedes 04aa05f0… — wave twelve: the two L2 day-context filters, their registration and 7-test suite, and the 2026 event calendar; 159 files, Amendment 34; earlier 04aa05f0… supersedes 5a9c3c57… — wave eleven: the early order-flow entry and four more level groups judged apart, its registration and 10-test suite; 155 files, Amendment 33; earlier 5a9c3c57… supersedes e21f707b… — wave ten: break and reclaim on candle closes at the big levels, filtered by the order flow, its registration and 8-test suite; 152 files, Amendment 32; earlier e21f707b… supersedes f178b353… — wave nine: L2 with a next-big-level or a volatility-scaled target against the fixed 25, its registration and 10-test suite; 149 files, Amendment 31; earlier f178b353… supersedes edf699bc… — wave eight: L2 on the first test, in the morning, both, or held 5 minutes, its registration and 7-test suite, and the frozen DEV cuts of waves six and seven with their freeze note; 146 files, Amendments 29-30; earlier edf699bc… supersedes fd06d259… — wave seven: order-flow levels graded A+ / A / B / skip with four exits, its registration and 20-test suite; 140 files, Amendment 28; earlier fd06d259… supersedes 3e934e75… — the context stamp check's peak filter and the shared parsing loop, after a review of V26–V27; 137 files, Amendment 27; earlier 3e934e75… supersedes c69b017e… — wave six: the level-break stops, L4 and trapped volume on the recordings, ES confirmation on minute bars, their registration and suites; 137 files, Amendment 26; earlier c69b017e… supersedes 98bc03c1… — context, exit, cost and risk tools with their registrations and suites, and the frozen DEV results their suite reproduces; 132 files, Amendment 25; earlier 98bc03c1… supersedes ae0f7cf3… — one study across two drives; 119 files, Amendment 23; earlier ae0f7cf3… supersedes f4529847… — the runner's refused size check skips or stops instead of crashing; 119 files, Amendment 22; earlier f4529847… supersedes 4f35d37c… — waves two to four wind an abandoned run back whole; wave two 1.1; 119 files, Amendment 21; earlier 4f35d37c… supersedes f466ee1b… — wave four: the counted search, its registration and 16-test suite; direction-matched baselines in waves three and four; the runner's quote fields; 119 files, Amendment 20; earlier f466ee1b… supersedes 64002e08… — a cut-short folder listing is a stop with the Windows error, never "no manifest"; the runner's no-plan stop states its reasons; 116 files, Amendment 19; earlier 64002e08… supersedes 5285925c… — wave three: the big-move registration, mrofyt_bigmove.py and its 27-test suite, 116 files, Amendment 18; earlier 5285925c… supersedes 092a62e0… — recover 1.6: a file Windows will not date is set aside instead of stopping the dry run, 113 files, Amendment 17; earlier 092a62e0… supersedes 14adcbf4… — recover 1.5: progress per run, oldest session first, a stop that names the drive, the folder or the refused step, the check file before any bulk read, earlier-pass manifests checked, recorder-only declarations, 113 files, Amendment 16; earlier 14adcbf4… supersedes 9a8bce6c… — the 9/19 parallel-session work merged: runner 1.2.2 decode-failure catch and wind-back, the ingest suite, the run guide, 113 files, Amendment 15; earlier c5f652c5… — a known-unreadable file is not re-read; earlier 416beef6… — unreadable-file verdict on the page, capped shared-gap alerts, legible replay level labels; earlier 694c6367… — replay evidence matches the approach id; earlier 2fa33aed… — recover 1.4 bounded reads; earlier f930879f… — recover 1.4 unreadable-file guard; earlier f930879f… — Amendment 14: replay split, recover 1.3 free-space guard, reconstructed-session completeness, pilot level trim, launcher open/refresh; earlier 4e67cd09… — God's Eye 1.1: the Mechanism theatre, study progress, runway, Amendment 13; earlier 108325dd…: adds analysis/godseye/ (19 files) and the archived dashboard directive, Amendment 12; earlier 15852c89…: recover 1.2 asks Windows, stop-never-report guards, auditor OPEN/KEPT/repair evidence; earlier 5b8e8ceb…: recover 1.1 refuses live runs; earlier ae256920…: wave two as code (mrofyt_wave2.py + suite), runner hooks, 90 files; earlier 3d34a1cb…: instant --dry-run; earlier: adds mrofyt_recover.py; earlier: pilot 1.2 validation blind + bootstrap intervals, auditor churn-after-BOOK_READY rule; earlier: truncated/corrupt-stream guard and the wave-two registration; earlier: pilot 1.1, recorder BOOK_READY repair, depth-completeness guard, retroactive runner correction. This file ships inside the zip it names, so the in-zip copy records the preceding zip hash by construction; hash the delivered artifact against the value here, not against its own embedded copy.)
```

```
cd analysis/mrofyt && for f in tests_*.py; do python3 "$f" | tail -1; done
cd ../godseye && python3 tests_godseye.py | tail -1
# run from inside the unzipped package: 885/885 + 46/46, identical to the repo
```

## Predecessors — reverified unmodified

```
74ff9a99e468e22326dad9e01e4ee4dc7ab90c8da7e330a6b5f9e70e9eecb91b  MROF_YT_OF01_FINAL_SOURCE_PROMPT.md
b753a09cc077267a935df37f9b531f2179d920b8f76dc6ee5788628c264f7194  MROF_YT_OF01_5_SUCCESSOR_FREEZE.md
e3da36cd63a18a22935124e852ce8f8b785e96df136d98944f7e88654b1c6847  mrofyt_engine_v015.py
```

Reverified in-suite by `tests_mrofyt_v01_6.py::B19` and
`tests_mrofyt_v01_7.py::C12`, so a predecessor edit breaks the build.

## Reproduce everything

```
cd analysis/mrofyt
for f in tests_*.py; do python3 "$f" | tail -1; done
```

| suite | result |
| --- | --- |
| `tests_mles_v11.py` | 29/29 |
| `tests_mles_v12.py` | 56/56 |
| `tests_mrofyt.py` | 59/59 |
| `tests_mrofyt_pilot.py` | 45/45 |
| `tests_mrofyt_runner.py` | 39/39 |
| `tests_mrofyt_ingest.py` | 69/69 |
| `tests_mrofyt_v01_1.py` | 56/56 |
| `tests_mrofyt_v01_2.py` | 31/31 |
| `tests_mrofyt_v01_3.py` | 32/32 |
| `tests_mrofyt_v01_4.py` | 25/25 |
| `tests_mrofyt_v01_5.py` | 36/36 |
| `tests_mrofyt_v01_6.py` | 21/21 |
| `tests_mrofyt_v01_7.py` | 15/15 |
| `tests_mrofyt_recover.py` | 51/51 |
| `tests_mrofyt_wave2.py` | 30/30 |
| `tests_mrofyt_bigmove.py` | 28/28 |
| `tests_mrofyt_discover.py` | 17/17 |
| `tests_mrofyt_exitstudy.py` | 19/19 |
| `tests_mrofyt_costs_risk.py` | 15/15 |
| `tests_mrofyt_context.py` | 21/21 |
| `tests_mrofyt_levelbreak.py` | 11/11 |
| `tests_mrofyt_smt.py` | 6/6 |
| `tests_mrofyt_flowlevels.py` | 20/20 |
| `tests_mrofyt_l2variants.py` | 7/7 |
| `tests_mrofyt_l2targets.py` | 10/10 |
| `tests_mrofyt_closereclaim.py` | 8/8 |
| `tests_mrofyt_earlylevels.py` | 10/10 |
| `tests_mrofyt_l2context.py` | 7/7 |
| `tests_mrofyt_valuearea.py` | 8/8 |
| `tests_mrofyt_shared.py` | 8/8 |
| `tests_mrofyt_l2firstsignal.py` | 6/6 |
| `tests_mrofyt_obviouslevels.py` | 7/7 |
| `tests_mrofyt_minutelevels.py` | 7/7 |
| `tests_mrofyt_limitentry.py` | 4/4 |
| `tests_mrofyt_intradaymom.py` | 3/3 |
| `tests_mrofyt_checkpoint.py` | 4/4 |
| `tests_mrofyt_confluence.py` | 7/7 |
| `tests_mrofyt_scaledbracket.py` | 5/5 |
| `tests_mrofyt_l2firstside.py` | 4/4 |
| `tests_mrofyt_nqonly.py` | 5/5 |
| `tests_mrofyt_psycheck.py` | 6/6 |
| `tests_mrofyt_profilelevels.py` | 12/12 |
| `tests_mrofyt_sessionlevels.py` | 11/11 |
| `tests_mrofyt_stretchfade.py` | 7/7 |
| `tests_mrofyt_vwapvalue.py` | 8/8 |
| **wave-one to twenty-three, tools total** | **885/885** |
| `../godseye/tests_godseye.py` | 46/46 |
| **package total** | **931/931** |

## Runnable research commands

```
python3 mles_v12_audit.py  "<capture folder>"                      # integrity
python3 mrofyt_runner.py   "<capture folder>" --out ledger.json     # outcome-blind
python3 mrofyt_pilot.py    "<capture folder>" --out pilot.json      # §8A diagnostic
python3 mrofyt_recover.py  "<capture folder>" --dry-run             # orphaned runs (instant); runs the recorder holds listed apart
python3 mrofyt_recover.py  "<capture folder>" --repair              # rebuild manifests — safe with NinjaTrader running; do it on a weekend anyway (I/O)
python3 mrofyt_wave2.py    "<capture folder>" --both --out wave2.json  # wave two, real + placebo, blind
python3 mrofyt_bigmove.py  "<capture folder>" --both --out w3.json     # wave three big-move search, DEV sessions only, real + placebo
python3 mrofyt_discover.py "<capture folder>" --out w4.json --nominated-out w4_nominated.json --w3-out w3.json  # wave four counted search + wave three real, one read of DEV
python3 mrofyt_exitstudy.py "<capture folder>" --out w5.json --nominated-out w5_nominated.json  # wave five exit study + half-life curves, DEV only
python3 mrofyt_costs.py    w3.json                                   # costs charged to the Holm survivor(s), one position at a time
python3 mrofyt_risk.py     w3.json --daily-stop 40 --account 50000   # drawdowns and sizing in three scenarios
python3 mrofyt_context.py  "<folder of NQ minute exports>" --out ctx.json --nominated-out ctx_nominated.json  # context search, 2019-06 .. 2026-06 only
python3 mrofyt_levelbreak.py "<capture folder>" --out w6.json --frozen-out w6_frozen.json  # wave six A on DEV: describes, freezes the trapped cut
python3 mrofyt_smt.py      "<folder of NQ and ES minute exports>" --out smt_dev.json       # wave six B, 2019-06 .. 2026-06 first look
python3 mrofyt_flowlevels.py "<capture folder>" --out w7.json --frozen-out w7_frozen.json  # wave seven on DEV: describes, freezes the two cuts
python3 mrofyt_l2variants.py "<replay folder>" --holdout --out w8_replay.json  # wave eight on the replay holdout (nothing to freeze first)
python3 mrofyt_l2targets.py "<capture folder>" --out w9.json --frozen-out w9_frozen.json  # wave nine on DEV: describes, freezes the median range
python3 mrofyt_closereclaim.py "<capture folder>" --out w10.json  # wave ten on DEV: describes (nothing to freeze)
python3 mrofyt_earlylevels.py "<capture folder>" --a-ref w9_frozen.json --out w11.json  # wave eleven on DEV: describes
python3 mrofyt_l2context.py "<capture folder>" --out w12.json  # wave twelve on DEV: describes (optional --calendar events.csv)
python3 mrofyt_valuearea.py "<capture folder>" --a-ref w9_frozen.json --out w13.json  # wave thirteen on DEV: describes
python3 mrofyt_l2firstsignal.py "<capture folder>" --out w14.json  # wave fourteen on DEV: describes (expect NQ 12 trades, 7 won, +9.44)
python3 mrofyt_l2firstsignal.py "<capture folder>" --unblind --out w14_eval.json  # THE TEST on sessions >= 20260921; exposes them for good
python3 mrofyt_obviouslevels.py "<capture folder>" --out w15.json  # wave fifteen on DEV: describes, counts each group's trades
python3 mrofyt_obviouslevels.py "<capture folder>" --unblind --out w15_eval.json  # secondary test, sessions >= 20260921
python3 mrofyt_minutelevels.py --history "<NQ minute exports>" --out m16a.json  # 16A on 2019-06 .. 2026-06: describes
python3 mrofyt_minutelevels.py --history "<NQ minute exports>" --unblind --out m16a_val.json  # 16A judged on the years before 2019-06-01, once
python3 mrofyt_minutelevels.py "<capture folder>" --out w16a.json  # 16A on recordings, DEV: does order flow add?
python3 mrofyt_limitentry.py "<capture folder>" --out w16b.json  # 16B on recordings, DEV: limit vs market entry
python3 mrofyt_intradaymom.py "<NQ minute exports>" --out m16c.json  # 16C on 2019-06 .. 2026-06: describes
python3 mrofyt_intradaymom.py "<NQ minute exports>" --unblind --out m16c_val.json  # 16C judged on the years before 2019-06-01, once
python3 mrofyt_checkpoint.py "<capture folder>" --a-ref w9_frozen.json --out cp_dev.json  # every recordings test in one read, DEV
python3 mrofyt_checkpoint.py "<old>;<new>" --unblind --a-ref w9_frozen.json --out cp_eval.json  # THE CHECKPOINT: every recordings test, once
python3 mrofyt_confluence.py "<capture folder>" --out w17.json  # wave seventeen alone, DEV: confluence grades and the ladder
python3 mrofyt_scaledbracket.py "<capture folder>" --a-ref w9_frozen.json --out w18.json  # wave eighteen alone, DEV: the scaled bracket
python3 mrofyt_l2firstside.py "<capture folder>" --out w19.json  # wave nineteen alone, DEV: first signal per side (expect NQ 16 trades, 11 won, +13.20)
python3 mrofyt_checkpoint.py "<capture folder>" --nq-only --a-ref w9_frozen.json --out cp_dev_nq.json  # the DEV checkpoint reading NQ only, about half the work
python3 mrofyt_cpcompare.py cp_dev.json cp_dev_nq.json  # must say MATCH before --nq-only is used on held-out sessions
pypy mrofyt_checkpoint.py ...  # PyPy runs the checkpoint and the comparison unchanged and faster; use it for those two only
python3 mrofyt_psycheck.py "<capture folder>" --expect 20261102:28834.50:28666.25  # which window gives the chart's weekly Psy-Hi / Psy-Lo (DEV or EXPOSED weeks only)
python3 mrofyt_profilelevels.py "<capture folder>" --out w20.json  # wave twenty alone, DEV: the overnight and weekly value areas, yesterday's close and midpoint, untested POC targets
python3 mrofyt_sessionlevels.py "<capture folder>" --out w21.json  # wave twenty-one alone, DEV: the Psy, Tokyo, London and ADR levels
python3 mrofyt_stretchfade.py "<NQ minute exports>" --out w22_new.json  # wave twenty-two on the newer years (2019-06 to 2026-06)
python3 mrofyt_stretchfade.py "<NQ minute exports>" --unblind --out w22_old.json  # the older years (before 2019-06-01), once
python3 mrofyt_vwapvalue.py "<NQ minute exports>" --out w23_new.json  # wave twenty-three on the newer years: RUBBER, MOMENTUM, ACCEPT
python3 mrofyt_vwapvalue.py "<NQ minute exports>" --unblind --out w23_old.json  # the older years, once
```

All of them stream at flat memory. `mrofyt_runner.py --outcomes` and
`mrofyt_exits_v017.research_driver()` both raise `STATE-C LOCKED`.

## Read-only no-order proof

```
grep -nE "SubmitOrder|ChangeOrder|CancelOrder|EnterLong|EnterShort|ExitLong|ExitShort" \
     mrofyt_swings_v016.py mrofyt_engine_v016.py mrofyt_exits_v017.py \
     mrofyt_pilot.py mrofyt_recover.py mrofyt_wave2.py \
     mrofyt_exitstudy.py mrofyt_costs.py mrofyt_risk.py mrofyt_context.py \
     mrofyt_levelbreak.py mrofyt_smt.py mrofyt_flowlevels.py \
     mrofyt_l2variants.py mrofyt_l2targets.py mrofyt_closereclaim.py \
     mrofyt_earlylevels.py mrofyt_l2context.py mrofyt_valuearea.py \
     mrofyt_ledgers.py mrofyt_l2firstsignal.py mrofyt_obviouslevels.py \
     mrofyt_minutelevels.py mrofyt_limitentry.py mrofyt_intradaymom.py \
     mrofyt_checkpoint.py mrofyt_confluence.py mrofyt_scaledbracket.py \
     mrofyt_l2firstside.py mrofyt_cpcompare.py mrofyt_psycheck.py \
     mrofyt_profilelevels.py mrofyt_sessionlevels.py mrofyt_stretchfade.py \
     mrofyt_vwapvalue.py
# -> no matches outside header comments documenting the prohibition
```

Enforced in-suite by `B18` and `C12`, which strip comments before
scanning, and by `W7` for the wave-two module (which additionally
forbids any fill / stop / target / simulate / P&L call).

## NOT performed here

Real NinjaTrader F5 compilation; Market Replay or live smoke testing;
any market-outcome study. This environment has no NT8, Windows or live
feed. **A stub compile is not an API validation.**

Classification: **`IMPLEMENTATION_COMPLETE` / `INSUFFICIENT_DATA` /
`MARKET_RESEARCH_NOT_RUN` / `PROSPECTIVE_VALIDATION_NOT_STARTED`.**

## Amendment: two integrity repairs (2026-09-13)

Recorded in full in `REVIEW_PACKAGE_MANIFEST_v12.md`; summarised here
because both change files this package ships.

```
ce1e475a37bcad14e4e7ea10228feaea9a561c6ea4d0181e54077774fdebc060  ../../src/MlesV12CaptureHost.cs (build 1.2.2)
1f264e3b54646c5d474107ed38c25072bed7fd95865bad2a669c00a8dfdb9a6f  mles_v12_audit.py
3d8812b9d286b754bdd01050f4714c3dea1de13c5d59e27a5274903fc180c405  mles_v12_harness.cs
665b0a06d3079c23fd55691f9e361e64573d62ee434f1d277ac5896b94da56fa  tests_mles_v12.py
```

1. **Recorder: spurious `BOOK_READY` after a disconnect.** The gate
   maxima were not reset when the book was invalidated, so the next
   depth row re-emitted `BOOK_READY` with no resync — and
   `mrofyt_runner.py` re-armed on it. Pinned by `T31`. **Needs a real
   NinjaTrader F5 recompile to take effect.**
2. **Auditor: `MISSING_DEPTH_ACTION` had no minimum-row guard**, so
   near-empty runs (a closed market, a few seconds before shutdown)
   failed a completeness claim they could not support. Pinned by `T32`
   and `T32b`. Analysis-side only, no recompile.

The lifecycle harness gained a depth row inside the disconnect gap —
its absence is precisely why defect 1 survived the suite.

3. **Runner: pre-repair recordings corrected retroactively.** The old
   recordings still carry `DISCONNECTED` on every gap row and no resync
   before the spurious ready; the runner now honours both, counts what it
   ignored, and prints the counts in its summary. Analysis-side only.
   Pinned by `R12`–`R12d`. Nothing captured is missing or altered.

4. **`RecorderBuild` bumped to 1.2.2.** The disconnect repair changes
   which quality events a run emits, so it had to be distinguishable in
   the manifest; it was first committed without the bump. `T33` now binds
   the repair and the build together. A `1.2.1` manifest means "may carry
   spurious post-disconnect `BOOK_READY`, runner correction applies".

   **Installing the recorder is two steps:** copy the `.cs` into
   `Documents/NinjaTrader 8/bin/Custom/Indicators/`, *then* press F5.
   F5 alone recompiles whatever is already there.

## Wave two — registered blind, 2026-09-18

`MROF_YT_WAVE2_REGISTRATION.md` (DRAFT, pending operator sign-off) records
the second-wave hypotheses **before** the data that will judge them
exists. Wave one is untouched and keeps running blind to the December
checkpoint; wave-two code, when written, lives in new modules.

The split that makes it meaningful: sessions `<= 20260918` are exposed
DEV and informed the design; sessions `>= 20260921` are untouched and are
the only data the wave-two verdict may be read from.

Design in one line: six families become **two that can actually fire**
(A1 with replenishment redefined to observe every grid tick, and A4
registered honestly as the degraded version that produced all 65 events),
plus `W2-A4-OPEN` where the mechanism is structurally forced, a placebo
level arm, a candle-only arm, a `CAUSAL_SWING` level comparison, and a
`aggrConf == HIGH` robustness variant that measures the inferred-aggressor
weakness instead of assuming it away. A2, A3 and A5 are dropped with
reasons from the funnel, not from outcomes.

`P10`–`P10e` bind the document to the code it references, so the
registration cannot go stale silently, and `P10d` re-pins the wave-one
detector hash so registering wave two provably changed nothing.

5. **Runner: a truncated or corrupt stream no longer kills the pass.**
   Two files copied while the recorder was writing ended mid-row and
   would have crashed a multi-hour run with no ledger written. The
   runner now checks each file's size against its manifest before
   ingest (skip whole as `STREAM_SIZE_MISMATCH`) and catches in-stream
   corruption as `CORRUPT_STREAM`, resetting run state so nothing
   partial survives. Pinned by `R13`-`R13e`. Never copy the capture
   folder while recording.

6. **Pilot 1.2: the validation blind, and the interval the kill criterion
   needs.** Registering wave two created a hole: the weekly wave-one
   pilot would have read markouts on -- and labelled `EXPOSED_PILOT_DEV`
   -- the very sessions the registration declares untouched, and
   `W2-A4r` is A4 as it ran. The pilot now withholds every markout for
   sessions `>= BLIND_FROM = 20260921` by default (events are counted so
   accrual stays visible), labels them `VALIDATION_BLIND_MARKOUTS_WITHHELD`,
   and unblinds only on an explicit, loud, permanent `--blind-from none`.
   Exposure is monotone: blind may become exposed, never the reverse.
   Also added: a seeded percentile-bootstrap 95% interval on every
   markout population (what §7's "interval includes zero" reads; none
   below five events), and the skip-reason and book-integrity counters
   in the report and summary. Pinned by `P11`-`P11k`; `P11k` binds the
   date and label to the registration text.
7. **Auditor: depth completeness is asserted on churn after `BOOK_READY`.**
   A 228-row restart stub still tripped the first floor because ~60 of
   its rows were the book being built, when only ADDs can occur. Rows
   are now counted after the run's first `BOOK_READY`; a run that never
   reached it built no book and can support no completeness claim.
   Pinned by `T32c`/`T32d`.

8. **`mrofyt_recover.py`: manifest reconstruction for runs killed before
   finalizing.** An ungraceful termination (power loss, forced reboot)
   stops the recorder before its finalizer writes the manifest. The CSVs
   survive, often complete, but the manifest IS the authoritative
   entrypoint for both the auditor and the runner — so the data is
   invisible to every downstream tool. The first fourteen-session
   capture had one such run on **every day of a week**.

   The tool rebuilds a manifest from the rows. Three refusals are built
   in, and they are the point of it:

   * **Originals are never modified.** A damaged stream is rewritten as
     a new `_RECOVERED.csv`; the damaged file stays exactly as it is.
   * **The recorder's self-reported integrity counters are never
     invented.** `gaps`, `duplicates`, `droppedRows` and the rest are
     the recorder's own account of what it saw; nothing in the rows can
     reveal them. Writing `0` would assert "no rows were ever dropped",
     the one claim that cannot be made, so they are **omitted**.
   * **A reconstructed manifest cannot validate its own file.** Its
     hashes, counts and sequence bounds are computed from that file and
     match by construction. The auditor now says so —
     `RECONSTRUCTED_RUN_NOT_SELF_VERIFYING` — instead of either a pile
     of `MISSING_COUNTER` noise or an unearned clean pass.

   A damaged run is truncated to one **common** eventSeq across all four
   streams, constrained only by the damaged ones: rows beyond a cut-off
   stream describe a world it can no longer account for, and merged they
   would advance quotes past the last depth update and freeze the book.
   An undamaged run is not cut at all — its streams legitimately end at
   different sequences. Pinned by `V1`–`V6` (18 tests), including that
   the recovered run becomes ingestible, that originals are unchanged by
   hash, and that a run missing a whole stream is refused rather than
   papered over.

   `--dry-run` probes only each file's header and last 64 KB, never the
   middle, so answering "what is recoverable here?" costs the same on a
   6 GB depth file as on a small one and reports total recoverable GB
   plus a per-stream verdict. The first implementation scanned every row
   even for a dry run, which made that question a 30-minute operation on
   a real capture folder. `V7`-`V7c` pin the cheapness by counting bytes
   actually read.

9. **Wave two as running code (2026-09-21).** `mrofyt_wave2.py`
   (MROF-YT-WAVE2-1.0) implements the registration's families, the
   candle-only arm B and the placebo arm C, with the §4.3 CAUSAL_SWING
   comparison declared `not_in_this_version` rather than half-built.
   The registration's §11 records exactly what each family became and
   where implementation had to be more precise than the prose (arm-B
   decision instant, placebo seed rule, the residual model's minimal
   first-wave form). No hypothesis parameter was changed.

   How wave one stays untouched: the module subclasses the pilot runner
   and reads only two new **no-op** observation hooks on the frozen
   runner (`_on_trade_event`, `_on_depth_event`, carrying the full
   adapter event after the frozen handling has run). `R14b` pins that
   the base runner's ledger is unchanged by their presence; `W5c` pins
   that the wave-one ledger the wave-two runner emits — fires, totals,
   feature counters, sessions, baselines, regimes — is byte-identical to
   the pilot's on the same seven synthetic sessions, and that the
   comparison is not vacuous; `W7b` and `P10d` re-pin the frozen signal
   hash.

   What the suite proves and what it does not: `W1`–`W1f` prove each
   wave-two detector IS the frozen one with a single input swapped or
   one threshold parameterised (2,000 random inputs for `W2-A4r == A4`);
   `W4`–`W4e` drive arm B's register → bar close → fire path directly;
   `W6`–`W6c` prove every placebo level sits ≥ 3 radii from every real
   level and that the placebo run is deterministic. The end-to-end run
   is on **synthetic** 33-minute sessions, so it verifies that bars
   close, registrations resolve, baselines mature and the residual
   model reaches a fit — code behaviour only. Zero fires on synthetic
   tape is expected and is not evidence about anything. The first
   real-data run is user-side, on DEV sessions ≤ 20260918, and reads
   nothing from validation sessions: the blind is the pilot's.

10. **`mrofyt_recover.py` 1.1: a run still being written is not an
    orphan (2026-09-21).** The first `--dry-run` on the real capture
    folder found 16 runs without a manifest, 84 GB — and listed the two
    runs being recorded *at that moment* (today's NQ and MNQ, 8.76 and
    7.79 GB, `.partial`, ending mid-flush) under `WOULD_RECONSTRUCT_
    WITH_REPAIR`. They have no manifest because the recorder writes it
    at close, and they end mid-row because a flush was in progress.
    1.0 could not tell that from a crash. Had `--repair` been run, it
    would have pinned a manifest declaring the session complete at
    whatever byte the scan reached, the recorder's own manifest would
    later have contradicted it, and the runner would have ingested a
    truncated day as if it were whole — on a **validation** session.

    1.1 recognises a live run by either of two independent signs and
    refuses it under every flag, re-checking at write time so a direct
    `reconstruct()` call cannot bypass discovery: a stream written
    within `LIVE_MTIME_S = 600 s` (the recorder flushes every 30 s, so
    a live file is never minutes stale), or a session label that is the
    current CME session or later (a recorder alive but idle over a
    weekend goes mtime-stale while its run is still open). Both err
    toward refusing. Such runs are listed as `SKIPPED_LIVE_RUN`, counted
    apart from orphans, and excluded from the recoverable total. Pinned
    by `V8`–`V8d`; `V8c` proves the refusal is per run, so the dead
    orphan beside a live run is still recovered.

    The other fourteen runs on that folder are genuine: seven complete
    sessions (14th–17th, 3–7 GB each) that need only a manifest, and
    seven cut mid-write by the laptop's shutdowns (4th, 8th, 14th, 15th)
    that need `--repair`. Operator rule added to the tool's usage text:
    **run `--repair` only when the recorder is idle** — it rewrites
    every stream of a damaged run as a new file on the drive the
    recorder is writing to.

11. **Recover 1.2: ask Windows, because the indirect signs do not hold
    (2026-09-22).** The second real dry run showed 1.1's live runs were
    caught by the session-label rule alone: the modified-time rule
    never fired, because Windows does not keep a held file's modified
    time current (the operator had seen this in Explorer a week earlier
    — size growing, date not moving). Reading the recorder source then
    showed the label rule would not have held either on the day
    `--repair` is meant to run: the session roll is driven by market
    events (`Process()` rotates when an event's session differs), so
    the run open over a weekend keeps Friday's label; and the
    recorder's idle-loop housekeeping is unreachable (`WorkerLoop`'s
    `while (queue.Count == 0 && accepting) Monitor.Wait(...)` never
    falls through to the `ev == null` branch), so nothing — no flush,
    no heartbeat — is written while the market is closed. A run
    NinjaTrader still held on a Saturday would have passed every 1.1
    sign as dead, been given a reconstructed manifest, and been
    finalized again by the recorder on Sunday: two manifests, one run,
    that stretch of a **validation** session counted twice. 1.1 was not
    used for a repair; 1.2 replaces it before one.

    1.2 asks directly. The recorder opens every stream
    `FileMode.CreateNew, FileAccess.Write, FileShare.Read` and holds it
    for the life of the run (`V9f` pins this in the source), so a
    read-only `CreateFileW(GENERIC_READ, FILE_SHARE_READ)` fails with
    `ERROR_SHARING_VIOLATION` for exactly as long as the recorder holds
    the file. HELD refuses; any other failure refuses too ("a check
    that could not be asked is never read as not held"); FREE still
    yields to a newest row under ten minutes old by the recorder's own
    row clock (a run being closed has released its files but not yet
    written its manifest). Off Windows only the indirect signs exist,
    and they stay in force there. The Windows call itself cannot be
    exercised in this environment; `V9`–`V9d` pin every decision around
    it with an injected answer, and the operator's own dry run is its
    real test: today's runs must be listed as "NinjaTrader still has
    ... open for writing". The reconstructed manifest is now written
    aside and moved into place (`V9g`), so a drive that drops
    mid-repair leaves a `.tmp` every tool ignores.

    The recorder idle-loop finding is a recorder defect (no flush and
    no heartbeat during quiet periods; exposure is the last unflushed
    buffer per stream, a few KB, when the machine dies during a break).
    It is recorded here, not fixed: a recorder change is an F5 the
    operator schedules deliberately, and nothing about it is urgent.

    **The same day, a loose USB cable failed three passes at once.**
    Runner, pilot and wave two all died on `OSError 22` mid-read — and
    the wave-two pass, finding no manifests on the vanished drive,
    printed a clean, well-formatted report of zero fires on zero
    sessions. Read as a result that is "nothing fires". Now: a capture
    folder that cannot be read, holds no manifest for the instruments,
    or stops answering mid-pass raises `CaptureUnavailable` /
    `NoCaptureData`; runner, pilot, wave two and auditor print `STOPPED`
    with the reason, exit 2, and write **nothing** — the pilot's
    exposure ledger stays byte-identical (`P12`), because a pass that
    did not complete labels no session exposed. A read error on ONE run
    while the folder still answers is that run's `IO_ERROR` skip and the
    pass continues (`R15b`, `T34b`). Pinned by `R15`–`R15d`, `T34`–
    `T34c`, `P12`, `W8`.

    Two more closures in the same batch. The runner ingests a run
    **once** when both the recorder's manifest and a reconstructed one
    exist for it, preferring the recorder's and naming the other in the
    ledger (`R15d`) — the double-count above closed a second way. And
    the auditor reports a run still being recorded as `OPEN`, not as
    eight `ORPHAN_PARTIAL` failures plus an instance shortfall (the
    2026-09-21 audit carried ten such lines), using the recovery tool's
    own liveness rule so the two can never disagree (`T30c`); damaged
    originals kept beside their recovered copies are `KEPT`, not
    orphans, so the post-repair audit reads honestly.

    **Repair evidence, because the operator caught a confounder.** "Six
    spurious `BOOK_READY` on builds 1.2.0/1.2.1, zero on 1.2.2" was
    presented as proof the recorder repair works. It is not: old
    sessions *are* the old-build sessions, so build is confounded with
    the calendar. The repair acts only after a feed disconnect, and the
    auditor now counts that trigger per build and prints a verdict:
    `NOT_EXERCISED` (no repaired-build run has had a disconnect — the
    repair is untested, however clean the runs look),
    `EXERCISED_AND_HELD`, or `FAILED`. Runs whose rows could not be read
    are counted, never assumed clean. `T35b` is the end-to-end case on
    the real recorder code: the mono lifecycle harness's
    disconnect/reconnect run, built from `src/`, reads as exercised and
    held. Whether the operator's 1.2.2 sessions have had a disconnect
    is what the next real audit will say.

    A caveat made explicit while touching the skip paths: `CORRUPT_
    STREAM` and `IO_ERROR` reset the run's book and report the run
    skipped, but windows, fires and baseline observations produced
    *before* the failing row are not rolled back — they came from valid
    rows. `R13c` ("a partly read run leaves nothing behind") passes
    because its fixture cannot produce a window before the bad row, not
    because anything is undone. No real run has taken either path yet:
    the damaged files on the capture are caught by the pre-flight size
    check, before any row is read.

12. **God's Eye View: a read-only dashboard over the project
    (2026-09-22).** `analysis/godseye/` — registry, policy, bounded
    replay reader, exporter, local server, synthetic demo, 28 tests,
    Windows launchers, an optional Pinokio launcher and
    `GODS_EYE_README.md`. Built from a second directive, supplied as an
    upload and archived under `docs/prompts/` (hash below), after the
    operator said "stop" on the previous batch — that batch was committed
    as its own revertible commit (d650dac) before this one began.

    What it is: four views — recording health (LIVE / IDLE / STALE /
    DISCONNECTED / UNAVAILABLE / UNKNOWN, decided by the recovery tool's
    own liveness rule so the two can never disagree; an unreadable folder
    is UNAVAILABLE with its error, never zero; shared NQ+MNQ gaps shown
    beside the pair overlap because a 1.000 overlap cannot see them),
    hypothesis readiness (registry-driven statuses with reasons, counts
    quoted from the released reports, nothing ranked), data quality and
    provenance (DST-aware ET session timeline, UTC in the inspector,
    recorder / reconstructed / orphan / open / failed distinguished, gaps
    shown as gaps), and a replay of exposed sessions (session →
    instrument → approach → 10-s window → the frozen inputs, book rebuilt
    with the runner's own `KLevelBook`, a level never seen is `unknown`).

    How the blind holds, in the backend: the policy classifies every
    session EXPOSED (ledger label), BLIND (≥ 20260921 or the blind
    label), PROTECTED_UNLISTED (before the hold-out but not in the
    ledger) or UNKNOWN (missing/unreadable ledger, mixed or absent
    label), and fails closed; the exporter strips event-level fields from
    every record of a non-exposed session and then scans the whole
    document outside its `exposed` section, refusing to write on any hit;
    the server re-runs the policy on every replay request (403). December
    changes nothing by itself; the outcome-unlock file is only ever
    tested for existence. `G2`, `G2b`, `G3`, `G3b`, `G8`, `G8e`, `G10`.

    What it costs the recorder laptop: a separate process; `scandir`,
    manifests and the last 64 KB of open runs; no row scan on load; the
    demo export read 8.8 MB from 32 files in 0.43 s at 22.75 MB peak
    heap; the server sits at ~45 MB resident; a replay window is one
    bounded seek per stream, capped at 250,000 rows and saying so when
    capped (`G9`). It writes only into its own `out_dir`, refuses an
    `out_dir` inside the capture folder (`G4b`), and the capture folder's
    tree hash is identical after export, demo build and tests (`G3d`).

    Two additive flags on predecessors so nothing is recomputed:
    `mles_v12_audit.py --out` and `mrofyt_pilot.py --windows-out`
    (exposed sessions only). No detector, threshold, level, window,
    baseline or feature definition changed; `P10d` and `W7b` re-pin the
    frozen signal hash, and `G1b` shows the registry's written conditions
    reproduce every frozen detector on 20,000 random inputs.

    Discrepancies found by inspection and recorded, not changed (the
    README's §6 and the registry's `DISCREPANCIES`, pinned by `G1c`): A2
    and A6 are continuations, not fades; A5 resumes with the trend and
    has four of five inputs passed as `None`; A6 (09:30–09:45 ET, six
    open-type levels, continuation) is not W2-A4-OPEN (09:30–10:30 ET,
    three levels, reversal); z-scores need 5 prior sessions per bucket
    while the residual model needs 20 prior observations; the swing
    module exists but is not a level provider and has never run on real
    tape; the Asia labels have no code; the repository ledger exposes
    20260901–20260905 only, so a pre-hold-out date not in the ledger is
    protected here; the fourteen level ids match `ACTIVE_LEVEL_IDS`.

    Not verified here, said plainly: Pinokio (no Pinokio in this
    environment; scripts follow the documented API; `launch_godseye.bat`
    is the fallback), the `.bat` files and the Windows file-sharing
    liveness check (no Windows here — the health card names which rule
    decided liveness), and every number on real data (all verification
    is on the labelled synthetic demo). The browser render was verified
    with headless Chromium 141 on all four views.

13. **God's Eye 1.1: the Mechanism theatre, and where the study stands
    (2026-09-23).** The operator asked for a demonstration of how each
    hypothesis should work. Rather than prose, each of the fifteen
    registry entries now carries a scripted five-beat scenario
    (`godseye_registry.DEMOS`): a synthetic tape in ticks from the level,
    resting size at the level, executions, and the inputs the frozen rule
    reads appearing beat by beat; the condition checklist lights up as
    they arrive and the verdict quotes the direction rule. Each script has
    a counter-example that changes ONE thing and does not fire. None of
    it is data and every page says so. What makes it more than a story:
    `G11` runs the frozen detector itself (`mrofyt_signals.DETECTORS`,
    `mrofyt_wave2.w2_*`) on every script's final beat and asserts it fires
    in the named direction; `G11b` asserts every counter-example does not
    fire in the frozen code and fails exactly one resolved clause; `G11c`
    runs `arm_b1`/`arm_b2` on the candle arms' bars. The registry gained
    `resolve()`, which derives each wave-two family's conditions from its
    base with the registration's one change (input swapped, forced None,
    required, threshold, gate) — `G11d` shows it agrees with `mrofyt_wave2`
    on 6,000 random inputs for all six derived families — so the theatre,
    the inspector and the replay evidence are judged by one evaluator. A
    thought-experiment panel puts each input on a slider and re-evaluates
    the written conditions; it calls no frozen function and touches no
    data.

    On Recording health: a "where the study stands" rail — complete
    sessions (window passed, both instruments ≥ 95%, no shared gap over 5
    min, every manifest run audit-clean; `G12`) against the runbook's 20
    and 60 milestones, the registration's 2026-12-01 checkpoint with
    trading days left (`G12c`), NQ signal-source events per family against
    the 30-event minimum with a linear accrual projection that is a count
    and never a result, families in registry order; disk runway in
    session-days from the median finalized bytes per session-day (`G12d`);
    the next scheduled market change; alerts that call "not recording"
    critical only while the market is scheduled open and say by when
    recording must resume; an opt-in local browser notification when
    recording stops during market hours. Keyboard shortcuts throughout.
    No frozen file changed; the package suites stay 490/490; the dashboard
    suite is 36/36.

14. **Before the first real deployment: four things the real data would
    have hit (2026-09-23).** Found while writing the operator's steps
    against the capture's real numbers, not the demo's.

    *The replay file.* The first real pilot produced 44,628 windows from
    ~10 sessions; the pilot's `--windows-out` file is ~1.5 KB per window,
    so the September DEV sessions make ~100 MB. God's Eye 1.0 parsed the
    whole file on every export (284 MB peak each time, every 5 minutes if
    scheduled) and the server held all of it (183 MB) -- on the laptop
    that is recording. It is now split once per pilot run (or ledger
    change) into one piece per (session, instrument) of inspectable
    sessions, in `out_dir`; a routine export reads the ~1.5 MB index
    (0.06 s, 5.7 MB); the server holds at most four pieces (~30 MB).
    Measured on a synthetic 63,000-window, 100 MB file. `G13`-`G13b`.
    The server also re-reads the exposure ledger when it changes, so a
    weekly pilot run needs no restart (still fail-closed).

    *The repair's size.* `reconstruct()` copies every `.partial` stream
    in full as `_RECOVERED.csv` (the original is never renamed), not only
    damaged ones, and every orphan on the real folder is `.partial`: a
    `--repair` writes up to the orphans' full size (~67 GB at the last
    dry run) onto the drive the recorder resumes writing to on Sunday
    18:00 ET. Nothing checked the space. Recover 1.3 prints what
    `--repair` would write against the free space in every dry run,
    refuses a pass that would leave under 40 GB free (about three
    session-days) before writing anything, and re-checks per run.
    `V10`-`V10c`; the suite now states the drive each test simulates,
    because this sandbox itself has only ~30 GB free.

    *Complete sessions after the repair.* The auditor flags every
    reconstructed run `RECONSTRUCTED_RUN_NOT_SELF_VERIFYING` (correctly:
    such a manifest cannot verify its own file). The progress rail read
    any flag as "not complete", so after the repair the repaired DEV
    sessions would never have counted toward the 20/60 milestones even
    though the runner ingests them. A session whose only flag is that
    one now counts and is labelled "relying on N reconstructed
    manifest(s)"; any other flag still excludes it. `G12e`.

    *Memory the pilot does not need.* The pilot kept each window's level
    snapshot for blind sessions too, though `write_windows` never writes
    them; validation sessions grow every week to December. Now kept only
    for non-blind windows (`P13`); no detector, threshold, level, window
    or feature definition touched.

    Also: the Windows launcher could open the browser before the server
    listened ("site can't be reached"); the server now opens it once
    bound (`--open`, `G13c`). And the snapshot went stale 15 minutes
    after launch unless the operator set up Task Scheduler, which would
    have made the new watchdog report "stale while the market is open"
    all day; the server now re-runs the export every 5 minutes while it
    is open, as a separate below-normal-priority process, one at a time
    (`--refresh 300` in both launchers, `G13d`).

    *Addendum, the same day.* The operator's first real dry run with 1.3
    died with `OSError: [Errno 22] Invalid argument` reading the first
    line of one leftover file, while the recorder was demonstrably fine
    (the live `.partial` files were growing). Python reports many
    Windows disk errors as errno 22; the likely cause is a file cut off
    when the drive dropped on 2026-09-22. Recover 1.4 catches a read
    error on ONE file, names it with its Windows error code, sets that
    run aside as `SKIPPED_UNREADABLE_FILE` (never repaired, nothing
    written for it), and carries on; a vanished drive still stops the
    pass. The dashboard's own tail reader already survived this. `V11`.

    *Second look, the same day.* Reading the same failure again: a file
    cut off when a drive drops is often zero-filled, with no line break
    at all, and every reader here iterated lines -- `readline()` on such
    a file pulls the whole multi-GB file into memory before it can fail
    (on the recording laptop). Now every read is bounded: the header is
    read from the first 1 MB, rows come from a chunked reader that stops
    at any line over 1 MB and names the stretch, and the repair copy
    uses the same reader. `V12` asserts peak memory under 8 MB on a
    40 MB zero-filled file; `V12b` that a repair keeps every good row
    before such a stretch and writes no zero byte.

    *Replay evidence, found in a screenshot.* Two levels approached at
    the same instant share a window end time; the evidence endpoint
    matched on time only and returned the first, so the panel could
    explain a different level than the header named. It now matches the
    approach id too, and the page sends it. `G8f` (the demo has such
    twins).

    *Review pass, the same day.* Three things the dashboard did not yet
    say or show well. (1) The two files the 9/22 drive drop left
    unreadable are a drive fact the operator should see without running
    the recovery tool: the exporter now carries recover 1.4's
    `SKIPPED_UNREADABLE_FILE` verdict, with the file name and the
    Windows error, into the health section and the session timeline;
    the page raises a warn alert for it ("check the drive / cable") and
    the orphan table shows it; nothing touches the file (`G14`, the
    capture folder's tree hash is identical before and after). (2) A
    long history of overnight restarts produced one shared-gap alert
    per session and buried the ones that matter: the five largest are
    listed, then one line for the rest (`G14b`). (3) Replay level labels
    were drawn under the candles and a candle body could swallow them;
    they are now drawn last, on a dark box, still pushed apart when two
    levels sit within a text height of each other. Rendered in headless
    Chromium: no page errors, no console errors.

    *The next morning.* On the recorder laptop Windows kept raising
    "python3.13.exe - Corrupt File: ...5919a82d-R002_depth.csv.partial
    is corrupt and unreadable. Please run the Chkdsk utility": NTFS
    itself flags that file (the 9/22 drive drop), and every read of it
    raises the warning. The dashboard's refresher exports every 5
    minutes and the recovery module's readers touch the file several
    times per export. The exporter now remembers a file that failed to
    read in its own output folder (`godseye_unreadable.json`, keyed by
    size and modification time, which stat() gives without reading)
    and does not open it again until either changes -- e.g. after
    chkdsk; the verdict, the liveness check and the classification are
    the recovery tool's own code, unchanged. `G14c` counts opens: zero
    while remembered, a real read again after the file's time changes,
    and a readable file loses the mark. The recorder is unaffected by
    the warning; the file system on D: needs chkdsk (runbook).

15. **Runner: the truncated-stream guard covers every decode failure,
    and an abandoned run leaves nothing behind.** The 2026-09-19 handler
    caught `MalformedHeaderError` and `UnknownEnumError`, but the
    adapter's numeric and timestamp primitives raise a bare `ValueError`,
    so a same-byte-count row that kept all twenty columns and garbled a
    price, a sequence number or a timestamp still killed the pass. Row
    decoding now raises `CorruptStream` for any of them, and the skip
    names the file and how far the stream got. Separately, a run reported
    `events=0` was still leaving its prefix's windows, wall states,
    latency samples and open approaches in the ledger; the run is now
    wound back to a mark taken before its first event. Pinned by
    `R13f`-`R13j`.

    *Merged 2026-09-24.* The amendment above was written in a parallel
    session on 2026-09-19 and never reached this branch; it is merged
    here together with that session's ingest suite
    (`tests_mrofyt_ingest.py`) and run guide (`RUNNER_GUIDE.md`). Where
    the two lines of work met: this branch's `IO_ERROR` skip (a read
    error on one run while the folder answers) now winds the run back
    to the same mark as `CORRUPT_STREAM`, instead of only resetting the
    book (`R15e`: a late device error leaves no approach or latency
    sample of that run behind); `R15b`/`R15c` inject their device error
    at the runner's new row-reading boundary (`AD.iter_file`), since
    rows no longer pass through `AD.merge_run`; the ingest suite's `G6`
    ages its partial by an hour, because the auditor shares the
    recovery tool's liveness rule and a partial written seconds ago may
    still be recording. Runner version `MROF-YT-RUNNER-1.2.2`: ledgers
    written before this revision may still carry a skipped run's
    prefix.

16. **Recovery: a pass that stops says where and why, and never writes
    after a refusal.** The first real `--repair` on the operator's drive
    (1.4, 2026-09-26) printed nothing while it ran -- its summary comes
    at the end -- then stopped when Windows refused to create
    `...d5223c43-R001_depth_RECOVERED.csv` (errno 22) and the capture
    folder stopped listing. The only record of how far it got was the
    manifests on the drive, and its message ("the drive was disconnected
    or lost power") was a guess: Python reports several Windows disk
    errors as errno 22, including a damaged folder index on a drive that
    is still attached, and chkdsk had already found two damaged entries
    in that folder. `MROF-YT-RECOVER-1.5`:

    * a real pass prints each run as it starts (`[i/n]` session,
      contract, run, size), each phase (reading every row, writing the
      copies, checking what was written, fingerprinting and the
      manifest) and each outcome with its time (`V13`);
    * runs are taken oldest session first, then by name, so the
      development days the study needs next come before the sealed
      hold-out days; on the operator's folder that puts NQ 9/08
      (`b96e5fe5`) before the 13.9 GB 9/25 run (`V13`);
    * after a failed read or write the drive root and the folder are
      listed separately, at once, and the stop names which stopped
      answering: `DRIVE_GONE` (the root), `FOLDER_UNREADABLE` (the root
      answers, the folder does not), `WRITE_REFUSED` / `READ_REFUSED`
      (both answer) -- with each one's own Windows error and a next step
      that differs: reconnect and re-run, or do not write to the drive
      again until it has been checked (`V14`, `V14c`, `V14d`);
    * a refused write ends the pass. Where the drive still answers, the
      copies that run had started are removed, so the folder never holds
      a `_RECOVERED.csv` no manifest references (the auditor would call
      it `ORPHAN_FINALIZED_CSV`); from a vanished drive nothing can be
      removed and the next pass overwrites it. `FAILED_REPAIR` takes its
      copies back out the same way (`V14b`, `V14d`);
    * before anything is read in bulk, the folder must take a small
      check file (created, synced, read back, removed); a folder that
      refuses stops the pass with nothing read or written. The recorder
      needs the same thing each time it opens a run (`V15`, `V15b`);
    * a manifest an earlier pass wrote is checked, not trusted: one
      that does not parse, or whose files are missing or not the byte
      count it records (acknowledged writes a dropping drive lost), marks
      the run for redoing, with the reason; the dry run counts the runs
      whose manifests check out (`V13b`, `V16`, `V16b`);
    * a run the probe already found unreadable is not read a second
      time in the real pass -- every read of such a file can raise a
      Windows "Corrupt File" warning (`V16c`);
    * declared fields (declaredDepth, build, aggressor source) are
      borrowed only from a manifest the recorder wrote. A reconstructed
      one holds them second-hand or inferred, and a redone run would
      otherwise borrow from its own stale manifest; with no recorder
      sibling the value is inferred and labelled so (`V16d`). Nothing
      downstream reads the label; the auditor's minimum-row rule uses
      the same number either way.

    No original is ever opened for writing; the no-order proof, the
    outcome lock, the frozen detectors and every threshold are untouched.
    Runs rebuilt by 1.4 stay rebuilt: their manifests are re-checked,
    not rewritten. Battery: 584/584 + 46/46.

17. **Recovery 1.6: a file Windows will not even date is set aside, not
    a stop (2026-10-02).** The first 1.5 dry run of the weekend, with
    NinjaTrader closed, stopped before listing a single run:
    `READ_REFUSED` on `MLES12_MNQ_MNQ_DEC26_20261001_20260929211720256-
    7a01b30b-R003_depth.csv.partial`, Windows error 1392 ("The file or
    directory is corrupted and unreadable"), in the live-run check.
    Windows had answered that no process held the file, the tail read
    had failed quietly (`newest_recv` returns None on any read error),
    and then `os.path.getmtime` itself raised: the file's directory
    entry is damaged, not just its bytes. 1.4 set aside files whose
    bytes cannot be read, but only in the probe, which runs after the
    live check. 1.6:

    * in the live check, a stream whose modification time cannot be
      read marks its run `unreadable` with the file name and the Windows
      error, and the run is not live (Windows already said it is not
      held); `probe_run` returns it as `SKIPPED_UNREADABLE_FILE` before
      anything else is read, and the real pass never opens it (`V17`);
    * a live run's byte total no longer stats a file that cannot be
      dated.

    The auditor and the dashboard call the same check, so both now list
    the run (the auditor as `ORPHAN_PARTIAL`, the dashboard with the
    unreadable file) instead of stopping. The runner and the pilot read
    manifests only and never reached this file. No original is opened
    for writing; no detector, threshold, window, level, baseline or
    feature definition is touched. This is the second file-system error
    on this drive (the first two files on 2026-09-22), now on a run from
    the week of 2026-09-28, which is the case for copying the capture
    off the drive before any further long pass. Battery: 585/585 + 46/46.

18. **Wave three: a registered search for order-flow events that precede
    25-point moves (2026-10-03).** The operator, reading the pilot's
    A4 markouts (a +2-point typical move with a −3-point average, no
    interval excluding zero), asked for recurring order-flow events
    that produce 25+ point moves, "built the right way". The right way
    is the one this package already uses: write down what will be
    looked for, how it is scored and how many things are tried, before
    looking. `MROF_YT_WAVE3_BIGMOVE_REGISTRATION.md` was committed
    (85084ff5…) before `mrofyt_bigmove.py` existed, and the tool has not
    been run on a recorded session here (none exists in this
    environment).

    * eight patterns on the frozen runner's own grid ticks and approach
      windows, with the frozen fields unchanged: flow shock with and
      against the response, a two-tick control run, a held open break,
      a sweep-and-reclaim of a range level, a VWAP band snapback, a
      failed retest of a held break, and a 10:30 ET trend read;
    * one path score, fixed: target 100 ticks, stops 40/60/80 ticks,
      1800 s limit, a tie is a stop, mid-to-mid inside one recording
      run, no fill, spread, slippage or commission. This is the first
      wave in the package that reads a path outcome; it does so on DEV
      sessions (`<= 20260918`) only, in its own module, and feeds
      nothing back into a wave-one or wave-two threshold. The wave-one
      ledger it emits is byte-identical to the pilot's (`B9`) and the
      frozen signal module keeps its pinned hash (`B10`);
    * an hour-matched baseline (every grid tick, both directions, cells
      by instrument and ET hour), because the patterns cluster in cash
      hours where 25-point moves are routine; the lift is observed minus
      the events' own cells, with a seeded bootstrap interval and p;
    * the wave-two placebo arm for the level patterns, same seed rule
      (`B6`);
    * 24 tests under Holm, fixed in the registration; fewer than 30
      resolved NQ events is NOT TESTED;
    * the gate: every session after 20260918 is refused and listed;
      `--unblind` is the checkpoint read, announces itself, and writes
      every session read to the exposure ledger as exposed by this
      wave, monotone (`B5`, `B7`, `B7b`);
    * a census of grid-feature deciles against the share of ticks that
      reach ±100 ticks inside 1800 s, labelled diagnostic, producing no
      verdict; a rule read off it is a wave-four registration.

    Battery: 612/612 + 46/46.

19. **A folder listing Windows cannot finish is a stop, never "no
    manifest" (2026-10-03).** With 71 manifests visible to `dir`, the
    wave-two pass stopped twice with "no MLES-CAPTURE-1.2 manifest ...
    the wrong folder, or a drive that came back under another letter".
    `glob.glob` swallows an OSError raised partway through a directory
    scan and returns what it had; on a drive whose folder index carries
    two damaged entries (error 1392, Amendment 17) that is nothing, and
    nothing reads exactly like the wrong folder. `discover_manifests`
    now enumerates with `os.listdir`, which raises, and turns the error
    into `CaptureUnavailable` naming the Windows code (`T36`); every
    tool that discovers manifests (audit, runner, pilot, waves two and
    three, the dashboard's exporter through the runner) inherits it.
    The runner's "no plan" stop now counts the manifest files it saw
    and says why none gave a plan (`R16`, `R16b`). No rule, threshold
    or detector changed. Battery: 615/615 + 46/46.

20. **Wave four: a counted search of the DEV tape for what precedes
    25-point moves, and two corrections found by building it
    (2026-10-09).** The operator asked again for the search they had
    proposed on 2026-10-03 — look in the recorded order flow for
    something recurring with positive expectancy, and make that the
    hypothesis — which had been agreed and then not built.
    `MROF_YT_WAVE4_DISCOVERY_REGISTRATION.md` was committed (9d35c018…)
    before `mrofyt_discover.py` existed: fourteen causal features on the
    frozen 10 s grid, a fixed grammar of 736 rules (singles at decile
    tails, pairs at quintile tails, direction part of the rule), each
    scored at wave three's three stops — 2 208 tests, a number fixed
    before the data is seen — with session-clustered t-tests,
    Benjamini–Hochberg over all 2 208, replication in both
    chronological halves of DEV, and at most five nominated rules
    frozen with numeric cut-points and judged once on the validation
    sessions (`--evaluate --unblind`, Holm over the set). One read of
    DEV yields this report and wave three's (`F10`). It has not been
    run on a recorded session here (none exists in this environment).

    * **Direction-matched baseline (pre-run correction, waves three
      and four).** The planted-effect test — a long-only edge on one
      feature, noise elsewhere — showed that a baseline cell pooling
      both directions gives every long rule a positive lift whatever
      its feature: 27 unrelated rules passed. On real tape the same
      happens whenever the sample drifted one way. Cells are now
      (instrument, ET hour, direction) in both waves; the unrelated
      candidates fall to 2, inside a 10 % false-discovery rate, and pure
      noise yields none (`F6`, `F6b`, `B5e`). Both registrations record
      the correction; neither tool had read a recorded session.
    * **The runner's quote fields.** `st.bid, st.ask, st.bsz, st.asz =
      b, bs, a, asz` put the bid SIZE in `st.ask` and the ask PRICE in
      `st.bsz`. Nothing read either field — order-flow imbalance and the
      mid use their own correctly labelled values — so no result of any
      wave changed (the wave-one ledger is byte-identical, `B9`, `F13`).
      Wave four's spread feature read them and printed spreads of
      −60 000 ticks on synthetic tape. Assigned in order now (`R17`);
      the spread reads the quote order-flow imbalance is built from.

    Battery: 632/632 + 46/46.

21. **An abandoned run is wound back whole in waves two, three and
    four (2026-10-10).** The first real wave-two report (2026-10-10,
    27 sessions) showed W2-A4r with 1 736 raw fires against the pilot's
    1 734 A4 fires, where the two must be identical (`W1`). The two
    extra fires, and 51 more across the wave-two families (on NQ: 9
    ARM-B1 and 3 ARM-B2 raw fires; the rest MNQ), came from the two
    20260917 runs the runner skips as corrupt. The runner winds an
    abandoned run back (Amendment 15) and the pilot winds back its own
    buffers, but `Wave2Runner` kept its own fires, counters and
    per-instrument state (top-3 adds and executions, high-confidence
    trades, the residual model's history, the bar cache) outside both.
    Wave three wound back its fires and grid records but not its
    pattern state or counters; wave four not its feature history.
    Each now snapshots and restores its own state with the run (`W9`,
    `B12`, `F14`, each against a pass that never saw the run, and the
    first two with a control showing the old wind-back leaked). Wave
    two is 1.1. The 2026-10-10 wave-two report is superseded: its NQ
    W2-A4r numbers match the pilot exactly, but ARM-B's NQ counts carry
    the leaked fires, so it is re-run with 1.1 rather than corrected by
    hand. No detector, threshold or definition changed.
    Battery: 635/635 + 46/46.

22. **A refused size check is a skip or a stop, never a crash
    (2026-10-20).** The first wave-four search on the operator's drive
    died with `TypeError: Runner._skip_io_error() missing 1 required
    positional argument: 'mark'`, raised while handling
    `WinError 433: A device which does not exist was specified` from
    the runner's size pre-flight (`os.path.getsize` on a 20260914 MNQ
    stream). The drive had dropped. The pre-flight's error path called
    `_skip_io_error` without the wind-back mark that the 9/19 merge
    added to it, so instead of skipping that run (folder still
    answering) or stopping with STOPPED (folder gone), every tool on the
    runner — pilot, waves two to four — would crash there. Nothing has
    been read at the pre-flight, so the call passes no mark and
    `_skip_io_error` winds back only when it has one (`R18`, `R18b`;
    under the old code `R18` raises). No result changed: the path had
    never been reached by a completed run. Battery: 637/637 + 46/46
    (`tests_mles_v12.py` needs the Mono C# compiler `mcs`, which this
    container lacked until installed).

23. **One study across two drives (2026-10-23).** The capture drive is
    full (1 TB) and the operator bought a second 1 TB drive, which
    cannot hold a copy of the first and still record. Recording moves
    to the new drive; the old one is kept as the archive of every
    session to date. The study has to be read as ONE capture in session
    order: robust baselines look back 20 sessions per minute bucket,
    yesterday's and last week's levels come from earlier sessions, and
    wave two's residual model carries history, so two separate passes
    would start the second drive's sessions with no history and differ
    from a continuous pass. Every tool that takes a capture folder now
    accepts two separated by a semicolon,
    `"D:\\MLES_Capture;E:\\MLES_Capture"`: the auditor and the runner
    discover manifests in each and read them as one plan; a run present
    in both (a backup copy) is read once, from the first folder named,
    and reported; one folder gone is the capture gone (STOPPED). Each
    run's streams were already resolved beside its own manifest, so no
    reading code changed. The pilot, wave two and the wave-four search
    on two folders give results identical to one folder holding every
    run (checked here on synthetic tape; `T37`, `R19`). The recovery
    tool and the dashboard stay one folder at a time: repair is run per
    drive, and the dashboard watches the drive being recorded to.
    Battery: 639/639 + 46/46.

24. **Waves three and four on DEV, frozen (2026-10-24).** The
    operator's first complete wave-four search (one read of the 15 DEV
    sessions, which also wrote wave three's real-level report) is
    committed byte for byte under `frozen_dev_20261024/` with
    `MROF_YT_W3_W4_DEV_FREEZE.md`, before any validation session is
    read. Both reports list the 23 sessions 20260921 → 20261023 as
    refused, and no event in them is later than 20260918. Wave four: 0
    CANDIDATEs of 2 208 tests (best q 0.377), five LEAD nominees. That
    commit is the hypothesis set §5 requires. Wave three: Holm over 24
    rejected only L2 SWEEP_RECLAIM at the 60-tick stop (116 NQ events,
    lift +0.155, p 0.001, +5.00 points before costs), which is carried to
    the checkpoint at that stop. L1 fired on no session. A descriptive
    per-session and one-position-at-a-time read of L2's DEV events is
    recorded there as not a test: positive on all six sessions it fired
    on, 55 of 116 events on 20260916 (FOMC). No code changed; the
    package zip was unchanged then (98bc03c1…); it ships them from V26.

25. **What an intraday trader needs that the study lacked (2026-10-26).**
    The operator asked for everything a consistently profitable
    intraday order-flow trader needs that this study did not have. Four
    tools were added; nothing frozen changed (the signal module keeps
    06ce854a…; every earlier suite passes unchanged).
    - **Context** (`mrofyt_context.py`, registration
      `MROF_YT_CONTEXT_REGISTRATION.md`): long, short or neither by
      10:30 ET, from NinjaTrader one-minute exports, which reach back to
      about 2006 where the order-flow recordings reach weeks. A search
      for the registration found that this repository's earlier
      minute-bar studies already read NQ bars from 2019-06-02 to
      2026-08-25 (NQ-DIRECTION-V1 among them, which found no robust
      intraday directional mechanism), and nothing earlier. So the
      search runs on 2019-06-01 .. 2026-06-30 and the verdict comes from
      every session before 2019-06-01; each mode drops the other's bars
      the moment their session is known (`X9`, `X11`). Exports are UTC,
      end of bar; a stamp check refuses any file whose cash-open volume
      jump is not at 09:30 ET and names the fix (`X7`).
    - **Exits** (`mrofyt_exitstudy.py`, wave five, registration
      `MROF_YT_WAVE5_EXIT_REGISTRATION.md`): when price has run 20
      points and momentum looks to be dying, is holding worth less than
      usual? Eight tape signs against a plain 10-point trailing stop on
      every 20-point run of the DEV tape, plus how long each wave-one
      and wave-three signal's edge lasts (5 s to 3 h). The operator's
      own read was asked for and not supplied; the standard inventory
      was fixed instead.
    - **Costs** (`mrofyt_costs.py`): on the frozen DEV report, L2 at 60
      ticks keeps +6.15 points a trade on NQ one position at a time after
      $5 commission, a tick of spread and a tick of stop slippage, and
      +0.15 on MNQ, where commission is four times larger per point.
    - **Risk** (`mrofyt_risk.py`): resampling whole recorded sessions
      cannot show a losing streak longer than the sample's own days held
      (6 trading days for L2), and gave a flattering picture; trades are
      therefore drawn one by one, in three scenarios (as sampled, half
      the edge, no edge), and contracts are sized on the half-edge one.
    Battery: 693/693 + 46/46 (`tests_mles_v12.py` needs the Mono C#
    compiler `mcs`).

26. **Fade the failed break or follow the held one (2026-10-26).** The
    operator asked whether to add "break and reclaim" (that is L2
    itself) and how to set stops, including tight ones placed by the
    order flow. On L2's September DEV trades, half of the eventual
    winners first went 4 points or more against the entry (winners that
    never went 2 / 4 / 10 / 15 points against: 32 / 49 / 69 / 97 %), so
    a stop of a few points meets NQ's own noise; a stop placed by the
    tape is another matter, and is now registered rather than chosen.
    `MROF_YT_WAVE6_LEVELBREAK_REGISTRATION.md` fixes, before either tool
    read real data: part A (`mrofyt_levelbreak.py`) on the recordings --
    L2 with a fixed, a STRUCTURAL (beyond the sweep extreme) and a
    FLOW-INVALIDATION exit, L4 (break and retest), and L2 filtered by
    TRAPPED volume, net of costs, Holm over five, judged on a replay
    holdout folder (sessions before 2026-09-01 only) or at the
    checkpoint; part B (`mrofyt_smt.py`) on NQ and ES minute bars -- ES
    confirming or denying the break, four tests, judged on the years
    before 2019-06-01. Synthetic tape never flips its flow, so the frozen
    L2 detector never fires on it; the suite swaps in a plumbing
    detector inside the suite only and restores it. Nothing frozen
    changed (06ce854a…). Battery: 710/710 + 46/46.

27. **Review of V26–V27 before any real export is read (2026-10-26).**
    A second reading of the six new modules against their registrations
    found no leak and no registration mismatch, and one robustness gap:
    the context stamp check ranked every minute by its volume jump over
    the minute before, so on real NQ tape a thin minute with a sharp
    jump (08:30 on a news day, the Globex reopen) could outrank 09:30 and
    the tool would refuse a correctly stamped file. It now ranks only
    minutes carrying at least half the day's peak average volume
    (`X6a`); the hints for Eastern-stamped and start-stamped files are
    unchanged. Also: files are read BOM-tolerant, mrofyt_smt reads
    through mrofyt_context's one parsing loop instead of a copy, and a
    Tick export (lines that are not minute bars) stops with that reason.
    No threshold, feature, split or test changed. Battery: 711/711 +
    46/46.

28. **Order-flow levels, graded, with targets from the order flow
    (2026-10-30).** L2's September DEV result (+351 points net, 57
    trades, one position at a time) owes 260 points to one day, the
    16 September Fed day: the six daily levels it watches are reached
    on few days. The operator proposed trading the levels the order
    flow builds every day (swing highs and lows), grading each setup
    A+ / A / B / skip from the order flow at the level, and taking the
    target from the order flow too ("could be 10R, not the same every
    time"), and asked that both target ideas be registered.
    `MROF_YT_WAVE7_FLOWLEVELS_REGISTRATION.md` fixes, before the tool
    read real data: three level types (one-minute swing highs and lows,
    absorption prices, yesterday's POC / VAH / VAL), one attempt per
    level, FAILED (fade) and HELD (follow) entries 09:30-15:30 ET, five
    grade points (trapped volume, absorption at the level, a strong
    turn, a fresh level, confluence with a daily level), a structural
    stop of 12-60 ticks, and four exits judged side by side: E1 the next
    level ahead (at least 1.5 x the stop, no cap; a nearer level means no
    trade), E2 no target and an exit when 2 of 4 tape signs say the move
    is dying, E3 half and half, E4 the original 25 / 15 as the baseline.
    Nine tests (FAILED and HELD at grade A or A+ on each exit, and
    whether net R rises with the grade), Holm over nine. DEV describes
    and freezes two cuts; the replay holdout folder or the December
    checkpoint judges. Wave six and wave seven are both registered
    before anyone has read the replay folder, so each reads it once as a
    fresh test. `mrofyt_flowlevels.py` uses wave four's runner, hooks
    only (`FL10`: wave four's grid, wave three's fires and the wave-one
    ledger identical); nothing frozen changed (06ce854a…). Battery:
    731/731 + 46/46.

29. **Waves five to seven run on DEV; their cuts frozen (2026-10-31).**
    The operator ran `mrofyt_levelbreak.py`, `mrofyt_flowlevels.py` and
    `mrofyt_exitstudy.py` on the old drive: 15 DEV sessions read, 23
    later sessions refused unread. `w6_frozen.json` and
    `w7_frozen.json` are committed under `frozen_dev_20261031/` before
    any held-out read, and `MROF_YT_W6_W7_DEV_FREEZE.md` records the
    descriptive DEV results. Wave six's trapped cut is 0 on both
    instruments (the median L2 event traded nothing beyond its level),
    so T5 equals T1 as registered; it stays frozen. Wave seven shows no
    edge after costs on DEV and its grade does not order results. Wave
    five nominated no sign. No code, threshold or test changed.

30. **L2 on the first test, in the morning, both, or held five minutes
    (2026-10-31).** The operator asked whether the first test of a level
    and the 09:30-11:30 window were treated differently. They were not:
    L2 traded every approach at every hour. On the saved DEV report the
    first L2 signal at a level made +12.79 points a trade net (12 trades,
    67 %) against +4.38 for later ones, and the morning +7.25 (14) against
    +4.39 for the afternoon; wave five's half-life showed L2's move in its
    favour to 5 minutes and against it from 10. These are DEV numbers,
    seen, so `MROF_YT_WAVE8_L2VARIANTS_REGISTRATION.md` fixes four
    variants before any held-out session is read by any tool: V1 the
    first approach to the level that CME session (every approach counted,
    signal or not), V2 09:30-11:30 ET, V3 both (the operator's pick), V4
    out at the mid after 5 minutes; wave six's T1 is reported beside as
    the reference. Holm over four; nothing is frozen from DEV.
    `mrofyt_l2variants.py` numbers approaches through the hook where the
    runner opens one (`_select_wall`, called once per approach), on wave
    six's runner (`LV5`: wave six's fires, grid and the wave-one ledger
    identical). Nothing frozen changed (06ce854a…). Battery: 738/738 +
    46/46.

31. **L2 without the fixed 25-point target (2026-10-31).** The operator
    asked whether the target can come from the market. Wave five's tape
    signs and trail, and wave seven's tape exit, did not beat a fixed
    target on DEV, so they are not repeated; two targets never tried on
    L2 are registered in `MROF_YT_WAVE9_L2TARGETS_REGISTRATION.md` before
    any held-out session is read by any tool: NEXT LEVEL (the nearest of
    the six daily range levels and the session VWAP at least 10 points
    ahead, 2 ticks short of it, no cap) and SCALED (25 points x the
    recent average daily range over its DEV median, 10-75 points). Each
    is judged against the fixed 25 on the same trades, on every L2 and on
    the first test (wave eight's V1), with the same stop and limit:
    paired, session-clustered, Holm over four. The DEV run freezes only
    the median range (no outcome) and describes how far each trade ran
    without a target. `mrofyt_l2targets.py` keeps each session's range at
    its close and the levels at each fire, on wave eight's runner (`LT8`:
    wave eight's fires, grid and the wave-one ledger identical). Nothing
    frozen changed (06ce854a…). Battery: 748/748 + 46/46.

32. **Break and reclaim on candle closes (2026-10-31).** L2 fades a
    failed test of a big level within seconds of the order flow
    flipping: on a chart, a wick. The operator asked for the same
    principle on candle closes. `MROF_YT_WAVE10_CLOSERECLAIM_REGISTRATION.md`
    fixes, before any held-out session is read by any tool: a one-minute
    close a tick or more through one of the six daily range levels, a
    close back within 5 one-minute candles, and an order-flow filter at
    the reclaim close (the candle's net aggression and the last 10 s,
    z >= 1.0, against the break); faded at that close with wave six's T1
    exit. C1 every filtered reclaim, C2 the first test of the level;
    Holm over two; the unfiltered reclaims and L2 (wave eight V0 / V1)
    reported beside from the same read. Nothing is frozen from DEV.
    `mrofyt_closereclaim.py` puts the six levels on every grid record of
    wave nine's runner (`CR6`: wave nine's grid, fires and ranges and the
    wave-one ledger identical), so one read also yields waves three, six,
    eight and nine. Nothing frozen changed (06ce854a…). Battery: 756/756
    + 46/46.

33. **An earlier entry, and more key levels judged apart (2026-11-01).**
    The operator asked to enter before wave ten's reclaim close, using
    the order flow, and to add VWAP and its bands, the pivots (with R1
    and S1), confirmed 1-hour and 4-hour swings and the two opens.
    `MROF_YT_WAVE11_EARLY_LEVELS_REGISTRATION.md` fixes, before any
    held-out session is read by any tool: the EARLY entry (a one-minute
    close through, then the first 10 s tick back through with the
    aggression against the break, z >= 1.0, within 5 candles), tested on
    the six daily range levels (E1, E2; Holm over two) beside L2, wave
    ten and a 10 s WICK analogue; and four groups never mixed into those
    six, each judged alone with WICK, EARLY and CLOSE entries and its own
    Holm: A swings (2 candles each side, confirmed, until a close beyond
    or 5 more sessions), B opens, C VWAP and bands, D PP / R1 / S1 / M2 /
    M3. A promising group joins the main levels only after the combined
    set is judged again on later unseen days. The tests use the fixed
    25 / 15 exit; wave nine's scaled target is shown beside. On the six
    levels the CLOSE entry reproduces wave ten exactly (`EL4`).
    `mrofyt_earlylevels.py` runs on wave ten's runner (`EL8`: its grid,
    fires and ranges and the wave-one ledger identical). Nothing frozen
    changed (06ce854a…). Battery: 766/766 + 46/46.

34. **Skip L2 on the wrong kind of day (2026-11-01).** The operator
    asked for the day-type filter: fade failed breaks on normal days,
    not on strong trend days or unusually big days. The context study
    reads day type from years of minute bars but only at 10:30 ET, and
    several of L2's best DEV trades came earlier.
    `MROF_YT_WAVE12_L2CONTEXT_REGISTRATION.md` fixes, before any
    held-out session is read by any tool, two filters known at each
    trade at any hour, every threshold set in advance: TREND (a fade
    against price that is at least 0.25 x the recent average daily
    range from the session VWAP is removed) and BIG DAY (trades after the
    session range reaches 1.0 x that range are removed). Each is judged
    by whether the kept trades beat the removed ones, on every L2 and
    on the first test, session-clustered, Holm over four; a filter that
    helps is combined with L2 only in a later registration judged on
    sessions read by nothing before it. `mrofyt_l2context.py` runs on
    wave eleven's runner (`CX6`: its fires, grid and ranges and the
    wave-one ledger identical). `calendar_2026_events.csv` lists the
    FOMC, CPI and jobs-report days of July-December 2026 for the event
    split, which is described only. Nothing frozen changed (06ce854a…).
    Battery: 773/773 + 46/46.

35. **Back into yesterday's value area with speed (2026-11-01).** The
    operator proposed a fair-value setup: price leaves the value area,
    is not accepted outside, and comes back fast with the order flow
    behind it; and asked that the volatility-scaled target be tested
    with it. `MROF_YT_WAVE13_VALUEAREA_REGISTRATION.md` fixes, before
    any held-out session is read by any tool: yesterday's cash-session
    value area from real trades, out 2 points beyond VAH or VAL, back
    in by a tick after a 4-point move in 30 s with aggression into
    value at z >= 2.0, faded into value 09:30-15:30 ET, 15-point stop,
    30 minutes; VA1 the fixed 25 (does it make money), VA2 the POC, VA3
    the far edge, VA4 the scaled target, each against the fixed 25 on
    the same trades; Holm over four. Wave seven's POC / VAH / VAL
    levels made no trade (their one attempt was used up overnight), so
    this idea had not been tested. `mrofyt_valuearea.py` runs on wave
    twelve's runner (`VA-7`: its fires, grid and ranges and the
    wave-one ledger identical). Nothing frozen changed (06ce854a…).
    Battery: 781/781 + 46/46.

36. **Eight code-review findings on waves seven to thirteen
    (2026-11-01).** The operator asked for a review of the code of
    waves seven to thirteen and then for its eight findings to be
    applied with minimal edits. No held-out session had been read by
    any of these waves. Three change what a wave counts:

    - *Wave seven, yesterday's value levels.* The registration (§1)
      makes POC / VAH / VAL known from the session's first grid tick.
      A recording run that started later in the session saw them as
      starting before its first mid, so they could never break there
      (one reason wave seven's DEV read had no POC / VAH / VAL trade).
      They now count from the later of that tick and the run's first
      mid (`run_levels`), as registered.
    - *Wave seven, HELD.* The return through the level was looked for
      only up to 120 s after the break, while the entry is the first
      grid tick up to 20 s later. A break that failed in between was
      still entered as HELD. A HELD entry now also needs no return a
      tick through the level up to its entry tick. The registration
      does not state this case, so it is a precision added here. It was
      made after wave seven's DEV read (HELD: 26 NQ DEV events, 0–5
      trades per test), for correctness and not from those numbers. No threshold,
      window, stop or exit changed.
    - *Wave eleven, WICK.* When the 300 s window ran out, the tick that
      ended it could not start the next break even when it was on the
      other side of the level. It now can, as in EARLY and CLOSE and as
      §1 describes ("the next break needs a close on the other side").
      Wave eleven has not been run on any recorded session.

    Five leave every result unchanged:

    - the two read ledgers in one module, `mrofyt_ledgers.py`;
    - yesterday's value area looked up once per run and session in
      wave thirteen;
    - wave eleven's hourly Eastern offset made public
      (`et_offset_hourly`) for wave thirteen's profile;
    - one set of compressed mid paths per read, shared by waves eight
      to thirteen (`V.compressed_paths`), ready for the combined read;
    - wave eight's wind-back logging only the run's own writes. Approach
      numbers restart each session, so the log keeps an entry's old
      value and does not just count new keys; LV6 caught the first,
      size-only version.

    `tests_mrofyt_shared.py` has one test per finding. SH3 and SH4 fail
    on the code before the fix. All earlier suites pass unchanged.

    **Wave seven must be re-frozen.** Its DEV cuts in
    `frozen_dev_20261031/w7_frozen.json` (trapped medians by instrument
    and kind) came from the events before these fixes. Wave seven's DEV
    run is to be repeated and the new file committed before wave seven
    reads any held-out session. That repeated DEV run is still DEV and
    exposes nothing new. Wave six's frozen cut is untouched, since wave
    six's code did not change. Nothing frozen changed (06ce854a…).
    Battery: 789/789 + 46/46.

37. **The one test the unseen days decide (2026-11-01).** After wave
    nine's DEV run the operator learned that wave eight's V1 (the very
    first touch of a level) holds 3 NQ DEV trades, all on one session,
    too rare to reach a verdict on the unseen days. The version the
    operator had been looking at counts the first L2 *signal* at a
    level, even when earlier touches gave none. The operator chose it
    as the version to test. `MROF_YT_WAVE14_L2FIRSTSIGNAL_REGISTRATION.md`
    fixes it, before any validation or replay holdout session was read
    by any tool, as the **primary test** of those sessions:

    - **Trades:** wave six's L2 events. Only the first L2 signal at each
      level per CME session, at any hour; an event uses up every level
      it touches, taken or not.
    - **Exit:** 25-point target, 15-point stop, 30 minutes. One position
      at a time, net of costs.
    - **Verdict (NQ only):** PASS needs 30 or more trades, the
      session-clustered 95 % interval of net a trade above 0, and a
      profit still without the best day. Anything else is NOT PROVEN,
      with the reason.
    - **Withholding:** a held-out read with fewer than 30 trades shows
      the count only and withholds every result from screen and file,
      so the verdict comes at the first read that holds 30. No threshold
      is lowered.
    - MNQ, every L2 and the strict first touch are reported beside,
      never tested.

    The count shown to the operator earlier (13 trades, 62 %, +10.60)
    keyed signals by the set of levels each touched. One signal at two
    levels at once let a later signal at one of them through. Counting
    each level separately, as registered, the saved DEV report gives 12
    trades, 7 won (58 %), +9.44 net a trade over 6 sessions; FS3
    reproduces both counts. `mrofyt_l2firstsignal.py` runs on wave
    eight's runner (FS6: its fires and grid identical). Nothing frozen
    changed (06ce854a…). Battery: 795/795 + 46/46.

38. **Three more obvious levels (2026-11-01).** The operator asked to
    add three levels that many traders watch for the reason L2 works
    (stop and breakout orders sitting just beyond them):

    - the initial balance high and low (09:30–10:30 ET);
    - round numbers every 100 points;
    - equal highs and lows.

    `MROF_YT_WAVE15_OBVIOUSLEVELS_REGISTRATION.md` fixes them before any
    tool computed them on any recorded session and before any validation
    or replay holdout session was read:

    - **IB:** known 10:30–17:00 ET, and only when the recording covers
      the window.
    - **ROUND:** every multiple of 100.00 points, per session.
    - **EQUAL:** two 15-minute swing highs (lows) within 4 ticks,
      standing until a 15-minute close a tick beyond it, or 5 sessions.
    - **Signal:** wave eleven's WICK entry, the 10-second L2 analogue,
      unchanged. Only the first signal at each level per session is
      taken.
    - **Trade:** 25 / 15 / 30 minutes, one position at a time per group,
      net of costs.
    - **Verdict:** each group judged alone on NQ: 30 or more trades,
      Holm over the three, the 95 % interval above 0 and a profit
      without the best day. A held-out read withholds a group that has
      fewer than 30 trades.
    - It is **secondary** to wave fourteen on sessions on or after
      2026-09-21, and judged separately on the replay holdout.

    `mrofyt_obviouslevels.py` adds no runner hook: the levels are built
    after the read from the mids and the grid, on wave fourteen's runner
    (OL6: its fires and grid identical). Nothing frozen changed
    (06ce854a…). Battery: 802/802 + 46/46.

39. **Years of minute bars, a limit entry, and a second strategy
    (2026-11-02).** The operator asked for the three ideas that follow
    from fifteen waves: L2 rests on about nine usable recorded sessions,
    costs take 2–3 ticks of every trade, and everything so far is one
    strategy. `MROF_YT_WAVE16_REGISTRATION.md` fixes all three before
    any part was computed on any data:

    - **16A, L2's six levels without order flow.**
      - **Rule:** a bar 2 ticks through, closed back within 5 bars; the
        first signal per level per session; 25 / 15 / 30 minutes.
      - **History:** tested on NQ minute exports, month-clustered,
        described on 2019-06 .. 2026-06 and judged once on the years
        before 2019-06-01.
      - **Recordings:** the same rule on minute bars of the mid, beside
        wave fourteen's first L2 signals, so the difference measures
        what the order flow adds.
    - **16B, a limit entry.**
      - **Order:** 2 or 4 ticks better than the signal mid, live for
        60 s. It fills only when price trades a full tick through it,
        and a missed signal counts as 0.
      - **Test:** each signal's limit result minus its market result,
        session-clustered, Holm over the two.
    - **16C, intraday momentum** (Gao, Han, Li and Zhou, 2018).
      - **Rule:** the move from yesterday's cash close to 10:00 sets the
        side of a 15:30–16:00 trade.
      - **Data:** NQ minute exports, judged as 16A-H.

    The minute-bar parts reuse the context study's reader, stamp check,
    front contract and split. They skip the first 14 sessions of each
    read, its ATR rule, recorded in the implementation record. The
    recordings parts add no runner hook (16A on wave ten's runner, 16B
    on wave fourteen's; ML6 and LE3 show the fires and grid identical).
    `mrofyt_ledgers.py` gains `record_history_read`. Nothing frozen
    changed (06ce854a…). Battery: 816/816 + 46/46.

40. **Every recordings test in one read (2026-11-02).** The operator
    asked why the coming test of the unseen sessions would not include
    everything they had added. Everything was already registered, but
    each wave was its own command and its own read.

    `mrofyt_checkpoint.py` reads the recordings once, with wave
    thirteen's runner, which carries every wave's hooks. It then runs
    each wave's own, unchanged report code on that read: waves 6, 8–15,
    16A and 16B. CP1 and CP2 show every report byte-identical to the
    wave's own command, on DEV and on an unblind read.

    - **Output:** wave fourteen's verdict as the headline, a scorecard
      of every NQ row with its status, and the number of tests.
    - **The luck note:** a pass outside the headline is promising, to be
      confirmed on later sessions, not proven.
    - **Not in the read:** wave seven (its own engine; its DEV cuts are
      to be refreshed first) and the minute-export parts.
    - **Exposure:** an `--unblind` read writes every wave's version to
      the exposure ledger.

    No rule, threshold or verdict is added or changed, and it has no
    registration of its own. Nothing frozen changed (06ce854a…).
    Battery: 820/820 + 46/46.

41. **Confluence, and whether to size into it (2026-11-03).** The
    operator asked whether a level many traders see from different
    angles (yesterday's high near a round 100, the initial balance on an
    overnight high) makes a better trade, and if so whether to size into
    the best setups. `MROF_YT_WAVE17_CONFLUENCE_REGISTRATION.md` fixes
    it before confluence was computed on any session and before any
    validation or replay holdout session was read:

    - **Signal:** wave eleven's WICK entry at every level of every
      family. The first signal per level per session; signals within
      60 s are one event.
    - **Grade:** the distinct families within 2 points: **A+** three or
      more, **A** two, **B** one.
    - **Trades:** 25 / 15 and 40 / 15, one at a time.
    - **Tests:** C1 confluence minus none, C2 A+ minus A, C3 the 40-point
      target minus the 25, C4 confluence makes money; Holm over four on
      NQ.
    - **Ladder:** 1 / 2 / 3 contracts for B / A / A+ against 1, described
      only. It may be adopted only after C1 (and, for the A+ step, C2)
      passes on held-out sessions, in a later registration.

    `mrofyt_confluence.py` runs on wave thirteen's runner with its hooks
    unchanged (CF6), and joins the one-read checkpoint: CP1 and CP2 show
    its report byte-identical to its own command. Nothing frozen changed
    (06ce854a…). Battery: 827/827 + 46/46.

42. **The whole bracket scaled to the market (2026-11-03).** Wave nine
    scaled only the target, and on DEV its target came out at about 25.5
    points, because September was its own reference. The operator asked
    what quants do instead. `MROF_YT_WAVE18_SCALEDBRACKET_REGISTRATION.md`
    fixes the textbook answer before any held-out session was read, on
    the headline's own trades (wave fourteen's first signals):

    - **Bracket:** stop 15 × k and target 25 × k, where k is wave nine's
      recent 14-session range over its frozen DEV reference, clamped
      0.4 .. 3.0.
    - **B1:** scaled minus fixed, net points a contract.
    - **B2:** scaled minus fixed, net in units of each trade's own stop,
      i.e. with every trade risking the same dollars.
    - **Verdict:** session-clustered, Holm over two, and profitable
      without the best day.

    The headline stays judged on the fixed 25 / 15. `mrofyt_scaledbracket.py`
    runs on wave nine's runner (SB4: its fires and grid identical) and
    joins the one-read checkpoint when `--a-ref` is given (CP1, CP2).
    Nothing frozen changed (06ce854a…). Battery: 832/832 + 46/46.

43. **One first signal from each side of a level (2026-11-05).** The
    operator asked whether "first touch" meant one side of a level or
    both. Wave fourteen takes one L2 signal per level per session from
    either side; once price breaks a level and comes back to it from the
    other side, the trapped traders are different ones.
    `MROF_YT_WAVE19_L2FIRSTSIDE_REGISTRATION.md` fixes the per-side rule
    as its own test before any held-out session was read:

    - **Rule:** an L2 event is taken when none of its levels has had an
      L2 event in the same direction earlier in the session, so each
      level gives at most one short and one long.
    - **Trade and verdict:** wave fourteen's, unchanged.
    - **Beside:** wave fourteen's per-level trades and the trades only
      this rule takes.

    It is a **secondary** test; wave fourteen stays the headline. On DEV
    (seen, so motivation only) it took 16 trades, 11 won, +13.20 net a
    trade, against wave fourteen's 12 and +9.44. Three of its five extra
    trades fell on 16 September (the FOMC day); without that day it made
    +10.45 a trade, no better than wave fourteen without it (+11.97). The
    suite reproduces these rows from the saved DEV report (FD2).
    `mrofyt_l2firstside.py` runs on wave fourteen's runner (FD3: its
    fires and grid identical) and joins the one-read checkpoint (CP1,
    CP2). Nothing frozen changed (06ce854a…). Battery: 836/836 + 46/46.

44. **A faster read, proved before it is used (2026-11-08).** The
    one-read checkpoint on both drives (about 1.2 TB) was measured at
    about 8.5 MB a second, a day or more on one core. The operator
    asked for it to be faster, with results the same as the full read.
    Nothing registered changes; the same sessions are read and marked.

    - **`--nq-only`:** the checkpoint reads NQ's recordings only. Every
      test is judged on NQ, and the runner keeps each instrument's
      levels, flow, baselines and trades apart (checked in the code:
      nothing but bookkeeping is shared), so NQ's results are those of
      the full read; MNQ, described beside and never tested, is not
      read. About half the work.
    - **`mrofyt_cpcompare.py`:** compares the NQ values of two
      checkpoint reports. The operator first runs the DEV checkpoint
      with `--nq-only` and compares it with the full DEV report
      (`cp_dev.json`, already read); only on MATCH is `--nq-only` used
      for the held-out read. A day MNQ alone recorded drops out of the
      sessions read, and the comparison names it.
    - **PyPy:** runs the checkpoint unchanged, its report identical
      byte for byte on synthetic captures, about 1.6 times faster. It
      exposed a fault the checkpoint would have hit: the exposure
      ledger, recorded once per wave with each call reading the one
      before, was written to a file left open, which PyPy closes only
      when collected; the next call read it unwritten and the ledger
      was lost (shown on the old code). `mrofyt_ledgers.py` now writes
      and closes before returning (the same bytes), and the checkpoint
      writes its report the same way. The single tools' own commands
      keep their writes, so PyPy is for the checkpoint and the
      comparison only.

    `tests_mrofyt_nqonly.py` (5) runs under CPython and PyPy;
    `tests_mrofyt_l2firstside.py` collects garbage after writing its
    synthetic runs so it does too (`mles_v12_synth.py` unchanged,
    3231659f…). Nothing frozen changed (06ce854a…). Battery: 841/841 +
    46/46.

45. **The Traders Reality Psy levels, matched to the chart before any
    test (2026-11-09).** The operator trades with the Traders Reality
    indicator (TR_MAIN, "Psy calc type: forex", overridden, since a
    futures symbol would otherwise be given the crypto calc that starts
    on Saturday night) and asked that its weekly Psy-Hi / Psy-Lo be
    among the levels. The operator supplied the indicator's and its
    library's source. The forex calc is the highest high and lowest low
    while `time('240', '0000-0800:2', "GMT")` is in session -- Monday
    00:00-08:00 GMT -- then fixed for the week. Whether TradingView
    tests that session on the chart's candles (7 PM-3 AM New York in
    winter, 8 PM-4 AM in summer) or on the 4-hour candles it names
    (10 PM-6 AM New York) is not settled by the source, so
    `mrofyt_psycheck.py` rebuilds both, and the project's earlier
    18:00-02:00 adaptation, from the recordings' NQ trades, and compares
    them with the operator's chart (last week 28,834.50 / 28,666.25 and
    this week 27,321.00 / 26,751.50, read from the chart). It reads only
    DEV or EXPOSED Monday sessions, so the week of 2 November is checked
    once the held-out read in progress has marked it; this week stays
    unread. Nothing is registered or tested yet: a Psy wave is
    registered on the window that matches, judged on sessions read by
    nothing before it, or on years of minute exports. `tests_mrofyt_
    psycheck.py` (6) runs under CPython and PyPy. Nothing frozen changed
    (06ce854a…). Battery: 847/847 + 46/46.

46. **Levels like the value area (2026-11-10).** On DEV, wave thirteen's
    return into yesterday's value area was the cleanest small result
    (7 trades, 7 won, three sessions: far too few to judge). The
    operator asked which other levels of that kind belong beside it and
    asked for them in the held-out read. `MROF_YT_WAVE20_PROFILELEVELS_
    REGISTRATION.md` fixes five, none computed on any session before it
    was frozen:

    - **ONVA:** the overnight (18:00-09:29:59 ET) value area, known from
      09:30. **WKVA:** last ISO week's value area. **CLOSE:**
      yesterday's 16:00 close. **MID:** yesterday's midpoint.
    - **Four tests:** the first WICK signal at each level per session,
      wave fifteen's code and trade; Holm over four.
    - **Two tests:** wave thirteen's back-into-value event against the
      overnight and the weekly value area; Holm over two.
    - **Two tests:** an untested POC of the last 5 sessions, 10+ points
      ahead, as the target of an L2 trade, against the fixed 25 on the
      same trades; Holm over two.

    All are **secondary**; wave fourteen stays the headline, and eight
    tests are added to a read of about fifty-four, so a pass is a lead.
    The registration discloses what is known of the held-out sessions:
    two `--unblind` checkpoint runs (7 and 8 November) were stopped
    before finishing and wrote no report and no ledger entry, and a
    chart of early November was seen while the Psy levels were matched.

    `mrofyt_profilelevels.py` runs on wave thirteen's runner plus hooks
    (PL9: fires, grid, value areas, ranges and ledger identical), and
    the one-read checkpoint (1.2) now reads with that runner; every
    earlier wave's report is still byte-identical to its own command
    (CP1, CP2), and the NQ-only read still gives every NQ value of the
    full read (NQ1, NQ2). `mrofyt_cpcompare.py` compares the waves two
    reports both hold, so a DEV report made before this wave can still
    prove the NQ-only read. Nothing frozen changed (06ce854a…). Battery:
    859/859 + 46/46.

47. **The Traders Reality levels (2026-11-13).** The operator trades with
    the Traders Reality indicator and, before the held-out read, asked
    for three of its level kinds that no wave has tested.
    `MROF_YT_WAVE21_SESSIONLEVELS_REGISTRATION.md` fixes five groups,
    none computed on any session before it was frozen:

    - **PSYC / PSYH:** the weekly Psy high and low. The indicator's
      forex calculation takes the highs and lows inside Monday
      00:00-08:00 GMT; its source does not settle whether that is the
      chart's own candles (PSYC) or the CME 4-hour candles opening
      there, Sunday 22:00 - Monday 06:00 ET (PSYH). Both are registered
      as they stand; `mrofyt_psycheck.py` (Amendment 45) names the
      chart's one after the read. Known from the window's end to Friday
      17:00 ET.
    - **ASIA:** the Tokyo session (00:00-06:00 GMT) high and low.
      **LONDON:** the high and low from 08:00 London time to 09:30 ET.
      Both known to 17:00 ET that session.
    - **ADR:** the session's lowest mid so far plus wave nine's recent
      range, and its highest so far minus it.
    - **Five tests:** the first WICK signal at each level per session,
      wave fifteen's code and trade; Holm over five.

    Window highs and lows come from trades, under a completeness rule
    (first and last trade within 120 s of the window's edges, no
    10-minute hole). All are **secondary**; wave fourteen stays the
    headline, and five tests are added to a read of about sixty-two, so
    a pass is a lead. A Psy group has two levels a week: it is expected
    to stay under 30 trades in this read and show its count only. The
    registration repeats Amendment 46's disclosure and adds the four Psy
    prices the operator read from the chart.

    `mrofyt_sessionlevels.py` runs on wave twenty's runner plus hooks
    (SL8: fires, grid, profiles, value areas, ranges and ledger
    identical), and the one-read checkpoint (1.3) now reads with that
    runner; every earlier wave's report is still byte-identical to its
    own command (CP1, CP2), and the NQ-only read still gives every NQ
    value of the full read (NQ1, NQ2). In SL9 every window high and low
    equals the highest and lowest trade read straight from the files,
    and both Psy pairs equal `mrofyt_psycheck.py`'s two windows.
    `tests_mrofyt_sessionlevels.py` (11) runs under CPython and PyPy.
    Nothing frozen changed (06ce854a…). Battery: 870/870 + 46/46.

48. **The held-out read, and the stretched fade on minute bars
    (2026-11-17).** The one-read checkpoint (V47) read every recorded
    session through 2026-11-13 on 13-17 November: 55 sessions, the 40
    from 2026-09-21 being the validation hold-out. All 55 are now
    `EXPOSED_PILOT_DEV`. The ledger in this package is the operator's,
    as that read wrote it; it replaces the pilot's 5-day copy. No test of
    the 67 passed:

    - **Wave fourteen, the headline:** 48 NQ trades, 42 % won, +1.02
      points a trade, 95 % range −5.6 to +7.6, nothing left without the
      best day: NOT PROVEN. September had shown 12 trades, +9.44.
    - Every L2 signal, one at a time: 379 trades, −0.65. With the order
      flow against without it (16A-R): +1.02 against +2.95. The scaled
      bracket, the targets, the day filters, the confluence grades and
      the limit entry did not help. Back into yesterday's value area,
      September's 7 of 7: 95 trades, −1.35.
    - The new levels: fading the overnight value area lost (31 trades,
      16 % won, −9.26); the others held fewer than 30 trades and show
      counts only.

    Read afterwards, not a test: wave twelve's TREND filter, registered
    to remove a fade taken back toward VWAP from far away, separated the
    trades the other way on NQ and MNQ in the unseen days and on MNQ in
    September. `MROF_YT_WAVE22_STRETCHFADE_REGISTRATION.md` puts that one
    cut to years of NQ minute bars, which 16A-R allows, since the order
    flow did not add:

    - part 16A's minute-bar failed break, every signal, split by wave
      twelve's rule unchanged (`|close − VWAP| >= 0.25 × A`, fading back
      toward VWAP);
    - **ST1:** the stretched fade makes money. **ST2:** it beats the
      rest. Month-clustered, 100+ trades, Holm over the two;
    - judged in each era, 2019-06 to 2026-06 without a flag and before
      2019-06-01 once with `--unblind`; confirmed only if ST1 passes in
      both.

    The registration discloses that plain VWAP reversion and a
    VWAP-stretch fade of structure breaks already lost on minute bars
    here (RVMR-STRAT B4, N-SERIES N10), and that close − VWAP closes with
    a 106-minute half-life. It is a lead with a low prior.
    `mrofyt_stretchfade.py` reads exactly part 16A's sessions, bars and
    levels: in SF4, on one contract and across a roll, its unsplit
    trades are part 16A's "every" trade for trade. A year of full-size
    minute bars reads in seconds. `tests_mrofyt_stretchfade.py` (7) runs
    under CPython and PyPy. Nothing frozen changed (06ce854a…). Battery:
    877/877 + 46/46.

49. **Reading the order flow, and three rules for years of minute bars
    (2026-11-17).** After the checkpoint, the operator asked for new
    order-flow strategies built from everything learned. Wave four's
    anatomy (the 15 DEV sessions, about 48 000 ten-second snapshots of
    NQ) was read as long minus short (direction) apart from long plus
    short (how much price moves at all):

    - The aggressor delta, the order-flow imbalance and the top-3 book
      imbalance mostly moved direction by under 3 points. Their extremes
      marked activity: both sides reached their targets more often. That
      is the checkpoint's 16A-R result (the flip did not add) seen from
      the other side.
    - The distance from VWAP showed two zones on both sides: moderately
      away, price kept going away; far away, it came back. The last 30
      minutes' move continued, except after the largest drops.
    - The checkpoint agreed in three places: fades at the VWAP bands lost
      on both instruments in both periods, L2 fades toward VWAP from far
      away won 46 % on both, and failed breaks of the overnight value
      area resumed 26 times in 31.

    `MROF_YT_WAVE23_VWAPVALUE_REGISTRATION.md` fixes three rules from
    that reading, for the same minute export as wave twenty-two:

    - **RUBBER:** far from VWAP with the last 30 minutes turning back:
      toward VWAP, 25 / 15.
    - **MOMENTUM:** moderately away and moving away: with it, 25 / 15.
    - **ACCEPT:** a failed break of the overnight value area: with the
      break, 15 / 25.

    Each is month-clustered, needs 100+ trades and goes through Holm
    over three, judged in each era, and is confirmed only if it passes
    in both. A confirmed rule comes back to the recordings' fresh
    sessions with the order flow as a timing filter, the one job the
    anatomy suggests it can do. `tests_mrofyt_vwapvalue.py` (8) re-derives
    every trade of a synthetic export without the module's helpers and
    runs under CPython and PyPy; a full year of minute bars reads in
    about 3 seconds. Nothing frozen changed (06ce854a…). Battery:
    885/885 + 46/46.
