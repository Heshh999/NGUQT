# REVIEW_PACKAGE_MANIFEST_v01_6_7.md — independent-verification package

Additive. `REVIEW_PACKAGE_MANIFEST.md` (v01.4),
`REVIEW_PACKAGE_MANIFEST_v01_5.md` and `REVIEW_PACKAGE_MANIFEST_v12.md`
stay unchanged and hash-pinned. Every claim below is independently
re-runnable. **THIS PROJECT DOES NOT AUTHORIZE LIVE TRADING.**

## New in this delivery

```
cb1ac7fa10b59955a467d140e7c17b9318eea525adb29b42c07cb15f64de1057  mrofyt_swings_v016.py
001d80630f0561749899f2ea46707bc339dd91435e082bad6da963c394d8b9de  mrofyt_engine_v016.py
84a0ca89b93eea041a82da37e5afb87c91072d3c8ed75ff77ced17706126b963  tests_mrofyt_v01_6.py
2b1f9f9159fcda2b76d5f9ac16e53771f473278bf7009b98de51cec37c95e17b  MROF_YT_OF01_6_SUCCESSOR_FREEZE.md
b6bd0b05f48a6e26871df69c97fde97112a19d3f4b17da7edf280caa5bdc354d  mrofyt_exits_v017.py
0df5357cce0d0c77c6f38759c757086a067ea90aef8efc1d373a766bbc8fe7f9  tests_mrofyt_v01_7.py
cbd25e6df806db216cf480a3445f1628fc56dff95ea0d903dc197b91ac7b4791  MROF_YT_OF01_7_EXIT_FREEZE.md
51c2996ffcd15faeca7670864cecb51de26d9741c2903abcd2fe572af43ade80  mrofyt_pilot.py (MROF-YT-PILOT-1.2; supersedes b955ea9d… — an unreadable or empty capture STOPS the pilot before anything is written, so no report and no exposure label from a pass that did not complete; io-error skip reason reported; Amendment 11. Earlier 3bd2b115…: validation blind (BLIND_FROM=20260921, markouts withheld, monotone exposure ledger), seeded bootstrap 95% intervals, skip reasons + book-integrity counters; 1.1 a6504d0f…: event de-duplication and the 300/600/1800 s horizons)
3f118e151d4634a177a148df9f26dc45dc5e94037bbe9f39b0796d205a1d4d9e  tests_mrofyt_pilot.py (45 tests; supersedes d174d26a… — P13 the level snapshot is kept only for non-blind windows; earlier a9bacd64… → P12: a stopped pass leaves the exposure ledger byte-identical)
6af137d68f1feb4f39206056534952712fe9468cc4818f0a409a26cb726692fa  MROF_YT_WAVE2_REGISTRATION.md (DRAFT — pending operator sign-off; supersedes 4e398285… — §11 implementation record and two implementation-precision notes in §4.1/§4.2, no hypothesis parameter changed; earlier: §8.1 interim-monitoring rule; re-hash on sign-off)
ada1320a067c3fad9582f6f216b5ecc4a2d352b69dc5bcdf3f99e4b0ae9cc04a  mrofyt_wave2.py (MROF-YT-WAVE2-1.1; supersedes 24103422… — a run the runner abandons mid-stream is wound back whole in wave two too (fires, counters, per-instrument state incl. the residual history); 53 fires from the two 20260917 runs skipped as corrupt had stayed in the 2026-10-10 report, Amendment 21; earlier MROF-YT-WAVE2-1.0; supersedes 18ba3b83… — an unreadable or empty capture folder STOPS the pass with no report instead of printing zero fires on zero sessions, Amendment 11. The registration as running code: W2-A1, W2-A4r, W2-A4f, W2-A4-OPEN, W2-A4r-z15, W2-A4r-HC, arm B, arm C placebo; subclass of the pilot runner via the runner's observation hooks; wave one untouched; §4.3 CAUSAL_SWING declared not-in-this-version)
2a88d57eedc0ae3219c199cdc38c83509bd640e865fc93ec45bda98d57c352d8  tests_mrofyt_wave2.py (30 tests; supersedes 50158d03… — W9 the abandoned-run wind-back, with a control showing the 1.0 behaviour leaked; earlier 29 tests; supersedes fbeb2623… — W8)
c162abe1587a67a99e64795766cefda28d7198640e0123a6f68ad2de53dc6fa6  MROF_YT_WAVE3_BIGMOVE_REGISTRATION.md (supersedes ea3ec303… — §3 and §10: baseline cells by (instrument, ET hour, direction), a pre-run correction made before any recorded session was read, Amendment 20; earlier FROZEN 2026-10-03 before any run, committed at 85084ff5… and then completed with its §10 implementation record: eight big-move patterns on the frozen grid and approach windows, a 100-tick target with 40/60/80-tick stops and an 1800 s limit, hour-matched baseline, the wave-two placebo arm, 24 tests under Holm, DEV sessions <= 20260918 only; Amendment 18)
ac7b874886f0b672383fea24e32caf154904d0ca08022aefbdda0471e777569c  mrofyt_bigmove.py (supersedes 88499404… — the abandoned-run wind-back also restores wave three's pattern state and counters, Amendment 21; earlier supersedes 1059327c… — direction-matched baseline cells; report_from_runner split out so wave four gets wave three's report from the same read, Amendment 20; earlier MROF-YT-W3-BIGMOVE-1.0: the registration as code on the pilot runner's hooks only; refuses every session after 20260918 unless --unblind, which announces itself and exposes permanently; the path score by a Fenwick first-touch sweep checked against a plain scan; no fill, slippage, commission or order; Amendment 18)
d5dd23f6d1edafeae27b2d437d765a3fe99b1eaa17619d579b851d72822ca2de  tests_mrofyt_bigmove.py (28 tests; supersedes 4f4a173d… — B12 the abandoned-run wind-back; earlier 27 tests; supersedes cf2cef7f… — B5e recomputes the lift from direction-matched cells; earlier 27 tests, B1–B11: the score against a forward scan on 8 904 random-walk checks, hand paths, every pattern condition load-bearing, Holm, the refusal gate, the hour-matched lift recomputed from the report, placebo offsets identical to wave two, the unblind ledger, wave-one ledger identity, frozen-hash pins, the census)
853d80e2a9baaa0b627a2fe0a9f27390d7bbf30945543721b558acd19dc5f9ed  MROF_YT_WAVE4_DISCOVERY_REGISTRATION.md (FROZEN 2026-10-09 before any run, committed at 9d35c018… and then completed with its §10 implementation record and one pre-run correction (direction-matched baseline cells): fourteen causal grid features, 736 rules, 2 208 tests, session-clustered t, Benjamini–Hochberg over all 2 208, both DEV halves, at most five nominated rules frozen with numeric cut-points and judged once on the validation sessions; Amendment 20)
3500fcc3ce7255331602a8d284c813a7d9edd8344d57f3cdc251579c6ddca175  mrofyt_discover.py (supersedes b4a54b4b… — the abandoned-run wind-back restores the wave-four feature history, Amendment 21; earlier MROF-YT-W4-DISCOVER-1.0: the counted search and the checkpoint evaluator on wave three's runner, hooks only; one read of DEV yields wave four's report and wave three's real-level report; --unblind only with --evaluate; no fill, slippage, commission or order; Amendment 20)
5a90b1794603789322fe3ad4525e5564e03166addb91c93c619b67e7c1943709  tests_mrofyt_discover.py (17 tests; supersedes b1eb6395… — F14 the abandoned-run wind-back; earlier 16 tests, F1–F13: Student t, BH and the clustered SE against references, the 736-rule grammar, the anchored cooldown, a planted effect found and pure noise rejected, degenerate tails counted, nominee overlap, frozen cut-points reproduce the search, the unblind refusal, one read for two waves, the features causal under a cut tape, evaluate's two modes and the ledger, wave-one ledger identity and frozen hashes)
6b0eb7ea4a9bc5deb48eec7e461b03c36d509defeb9a28023b104b489f929538  MROF_YT_PILOT_DIAGNOSTIC_FINDINGS.md (supersedes 4624b199… — Amendment 2: the validation blind; Amendment 1 supersedes 8ab588fa…)
aaf1f1f91e33ecd14b81b3b5d58f750acd0800fc57059b1a861b2c950e73edda  mrofyt_recover.py (MROF-YT-RECOVER-1.6; supersedes 962f7319… — a file whose date Windows will not return (error 1392 on a damaged directory entry) is set aside as SKIPPED_UNREADABLE_FILE inside the live-run check instead of stopping the whole dry run before any run is listed, Amendment 17. 1.5 (962f7319…) supersedes 3bed26e0… — a real pass prints each run as it starts, its phases and its outcome, oldest session first; after a failed read or write it asks the drive root and the folder separately and names which stopped answering (DRIVE_GONE, FOLDER_UNREADABLE, WRITE_REFUSED, READ_REFUSED) instead of guessing "disconnected"; a refused write stops the pass after taking back that run's unfinished copies; the folder must take a small check file before anything is read in bulk; an earlier pass's manifest whose files are missing or not the size it records marks the run for redoing; a run the probe found unreadable is not read again; declared fields are borrowed from recorder-written manifests only; Amendment 16. 1.4 (3bed26e0…) supersedes bc2d60d5… — every read is memory-bounded (a zero-filled file with no line break, what a drive drop leaves, no longer pulls its whole size into memory: MAX_LINE_BYTES), and one unreadable file (the first real 1.3 dry run died on OSError 22) is named with its Windows error and set aside as SKIPPED_UNREADABLE_FILE, never repaired, and the pass carries on; 1.3 (bc2d60d5…) supersedes dcd01f4a… — a repair must not fill the drive the recorder writes to: the dry run states what --repair would write against the free space, a pass that would leave under 40 GB free is refused before writing anything, and each run is re-checked; Amendment 14. 1.2 (dcd01f4a…) supersedes 0e73abfb… — asks Windows directly whether the recorder still holds a run (file-sharing check), the only sign that holds over a weekend; anything held or unanswerable is refused; Amendment 11. 1.1 (0e73abfb…): indirect live-run signs; 1.0 (a8b637a5…): manifest reconstruction, instant --dry-run)
1143117b906ace167869d2cf336add6ffb1f21048a9132ec672f6298f422cf2e  tests_mrofyt_recover.py (51 tests; supersedes d65c1740… — V17 a .partial file whose date Windows refuses; earlier d65c1740… supersedes 1a91fed7… — V13–V13b progress lines, oldest-first order, the earlier-pass count; V14–V14d a refused write, an unlistable folder, a vanished drive (each named, the stopped run's copies taken back where the drive answers, the re-run finishing); V15–V15b the check file before any bulk read; V16–V16d the earlier-pass manifest check, recorder-only declarations, no second read of an unreadable file; earlier 1a91fed7… → V11–V12b; earlier 7960bb10… → V11 the unreadable file, V12–V12b bounded reads of zero-filled files (peak memory asserted); earlier 04f7d842… → V10–V10c the free-space guard, each test stating the drive it simulates; earlier ed72a3fd… → V9–V9g: the direct check with an injected answer, the closing-window veto, the recorder-source premise, the atomic manifest write)
f61a1f23fe31a479d04d4fd98cd59c66a9b018e0ef6c5f52459e2bea4094f84c  MROF_ACTUAL_STATE_INVENTORY.md (supersedes 50d0ddc7… — row 7 records the W2-A4f wiring, row 20 the wave-two module)
```

God's Eye View — the read-only dashboard (`analysis/godseye/`, Amendment 12):

```
e79dd336adfea628846db28c3d4019ea0b4f2fad72aa00d6fac5cc1e3da78bf0  ../godseye/godseye_registry.py (MROF-GODSEYE-REGISTRY-1.0; supersedes f7c4d222… — resolve() judges each wave-two family exactly as mrofyt_wave2 does (G11d), and DEMOS: one scripted mechanism scenario per hypothesis with a counter-example, every one run through the frozen detector by G11–G11c; Amendment 13. Earlier: hypotheses, levels, context and the discrepancy record as the frozen code has them; G1b reproduces every frozen detector from its written conditions)
71126ff55621e752576179e7e6f937b0410dc76eedb5bde56a4487507ca82aaf  ../godseye/godseye_policy.py (MROF-GODSEYE-POLICY-1.0: EXPOSED / BLIND / PROTECTED_UNLISTED / UNKNOWN, fail closed; event-level field list; strip-and-scan boundary; outcome lock read only)
bb5ce978700145faebd3d211ebbe4232c55e5081661363eaf9255b9827a3a328  ../godseye/godseye_replay.py (bounded raw reads: byte-offset search, 250,000-row cap that says truncated, book rebuilt with the runner's frozen KLevelBook, depth never invented)
b88ac63e1a71741587956e4f5b21c81145975a3dd78e222cae49c2fa9b4ab040  ../godseye/godseye_export.py (MROF-GODSEYE-EXPORT-1.0; supersedes dc4d9793… — a file found unreadable is remembered in out_dir and not opened again until its size or time changes; earlier 7fb480f5… — a run set aside by recover 1.4 as SKIPPED_UNREADABLE_FILE carries the file name and the Windows error into the health and session sections; earlier 60e463e3… → the replay windows file is split once per pilot run into one piece per (session, instrument) of inspectable sessions, so a routine export reads a small index instead of ~100 MB; a session whose only audit flag is RECONSTRUCTED_RUN_NOT_SELF_VERIFYING counts as complete, labelled; Amendment 14. Earlier 16aa4c57… → progress section (complete-session rule, runbook milestones, checkpoint clock, accrual counts), disk runway, next scheduled market change, resolved conditions for wave-two families; Amendment 13. Earlier: reports + bounded capture tail -> one sanitized snapshot, atomic, refuses to write on any event-level key outside the exposed section, refuses an out_dir inside the capture folder)
8b61f9abbf5b7db3aae302f086038f02d8b57713822d4341a86993a4824ffa9c  ../godseye/godseye_server.py (the evidence endpoint matches the approach id as well as the time (two levels approached at one instant no longer swap evidence); MROF-GODSEYE-SERVER-1.0; supersedes 775e412f… — serves replay windows one (session, instrument) piece at a time, at most four held; re-reads the exposure ledger when it changes; --open opens the browser once listening; --refresh N re-runs the export every N s as a separate below-normal-priority process (the launchers use 300); Amendment 14. Earlier: stdlib HTTP on 127.0.0.1; policy re-checked on every replay request; stale after 15 min; last good snapshot kept)
b0aaf0743b2f87c3661bfeaa9fc02caeb24b6c81da6dafd650e97147f9588de1  ../godseye/godseye_demo.py (MROF-GODSEYE-DEMO-1.0: labelled synthetic capture + reports through library entry points only; its own ledger, inside the demo folder)
3791e3ad53aa37436c9a6e7badc54500c448212bed7ebcccdef69c0e9ac3152d  ../godseye/tests_godseye.py (46 tests, G1–G14c + G8f; supersedes 041eaffd… — G14c no re-read of a known-unreadable file; earlier a264c7de… — G14 the unreadable-file verdict reaches the page, alerted, capture untouched; G14b shared-gap alerts capped; earlier edc2d6bf… → G12e reconstructed-only sessions complete and labelled, G13–G13d the replay split, the server's bounded pieces and ledger re-read, the launcher, the refresher; earlier 3d2d5111… → G11–G11d theatre scripts vs the frozen code, G12–G12d study progress, clock, runway)
23517ae39a7fbb6a7cb4a271c858057e2c02033105fefaa9f9beb870179ee39a  ../godseye/static/app.js (supersedes a19771cc… — alerts name a run the drive cannot read and cap shared-gap warnings at the five largest plus one summary line; the orphan table shows the unreadable file; replay level labels drawn over the candles on a dark box; earlier a19771cc… → the page sends the approach id with every evidence request; earlier 44bfe9ea… → the progress rail names sessions relying on reconstructed manifests; earlier 0fd3a368… → progress rail, schedule-aware alerts, runway, watchdog notifications, funnel bars)
c0d29207c0b283751bd38e5b4c614b3f4e86025c4b0c09ae3e9f40ac8a0a27e3  ../godseye/static/theatre.js (the Mechanism theatre view and keyboard shortcuts; Amendment 13)
b65447cb56b2ef6e8067095adf094413f4ffc5094c450771b530577021fd7c69  ../godseye/static/index.html
c3dd56058931c0f773d15648e5de1ce659c722d390d81a99ff6c87063c3e44a3  ../godseye/static/style.css
ea11ca5285b42825ad3f272b38a3903274849d3713aefa3a1fe5e7a4752c8762  ../godseye/GODS_EYE_README.md (architecture, permission model, setup, the four views, blind enforcement, discrepancy record, adapters, verification, blockers, user guide)
8169159cbf3444a82bc59538d6053fc4c693606c7d4c6f7f73e811f42fb635f6  ../godseye/launch_godseye.bat (supersedes a3cf2105… — the server opens the browser once listening instead of racing it; reviewed, not executed: no Windows here)
6d52566b3cd6dcc310517733fc94b4cdc355beecd10fe3ff7260082040420b36  ../godseye/export_godseye.bat
8799ff3dc698a7f2a186be1dc18c3c35e1697bce554f350b9f77f74ca17fd21e  ../godseye/godseye.config.example.json
ec8366a0e493efe33963a227bda8084e9f5a1e7123de66687b6881387d511c00  ../godseye/pinokio/pinokio.js (optional Pinokio launcher, dashboard only; NOT exercised here — no Pinokio)
31526b3cee7dfe325758e4eb321134897a1f52232cd4094d73581e58df480b3f  ../godseye/pinokio/install.js
e89a18767df0469c2c15262f90937e19a9577f453b9070cfc63064829fa118c1  ../godseye/pinokio/start.js
451a3544e1a854195bdb62b247186cfc15eaf70aedc49a9d0b270f63f537eb83  ../godseye/pinokio/stop.js
8d1b123206885250b9a9b21951b58e37ed318fd0d2f93656c91926135b097e16  ../godseye/pinokio/export.js
```

Modified (one file, additively — a skip path, observation hooks and a
run-id field):

```
280ad72892ec992a36cf6762d45580a3608095bc9914ee6b301452cc540710af  mrofyt_runner.py (MROF-YT-RUNNER-1.2.2; supersedes 86180aec… — reads a capture spanning two folders as one study in session order (a run present in both is read once and named), Amendment 23; earlier MROF-YT-RUNNER-1.2.2; supersedes 228d48c6… — a stat() refused in the size pre-flight is that run's IO_ERROR skip (or a STOP when the folder is gone), not a TypeError: the call lacked its wind-back argument since the 9/19 merge, Amendment 22; earlier MROF-YT-RUNNER-1.2.2; supersedes a382df95… — the quote fields are assigned in their own order (st.ask held the bid size and st.bsz the ask price; nothing read either, so no result changed), Amendment 20; earlier MROF-YT-RUNNER-1.2.2; supersedes a4a518b7… — a folder with manifest files that gives no plan stops with a count and the reasons (unreadable, other instrument, other schema) instead of "wrong folder", Amendment 19; earlier MROF-YT-RUNNER-1.2.2; supersedes 10485b66… — every row-decoding failure is CORRUPT_STREAM, and an abandoned run -- corrupt row or device error -- is wound back whole, Amendment 15; earlier supersedes c48dfe9e… — a capture folder that cannot be read, or stops answering mid-pass, STOPS the pass with no ledger; a read error on one run while the folder answers is that run's IO_ERROR skip; a run carrying both the recorder's manifest and a reconstructed one is ingested once; Amendment 11. Earlier c48dfe9e…: two no-op observation hooks for wave two; 99c9b277…: truncated/corrupt streams skipped whole; earlier: retroactive disconnect-gap correction. See REVIEW_PACKAGE_MANIFEST_v12.md)
eeb866c96f064519c34c35ef68981a2effd7db9cf4406800ae4b92e83fc04bdb  tests_mrofyt_runner.py (39 tests; supersedes 5b81b237… — R19 two folders read as one; earlier 38 tests; supersedes e01bf9b1… — R18–R18b the refused size check; earlier 36 tests; supersedes 0eb00b3b… — R17 the quote fields; earlier 35 tests; supersedes a8737602… — R16–R16b the stated no-plan reason; earlier 33 tests; supersedes 8ea5c6be… — R13f–R13j merged, R15e, R15b/R15c inject at the row-reading boundary; earlier supersedes 51e08e10… — R15–R15d)
f21c6f66a0f07e58b8e71af173e6acd6c43b1ef74e66343314739cc0ace43dff  tests_mrofyt_ingest.py (69 tests; merged from the 9/19 parallel session: adapter parse, merge and pairing paths; G6 ages its partial, Amendment 15)
146802326c487518dafab38dd8395fd51dad2bd674115ccba7b1a460d68706ba  RUNNER_GUIDE.md (merged from the 9/19 parallel session: how to run the outcome-blind ingest runner; brought up to runner 1.2.2 on merge -- IO_ERROR, STOPPED on an unreadable capture, the wider CORRUPT_STREAM catch and the wind-back)
a0db13fcd5b083706fb74d7ead792674949c895accafc7ad3a8a20f1fe5d965d  mles_v12_audit.py (supersedes 1159f125… — one capture may span two folders ("D:\\MLES_Capture;E:\\MLES_Capture"): audited as one, a run present in both audited once and reported, one folder gone is the capture gone, Amendment 23; earlier supersedes 6b522644… — discover_manifests enumerates with os.listdir and raises CaptureUnavailable with the Windows error when the listing fails, never an empty list (glob swallowed a cut-short listing on 2026-10-03 and three tools read it as the wrong folder), Amendment 19; earlier supersedes 003f03b8… — `--out FILE` writes the audit report as JSON for the dashboard, Amendment 12; no rule changed. 003f03b8…: a run still being recorded is OPEN, not failed; damaged originals kept beside recovered copies are KEPT, not failed; unreadable capture stops the audit; per-build disconnect evidence says whether the 1.2.2 repair was exercised or merely not contradicted; Amendment 11. See REVIEW_PACKAGE_MANIFEST_v12.md)
2cbb2a07ea1809f895c8ed96fb942c4bd481bdcbd4f72b299bf6d4a8add920f0  tests_mles_v12.py (56 tests; supersedes c50f7573… — T37 two folders audit as one; earlier 55 tests; supersedes 1c9b8973… — T36 the cut-short listing; earlier 54 tests; supersedes 665b0a06… — T30c, T34–T34c, T35–T35b; T30's orphan fixture is now aged, because a file written a second ago is what a live run looks like)
cdf6d14cfd324225340795932eac96c830e4eb936a3d7dee686141fd9e6fd534  NT8_RECORDING_RUNBOOK.md (supersedes 1c47b9c9… — §8 names the dashboard and the `--out` files it reads; earlier: §8 lists the wave-two command)
```

The pilot line above (51c2996f…) is superseded in Amendment 12 by:

```
b598a10e9b7790c46462f85c8a3f5114c4d913b21100b0e4bc10ed9444204381  mrofyt_pilot.py (MROF-YT-PILOT-1.2; supersedes 2b6efce2… — merged 9/19 work: PilotRunner winds its own observation buffers back with an abandoned run, Amendment 15; earlier supersedes f81c6b14… — a window keeps the level snapshot only when its session is not blind (the validation sessions grow weekly and are never written); Amendment 14. f81c6b14… supersedes 51c2996f… — `--windows-out FILE` writes the decision windows of EXPOSED sessions only (MROF-PILOT-WINDOWS-1) for the dashboard's replay, and each window record carries the approach id, side and the runner's levels; no detector, threshold, level, window, baseline or feature definition touched — P10d re-pins the frozen signal hash; Amendment 12)
eee416353fd6b94f932fee21f5d0368f186e4ede75a1e15bcb8b4fd625113e44  mrofyt_costs.py (MROF-YT-COSTS-1.0: what a mid-to-mid path result keeps after commission, spread and stop slippage, every event and one position at a time, with a spread x slippage sensitivity grid; accounting, never a rule; Amendment 25)
fd1755fb3607509b0d3e06dc8c6d6dc4e3712d7b23c74801567efde10bd6d192  mrofyt_risk.py (MROF-YT-RISK-1.0: drawdowns, losing streaks, bad days and contracts for a risk budget, resampled from the trades one account could take, in three scenarios -- as sampled, half the edge, no edge -- and sized on the half-edge one; a sample with under 20 trading sessions is flagged; Amendment 25)
8799e95096901f05d71b6e3cb86a2c4ad392465419b1e39eb7a7a3baea43b1b8  tests_mrofyt_costs_risk.py (15 tests: the cost and path arithmetic, the daily stop, the scenarios, the seed, streaks beyond the recorded days, sizing, and the frozen DEV report reproduced; Amendment 25)
43513abb03041ca34b426ad82fc434ed49997cef2dfb26b3e2765b1ee8180426  mrofyt_exitstudy.py (MROF-YT-W5-EXIT-1.0: wave five, when a winning run is ending -- eight tape signs against a plain 10-point trail on every 20-point run of the DEV tape, Holm over eight, at most three nominated; and the half-life curves 5 s .. 3 h of every wave-one and wave-three family; DEV only unless --evaluate --unblind; wave four's runner, hooks only; Amendment 25)
755d5e9c574a661cc7da557f24db7810db5c3bcbf5762539e68f1457ae9ea460  tests_mrofyt_exitstudy.py (19 tests: the trail against a re-implementation, the run state, each sign, a planted exit edge found and noise rejected, the cooldown, the unblind refusal, causality under a cut tape, the abandoned-run wind-back, evaluate's two modes and the ledger, the half-life curve by hand, wave-one ledger identity and the frozen hash; Amendment 25)
3bcd8c642dc8cf478d81cdd611bc594245dc489e95d8923696c2c3d1be6299b8  MROF_YT_WAVE5_EXIT_REGISTRATION.md (FROZEN 2026-10-26 before any recorded session was read by it; Amendment 25)
708c38efec9338ac2f8748f8920bcf5153772f63f5e4ac995d2dd0c60009d5df  mrofyt_context.py (supersedes 09bf75a6… — the stamp check ranks only minutes at or above half the peak average volume, so a thin minute with a sharp jump cannot outrank the cash open; BOM-tolerant reading; one parsing loop shared with mrofyt_smt; a Tick export stops with that reason, Amendment 27; earlier MROF-YT-CTX-1.0: long, short or neither by 10:30 ET from NinjaTrader minute exports -- 13 features, 676 rules, month-clustered t, Benjamini-Hochberg; searched on 2019-06-01 .. 2026-06-30, judged on every session before 2019-06-01, which no study in this repository has read; each mode drops the other's bars unread; nothing from 2026-07-01; Amendment 25)
7fbdefccf00b7a618788402aa21cf62c32177fabd7037f943913162f9a7a321a  tests_mrofyt_context.py (21 tests; supersedes fc334024… — X6a the peak filter of the stamp check, Amendment 27; earlier 20 tests: both DST regimes, end-of-bar UTC stamps, contract names, the value area, a day's statistics, the stamp check and its two refusals, the front contract and the same-contract gap across a roll, a planted context edge found and the noise rate bounded over 40 datasets, the split never crossed, the July 2026 refusal, evaluate's two modes, causality; Amendment 25)
55539749c0d916c6035b443c125fb5e41a4e445bc1235f837c3334486372aed5  MROF_YT_CONTEXT_REGISTRATION.md (supersedes 2a62f740… — §1 and §10 state the stamp check's peak filter, a precision of the implementation made before any real bar was read, Amendment 27; FROZEN 2026-10-26; Amendment 25)
9a2aca7a98aa2237dafc1520e51a993bcb48be872ec8954bc32f5d177adefb2e  mrofyt_levelbreak.py (MROF-YT-W6-LEVELBREAK-1.0: wave six part A -- L2 with a fixed, a STRUCTURAL and a FLOW-INVALIDATION stop, L4, and L2 filtered by TRAPPED volume, net of costs, Holm over five; DEV describes, a replay holdout folder (sessions before 2026-09-01 only) or the --unblind checkpoint judges; wave three's runner, hooks only; Amendment 26)
1e2a0b8a6696c4b5be78dd5a16e9ffe61d2022755e1133972e6b45f9f22a4737  tests_mrofyt_levelbreak.py (11 tests: the path exit against wave three's reference scan, the structural stop, the flow invalidation, the trapped-volume hook, end to end with a suite-only plumbing detector, the trapped filter, evaluate's modes, the holdout folder rule, wave three unchanged, the wind-back; Amendment 26)
24ce2cc539a662ce34fdf8ede80e718b2b548144ebf3fe2e3cf0e7ff8ee7c212  mrofyt_smt.py (supersedes d518956b… — reads through mrofyt_context's parsing loop (an aggregator class, no second copy of the loop), Amendment 27; earlier MROF-YT-W6B-SMT-1.0: wave six part B -- NQ failed and held breaks of yesterday's high and low on minute bars, ES confirming or not, four fixed tests, month-clustered, Holm; read on 2019-06 .. 2026-06, judged on the years before 2019-06-01; Amendment 26)
d1d50f8506448287dada036d413f60ab162bf25fe12f2740752d548b2714cd64  tests_mrofyt_smt.py (6 tests: events, ES timing, the outcome, the clustered difference by hand, a planted edge found and the noise rate bounded, the split end to end; Amendment 26)
bfb34438a90a5335df8a2265bced46d51ff40acf8bf560b7f16595249a69993b  MROF_YT_WAVE6_LEVELBREAK_REGISTRATION.md (FROZEN 2026-10-26 before either tool read real data; Amendment 26)
d25b41dd81c82e6574bf9ba7452b98a16f47d1f324cfc8ab72bcc218d0eb2cbc  mrofyt_flowlevels.py (MROF-YT-W7-FLOWLEVELS-1.0: wave seven -- failed and held breaks of the levels the order flow builds every day (one-minute swing highs and lows, absorption prices, yesterday's value area), graded A+ / A / B / skip on five order-flow points, with a structural stop and four exits: the next level ahead, a tape exit with no target, half and half, and the original 25 / 15; nine tests, net R after costs, one position at a time, Holm over nine; DEV describes and freezes two cuts, a replay holdout folder (sessions before 2026-09-01 only) or the --unblind checkpoint judges; wave four's runner, hooks only; Amendment 28)
02e2922721070580af1e51d4ce53ac606c5b19b092c509cf454d11f543eb9e01  tests_mrofyt_flowlevels.py (20 tests: the search tree against a brute-force scan, swing / absorption / value-area levels and merging, FAILED and HELD by hand with their stops and trapped volume, which way a level breaks, fresh and absorption, the grade and confluence, E1's target rule, the bracket, the tape exit sign by sign, E2 / E3 / E4, costs and the hybrid's halves, one position at a time, the grade slope on planted and flat data, end to end, evaluate's modes, the holdout folder rule, wave four unchanged, the wind-back; Amendment 28)
c59c4a02e5d8e1124ab7ae7276ba362f8e4243b963f3f6cc29d4f2da7c99f63f  MROF_YT_WAVE7_FLOWLEVELS_REGISTRATION.md (FROZEN 2026-10-30 before the tool read real data; Amendment 28)
7773c52c771a6ef2ec66fd92aec6b633a7a933f999f7148ad6bb103d967ecf50  mrofyt_l2variants.py (MROF-YT-W8-L2VARIANTS-1.0: wave eight -- wave six's L2 trades restricted to the first test of the level that session (V1), the 09:30-11:30 ET window (V2), both (V3, the operator's pick), or held at most 5 minutes (V4); every L2 (wave six's T1) beside as the reference; net of costs, session-clustered, Holm over four; nothing frozen from DEV; a replay holdout folder or the --unblind checkpoint judges; wave six's runner, hooks only; Amendment 30)
657cac9741b66a043e79bf91420f82de53f6d4608a9a496113254d104ec59723  tests_mrofyt_l2variants.py (7 tests: the per-level test count, the variant rules and window edges, the 5-minute exit, end to end with wave six's suite-only plumbing detector, the holdout folder rule, wave six unchanged, the wind-back and the registration; Amendment 30)
dd79fdbb059236200a87088d178c606c9b01baa3a83ec20f2d2a88d3fde85ec3  MROF_YT_WAVE8_L2VARIANTS_REGISTRATION.md (FROZEN 2026-10-31 before any held-out session was read; Amendment 30)
```

Frozen DEV results (Amendment 24; shipped in the package from V26 because `tests_mrofyt_costs_risk.py` reproduces them):

```
e881a5bf9f9f72c201f7dd941cf9713713d7033c5452e2fba19e7bccbd72881a  MROF_YT_W3_W4_DEV_FREEZE.md (waves three and four on DEV, committed before any validation read: wave four's hypothesis set and wave three's carried pattern)
88a7caf41cd48e4a5440f3d4c8cd3ffb2ee9f61988b07a3f892015bdd1a92dad  frozen_dev_20261024/w4_nominated.json (the file --evaluate reads at the checkpoint; five LEAD rules with their numeric cut-points)
193ff50f5efc3dc96fac9ca15ee4305d9d84fb215d79a9c9e4913d4131e46252  frozen_dev_20261024/w4.json (the operator's wave-four search report)
18a576a8e787dae311ef0737b56d314e8e0ca57b3bdd9eca102bf75fef6859ac  frozen_dev_20261024/w3.json.gz (gzip -9 -n of the wave-three real-level report d37309f7…, 29 MB uncompressed)
```

Frozen DEV cuts of waves six and seven (Amendment 29; in the repository, read by `--evaluate` on held-out sessions):

```
d09cef66ac9d84a2f3df2713973990a19b6bd0ed8cfa8dd5d1426faee71d5689  frozen_dev_20261031/w6_frozen.json (wave six A4 trapped cut: NQ 0.0, MNQ 0.0)
030ee8bb3f7815ec6bd560a551615298060d812abb33101451eb32685cf798d3  frozen_dev_20261031/w7_frozen.json (wave seven trapped medians and |D| 90th percentiles)
8acd658e36af878de088dae9aed7f78de9d7389e4b2eb35084a850f6703254a2  MROF_YT_W6_W7_DEV_FREEZE.md (the DEV runs of waves five to seven, the sessions read and refused, the frozen files, committed before any held-out read)
```

Archived source directives:

```
55d598a3c2e5453b9c47675f76932455dca8689084fddfd4535e5b4907def942  ../../docs/prompts/MROF_ONE_COMPLETE_CLAUDE_PROMPT_1.md
b2a0122b40e6ef140a1cb6fe7011068bfa3cc52039a75b19da54c9fc1e7ae389  ../../docs/prompts/MROF_GODS_EYE_VIEW_CLAUDE_PROMPT_PINOKIO.md (the dashboard directive, Amendment 12; archived from the upload as it was read — 166 lines — so the hash is of this archived copy)
```

Delivered package (140 files, repo layout preserved so every suite runs
from inside it unchanged):

```
edf699bcdd46bc7bc6b6678b4af0e623f145c6f568ca7002b41e0b0a206ab9f3  MROF_V1_Engine_v01_6_7.zip (supersedes fd06d259… — wave seven: order-flow levels graded A+ / A / B / skip with four exits, its registration and 20-test suite; 140 files, Amendment 28; earlier fd06d259… supersedes 3e934e75… — the context stamp check's peak filter and the shared parsing loop, after a review of V26–V27; 137 files, Amendment 27; earlier 3e934e75… supersedes c69b017e… — wave six: the level-break stops, L4 and trapped volume on the recordings, ES confirmation on minute bars, their registration and suites; 137 files, Amendment 26; earlier c69b017e… supersedes 98bc03c1… — context, exit, cost and risk tools with their registrations and suites, and the frozen DEV results their suite reproduces; 132 files, Amendment 25; earlier 98bc03c1… supersedes ae0f7cf3… — one study across two drives; 119 files, Amendment 23; earlier ae0f7cf3… supersedes f4529847… — the runner's refused size check skips or stops instead of crashing; 119 files, Amendment 22; earlier f4529847… supersedes 4f35d37c… — waves two to four wind an abandoned run back whole; wave two 1.1; 119 files, Amendment 21; earlier 4f35d37c… supersedes f466ee1b… — wave four: the counted search, its registration and 16-test suite; direction-matched baselines in waves three and four; the runner's quote fields; 119 files, Amendment 20; earlier f466ee1b… supersedes 64002e08… — a cut-short folder listing is a stop with the Windows error, never "no manifest"; the runner's no-plan stop states its reasons; 116 files, Amendment 19; earlier 64002e08… supersedes 5285925c… — wave three: the big-move registration, mrofyt_bigmove.py and its 27-test suite, 116 files, Amendment 18; earlier 5285925c… supersedes 092a62e0… — recover 1.6: a file Windows will not date is set aside instead of stopping the dry run, 113 files, Amendment 17; earlier 092a62e0… supersedes 14adcbf4… — recover 1.5: progress per run, oldest session first, a stop that names the drive, the folder or the refused step, the check file before any bulk read, earlier-pass manifests checked, recorder-only declarations, 113 files, Amendment 16; earlier 14adcbf4… supersedes 9a8bce6c… — the 9/19 parallel-session work merged: runner 1.2.2 decode-failure catch and wind-back, the ingest suite, the run guide, 113 files, Amendment 15; earlier c5f652c5… — a known-unreadable file is not re-read; earlier 416beef6… — unreadable-file verdict on the page, capped shared-gap alerts, legible replay level labels; earlier 694c6367… — replay evidence matches the approach id; earlier 2fa33aed… — recover 1.4 bounded reads; earlier f930879f… — recover 1.4 unreadable-file guard; earlier f930879f… — Amendment 14: replay split, recover 1.3 free-space guard, reconstructed-session completeness, pilot level trim, launcher open/refresh; earlier 4e67cd09… — God's Eye 1.1: the Mechanism theatre, study progress, runway, Amendment 13; earlier 108325dd…: adds analysis/godseye/ (19 files) and the archived dashboard directive, Amendment 12; earlier 15852c89…: recover 1.2 asks Windows, stop-never-report guards, auditor OPEN/KEPT/repair evidence; earlier 5b8e8ceb…: recover 1.1 refuses live runs; earlier ae256920…: wave two as code (mrofyt_wave2.py + suite), runner hooks, 90 files; earlier 3d34a1cb…: instant --dry-run; earlier: adds mrofyt_recover.py; earlier: pilot 1.2 validation blind + bootstrap intervals, auditor churn-after-BOOK_READY rule; earlier: truncated/corrupt-stream guard and the wave-two registration; earlier: pilot 1.1, recorder BOOK_READY repair, depth-completeness guard, retroactive runner correction. This file ships inside the zip it names, so the in-zip copy records the preceding zip hash by construction; hash the delivered artifact against the value here, not against its own embedded copy.)
```

```
cd analysis/mrofyt && for f in tests_*.py; do python3 "$f" | tail -1; done
cd ../godseye && python3 tests_godseye.py | tail -1
# run from inside the unzipped package: 738/738 + 46/46, identical to the repo
```

## Predecessors — reverified unmodified

```
74ff9a99e468e22326dad9e01e4ee4dc7ab90c8da7e330a6b5f9e70e9eecb91b  MROF_YT_OF01_FINAL_SOURCE_PROMPT.md
b753a09cc077267a935df37f9b531f2179d920b8f76dc6ee5788628c264f7194  MROF_YT_OF01_5_SUCCESSOR_FREEZE.md
e3da36cd63a18a22935124e852ce8f8b785e96df136d98944f7e88654b1c6847  mrofyt_engine_v015.py
```

Reverified in-suite by `tests_mrofyt_v01_6.py::B19` and
`tests_mrofyt_v01_7.py::C12`, so a predecessor edit breaks the build.

## Reproduce everything

```
cd analysis/mrofyt
for f in tests_*.py; do python3 "$f" | tail -1; done
```

| suite | result |
| --- | --- |
| `tests_mles_v11.py` | 29/29 |
| `tests_mles_v12.py` | 56/56 |
| `tests_mrofyt.py` | 59/59 |
| `tests_mrofyt_pilot.py` | 45/45 |
| `tests_mrofyt_runner.py` | 39/39 |
| `tests_mrofyt_ingest.py` | 69/69 |
| `tests_mrofyt_v01_1.py` | 56/56 |
| `tests_mrofyt_v01_2.py` | 31/31 |
| `tests_mrofyt_v01_3.py` | 32/32 |
| `tests_mrofyt_v01_4.py` | 25/25 |
| `tests_mrofyt_v01_5.py` | 36/36 |
| `tests_mrofyt_v01_6.py` | 21/21 |
| `tests_mrofyt_v01_7.py` | 15/15 |
| `tests_mrofyt_recover.py` | 51/51 |
| `tests_mrofyt_wave2.py` | 30/30 |
| `tests_mrofyt_bigmove.py` | 28/28 |
| `tests_mrofyt_discover.py` | 17/17 |
| `tests_mrofyt_exitstudy.py` | 19/19 |
| `tests_mrofyt_costs_risk.py` | 15/15 |
| `tests_mrofyt_context.py` | 21/21 |
| `tests_mrofyt_levelbreak.py` | 11/11 |
| `tests_mrofyt_smt.py` | 6/6 |
| `tests_mrofyt_flowlevels.py` | 20/20 |
| `tests_mrofyt_l2variants.py` | 7/7 |
| **wave-one to eight, tools total** | **738/738** |
| `../godseye/tests_godseye.py` | 46/46 |
| **package total** | **784/784** |

## Runnable research commands

```
python3 mles_v12_audit.py  "<capture folder>"                      # integrity
python3 mrofyt_runner.py   "<capture folder>" --out ledger.json     # outcome-blind
python3 mrofyt_pilot.py    "<capture folder>" --out pilot.json      # §8A diagnostic
python3 mrofyt_recover.py  "<capture folder>" --dry-run             # orphaned runs (instant); runs the recorder holds listed apart
python3 mrofyt_recover.py  "<capture folder>" --repair              # rebuild manifests — safe with NinjaTrader running; do it on a weekend anyway (I/O)
python3 mrofyt_wave2.py    "<capture folder>" --both --out wave2.json  # wave two, real + placebo, blind
python3 mrofyt_bigmove.py  "<capture folder>" --both --out w3.json     # wave three big-move search, DEV sessions only, real + placebo
python3 mrofyt_discover.py "<capture folder>" --out w4.json --nominated-out w4_nominated.json --w3-out w3.json  # wave four counted search + wave three real, one read of DEV
python3 mrofyt_exitstudy.py "<capture folder>" --out w5.json --nominated-out w5_nominated.json  # wave five exit study + half-life curves, DEV only
python3 mrofyt_costs.py    w3.json                                   # costs charged to the Holm survivor(s), one position at a time
python3 mrofyt_risk.py     w3.json --daily-stop 40 --account 50000   # drawdowns and sizing in three scenarios
python3 mrofyt_context.py  "<folder of NQ minute exports>" --out ctx.json --nominated-out ctx_nominated.json  # context search, 2019-06 .. 2026-06 only
python3 mrofyt_levelbreak.py "<capture folder>" --out w6.json --frozen-out w6_frozen.json  # wave six A on DEV: describes, freezes the trapped cut
python3 mrofyt_smt.py      "<folder of NQ and ES minute exports>" --out smt_dev.json       # wave six B, 2019-06 .. 2026-06 first look
python3 mrofyt_flowlevels.py "<capture folder>" --out w7.json --frozen-out w7_frozen.json  # wave seven on DEV: describes, freezes the two cuts
python3 mrofyt_l2variants.py "<replay folder>" --holdout --out w8_replay.json  # wave eight on the replay holdout (nothing to freeze first)
```

All of them stream at flat memory. `mrofyt_runner.py --outcomes` and
`mrofyt_exits_v017.research_driver()` both raise `STATE-C LOCKED`.

## Read-only no-order proof

```
grep -nE "SubmitOrder|ChangeOrder|CancelOrder|EnterLong|EnterShort|ExitLong|ExitShort" \
     mrofyt_swings_v016.py mrofyt_engine_v016.py mrofyt_exits_v017.py \
     mrofyt_pilot.py mrofyt_recover.py mrofyt_wave2.py \
     mrofyt_exitstudy.py mrofyt_costs.py mrofyt_risk.py mrofyt_context.py \
     mrofyt_levelbreak.py mrofyt_smt.py mrofyt_flowlevels.py \
     mrofyt_l2variants.py
# -> no matches outside header comments documenting the prohibition
```

Enforced in-suite by `B18` and `C12`, which strip comments before
scanning, and by `W7` for the wave-two module (which additionally
forbids any fill / stop / target / simulate / P&L call).

## NOT performed here

Real NinjaTrader F5 compilation; Market Replay or live smoke testing;
any market-outcome study. This environment has no NT8, Windows or live
feed. **A stub compile is not an API validation.**

Classification: **`IMPLEMENTATION_COMPLETE` / `INSUFFICIENT_DATA` /
`MARKET_RESEARCH_NOT_RUN` / `PROSPECTIVE_VALIDATION_NOT_STARTED`.**

## Amendment: two integrity repairs (2026-09-13)

Recorded in full in `REVIEW_PACKAGE_MANIFEST_v12.md`; summarised here
because both change files this package ships.

```
ce1e475a37bcad14e4e7ea10228feaea9a561c6ea4d0181e54077774fdebc060  ../../src/MlesV12CaptureHost.cs (build 1.2.2)
1f264e3b54646c5d474107ed38c25072bed7fd95865bad2a669c00a8dfdb9a6f  mles_v12_audit.py
3d8812b9d286b754bdd01050f4714c3dea1de13c5d59e27a5274903fc180c405  mles_v12_harness.cs
665b0a06d3079c23fd55691f9e361e64573d62ee434f1d277ac5896b94da56fa  tests_mles_v12.py
```

1. **Recorder: spurious `BOOK_READY` after a disconnect.** The gate
   maxima were not reset when the book was invalidated, so the next
   depth row re-emitted `BOOK_READY` with no resync — and
   `mrofyt_runner.py` re-armed on it. Pinned by `T31`. **Needs a real
   NinjaTrader F5 recompile to take effect.**
2. **Auditor: `MISSING_DEPTH_ACTION` had no minimum-row guard**, so
   near-empty runs (a closed market, a few seconds before shutdown)
   failed a completeness claim they could not support. Pinned by `T32`
   and `T32b`. Analysis-side only, no recompile.

The lifecycle harness gained a depth row inside the disconnect gap —
its absence is precisely why defect 1 survived the suite.

3. **Runner: pre-repair recordings corrected retroactively.** The old
   recordings still carry `DISCONNECTED` on every gap row and no resync
   before the spurious ready; the runner now honours both, counts what it
   ignored, and prints the counts in its summary. Analysis-side only.
   Pinned by `R12`–`R12d`. Nothing captured is missing or altered.

4. **`RecorderBuild` bumped to 1.2.2.** The disconnect repair changes
   which quality events a run emits, so it had to be distinguishable in
   the manifest; it was first committed without the bump. `T33` now binds
   the repair and the build together. A `1.2.1` manifest means "may carry
   spurious post-disconnect `BOOK_READY`, runner correction applies".

   **Installing the recorder is two steps:** copy the `.cs` into
   `Documents/NinjaTrader 8/bin/Custom/Indicators/`, *then* press F5.
   F5 alone recompiles whatever is already there.

## Wave two — registered blind, 2026-09-18

`MROF_YT_WAVE2_REGISTRATION.md` (DRAFT, pending operator sign-off) records
the second-wave hypotheses **before** the data that will judge them
exists. Wave one is untouched and keeps running blind to the December
checkpoint; wave-two code, when written, lives in new modules.

The split that makes it meaningful: sessions `<= 20260918` are exposed
DEV and informed the design; sessions `>= 20260921` are untouched and are
the only data the wave-two verdict may be read from.

Design in one line: six families become **two that can actually fire**
(A1 with replenishment redefined to observe every grid tick, and A4
registered honestly as the degraded version that produced all 65 events),
plus `W2-A4-OPEN` where the mechanism is structurally forced, a placebo
level arm, a candle-only arm, a `CAUSAL_SWING` level comparison, and a
`aggrConf == HIGH` robustness variant that measures the inferred-aggressor
weakness instead of assuming it away. A2, A3 and A5 are dropped with
reasons from the funnel, not from outcomes.

`P10`–`P10e` bind the document to the code it references, so the
registration cannot go stale silently, and `P10d` re-pins the wave-one
detector hash so registering wave two provably changed nothing.

5. **Runner: a truncated or corrupt stream no longer kills the pass.**
   Two files copied while the recorder was writing ended mid-row and
   would have crashed a multi-hour run with no ledger written. The
   runner now checks each file's size against its manifest before
   ingest (skip whole as `STREAM_SIZE_MISMATCH`) and catches in-stream
   corruption as `CORRUPT_STREAM`, resetting run state so nothing
   partial survives. Pinned by `R13`-`R13e`. Never copy the capture
   folder while recording.

6. **Pilot 1.2: the validation blind, and the interval the kill criterion
   needs.** Registering wave two created a hole: the weekly wave-one
   pilot would have read markouts on -- and labelled `EXPOSED_PILOT_DEV`
   -- the very sessions the registration declares untouched, and
   `W2-A4r` is A4 as it ran. The pilot now withholds every markout for
   sessions `>= BLIND_FROM = 20260921` by default (events are counted so
   accrual stays visible), labels them `VALIDATION_BLIND_MARKOUTS_WITHHELD`,
   and unblinds only on an explicit, loud, permanent `--blind-from none`.
   Exposure is monotone: blind may become exposed, never the reverse.
   Also added: a seeded percentile-bootstrap 95% interval on every
   markout population (what §7's "interval includes zero" reads; none
   below five events), and the skip-reason and book-integrity counters
   in the report and summary. Pinned by `P11`-`P11k`; `P11k` binds the
   date and label to the registration text.
7. **Auditor: depth completeness is asserted on churn after `BOOK_READY`.**
   A 228-row restart stub still tripped the first floor because ~60 of
   its rows were the book being built, when only ADDs can occur. Rows
   are now counted after the run's first `BOOK_READY`; a run that never
   reached it built no book and can support no completeness claim.
   Pinned by `T32c`/`T32d`.

8. **`mrofyt_recover.py`: manifest reconstruction for runs killed before
   finalizing.** An ungraceful termination (power loss, forced reboot)
   stops the recorder before its finalizer writes the manifest. The CSVs
   survive, often complete, but the manifest IS the authoritative
   entrypoint for both the auditor and the runner — so the data is
   invisible to every downstream tool. The first fourteen-session
   capture had one such run on **every day of a week**.

   The tool rebuilds a manifest from the rows. Three refusals are built
   in, and they are the point of it:

   * **Originals are never modified.** A damaged stream is rewritten as
     a new `_RECOVERED.csv`; the damaged file stays exactly as it is.
   * **The recorder's self-reported integrity counters are never
     invented.** `gaps`, `duplicates`, `droppedRows` and the rest are
     the recorder's own account of what it saw; nothing in the rows can
     reveal them. Writing `0` would assert "no rows were ever dropped",
     the one claim that cannot be made, so they are **omitted**.
   * **A reconstructed manifest cannot validate its own file.** Its
     hashes, counts and sequence bounds are computed from that file and
     match by construction. The auditor now says so —
     `RECONSTRUCTED_RUN_NOT_SELF_VERIFYING` — instead of either a pile
     of `MISSING_COUNTER` noise or an unearned clean pass.

   A damaged run is truncated to one **common** eventSeq across all four
   streams, constrained only by the damaged ones: rows beyond a cut-off
   stream describe a world it can no longer account for, and merged they
   would advance quotes past the last depth update and freeze the book.
   An undamaged run is not cut at all — its streams legitimately end at
   different sequences. Pinned by `V1`–`V6` (18 tests), including that
   the recovered run becomes ingestible, that originals are unchanged by
   hash, and that a run missing a whole stream is refused rather than
   papered over.

   `--dry-run` probes only each file's header and last 64 KB, never the
   middle, so answering "what is recoverable here?" costs the same on a
   6 GB depth file as on a small one and reports total recoverable GB
   plus a per-stream verdict. The first implementation scanned every row
   even for a dry run, which made that question a 30-minute operation on
   a real capture folder. `V7`-`V7c` pin the cheapness by counting bytes
   actually read.

9. **Wave two as running code (2026-09-21).** `mrofyt_wave2.py`
   (MROF-YT-WAVE2-1.0) implements the registration's families, the
   candle-only arm B and the placebo arm C, with the §4.3 CAUSAL_SWING
   comparison declared `not_in_this_version` rather than half-built.
   The registration's §11 records exactly what each family became and
   where implementation had to be more precise than the prose (arm-B
   decision instant, placebo seed rule, the residual model's minimal
   first-wave form). No hypothesis parameter was changed.

   How wave one stays untouched: the module subclasses the pilot runner
   and reads only two new **no-op** observation hooks on the frozen
   runner (`_on_trade_event`, `_on_depth_event`, carrying the full
   adapter event after the frozen handling has run). `R14b` pins that
   the base runner's ledger is unchanged by their presence; `W5c` pins
   that the wave-one ledger the wave-two runner emits — fires, totals,
   feature counters, sessions, baselines, regimes — is byte-identical to
   the pilot's on the same seven synthetic sessions, and that the
   comparison is not vacuous; `W7b` and `P10d` re-pin the frozen signal
   hash.

   What the suite proves and what it does not: `W1`–`W1f` prove each
   wave-two detector IS the frozen one with a single input swapped or
   one threshold parameterised (2,000 random inputs for `W2-A4r == A4`);
   `W4`–`W4e` drive arm B's register → bar close → fire path directly;
   `W6`–`W6c` prove every placebo level sits ≥ 3 radii from every real
   level and that the placebo run is deterministic. The end-to-end run
   is on **synthetic** 33-minute sessions, so it verifies that bars
   close, registrations resolve, baselines mature and the residual
   model reaches a fit — code behaviour only. Zero fires on synthetic
   tape is expected and is not evidence about anything. The first
   real-data run is user-side, on DEV sessions ≤ 20260918, and reads
   nothing from validation sessions: the blind is the pilot's.

10. **`mrofyt_recover.py` 1.1: a run still being written is not an
    orphan (2026-09-21).** The first `--dry-run` on the real capture
    folder found 16 runs without a manifest, 84 GB — and listed the two
    runs being recorded *at that moment* (today's NQ and MNQ, 8.76 and
    7.79 GB, `.partial`, ending mid-flush) under `WOULD_RECONSTRUCT_
    WITH_REPAIR`. They have no manifest because the recorder writes it
    at close, and they end mid-row because a flush was in progress.
    1.0 could not tell that from a crash. Had `--repair` been run, it
    would have pinned a manifest declaring the session complete at
    whatever byte the scan reached, the recorder's own manifest would
    later have contradicted it, and the runner would have ingested a
    truncated day as if it were whole — on a **validation** session.

    1.1 recognises a live run by either of two independent signs and
    refuses it under every flag, re-checking at write time so a direct
    `reconstruct()` call cannot bypass discovery: a stream written
    within `LIVE_MTIME_S = 600 s` (the recorder flushes every 30 s, so
    a live file is never minutes stale), or a session label that is the
    current CME session or later (a recorder alive but idle over a
    weekend goes mtime-stale while its run is still open). Both err
    toward refusing. Such runs are listed as `SKIPPED_LIVE_RUN`, counted
    apart from orphans, and excluded from the recoverable total. Pinned
    by `V8`–`V8d`; `V8c` proves the refusal is per run, so the dead
    orphan beside a live run is still recovered.

    The other fourteen runs on that folder are genuine: seven complete
    sessions (14th–17th, 3–7 GB each) that need only a manifest, and
    seven cut mid-write by the laptop's shutdowns (4th, 8th, 14th, 15th)
    that need `--repair`. Operator rule added to the tool's usage text:
    **run `--repair` only when the recorder is idle** — it rewrites
    every stream of a damaged run as a new file on the drive the
    recorder is writing to.

11. **Recover 1.2: ask Windows, because the indirect signs do not hold
    (2026-09-22).** The second real dry run showed 1.1's live runs were
    caught by the session-label rule alone: the modified-time rule
    never fired, because Windows does not keep a held file's modified
    time current (the operator had seen this in Explorer a week earlier
    — size growing, date not moving). Reading the recorder source then
    showed the label rule would not have held either on the day
    `--repair` is meant to run: the session roll is driven by market
    events (`Process()` rotates when an event's session differs), so
    the run open over a weekend keeps Friday's label; and the
    recorder's idle-loop housekeeping is unreachable (`WorkerLoop`'s
    `while (queue.Count == 0 && accepting) Monitor.Wait(...)` never
    falls through to the `ev == null` branch), so nothing — no flush,
    no heartbeat — is written while the market is closed. A run
    NinjaTrader still held on a Saturday would have passed every 1.1
    sign as dead, been given a reconstructed manifest, and been
    finalized again by the recorder on Sunday: two manifests, one run,
    that stretch of a **validation** session counted twice. 1.1 was not
    used for a repair; 1.2 replaces it before one.

    1.2 asks directly. The recorder opens every stream
    `FileMode.CreateNew, FileAccess.Write, FileShare.Read` and holds it
    for the life of the run (`V9f` pins this in the source), so a
    read-only `CreateFileW(GENERIC_READ, FILE_SHARE_READ)` fails with
    `ERROR_SHARING_VIOLATION` for exactly as long as the recorder holds
    the file. HELD refuses; any other failure refuses too ("a check
    that could not be asked is never read as not held"); FREE still
    yields to a newest row under ten minutes old by the recorder's own
    row clock (a run being closed has released its files but not yet
    written its manifest). Off Windows only the indirect signs exist,
    and they stay in force there. The Windows call itself cannot be
    exercised in this environment; `V9`–`V9d` pin every decision around
    it with an injected answer, and the operator's own dry run is its
    real test: today's runs must be listed as "NinjaTrader still has
    ... open for writing". The reconstructed manifest is now written
    aside and moved into place (`V9g`), so a drive that drops
    mid-repair leaves a `.tmp` every tool ignores.

    The recorder idle-loop finding is a recorder defect (no flush and
    no heartbeat during quiet periods; exposure is the last unflushed
    buffer per stream, a few KB, when the machine dies during a break).
    It is recorded here, not fixed: a recorder change is an F5 the
    operator schedules deliberately, and nothing about it is urgent.

    **The same day, a loose USB cable failed three passes at once.**
    Runner, pilot and wave two all died on `OSError 22` mid-read — and
    the wave-two pass, finding no manifests on the vanished drive,
    printed a clean, well-formatted report of zero fires on zero
    sessions. Read as a result that is "nothing fires". Now: a capture
    folder that cannot be read, holds no manifest for the instruments,
    or stops answering mid-pass raises `CaptureUnavailable` /
    `NoCaptureData`; runner, pilot, wave two and auditor print `STOPPED`
    with the reason, exit 2, and write **nothing** — the pilot's
    exposure ledger stays byte-identical (`P12`), because a pass that
    did not complete labels no session exposed. A read error on ONE run
    while the folder still answers is that run's `IO_ERROR` skip and the
    pass continues (`R15b`, `T34b`). Pinned by `R15`–`R15d`, `T34`–
    `T34c`, `P12`, `W8`.

    Two more closures in the same batch. The runner ingests a run
    **once** when both the recorder's manifest and a reconstructed one
    exist for it, preferring the recorder's and naming the other in the
    ledger (`R15d`) — the double-count above closed a second way. And
    the auditor reports a run still being recorded as `OPEN`, not as
    eight `ORPHAN_PARTIAL` failures plus an instance shortfall (the
    2026-09-21 audit carried ten such lines), using the recovery tool's
    own liveness rule so the two can never disagree (`T30c`); damaged
    originals kept beside their recovered copies are `KEPT`, not
    orphans, so the post-repair audit reads honestly.

    **Repair evidence, because the operator caught a confounder.** "Six
    spurious `BOOK_READY` on builds 1.2.0/1.2.1, zero on 1.2.2" was
    presented as proof the recorder repair works. It is not: old
    sessions *are* the old-build sessions, so build is confounded with
    the calendar. The repair acts only after a feed disconnect, and the
    auditor now counts that trigger per build and prints a verdict:
    `NOT_EXERCISED` (no repaired-build run has had a disconnect — the
    repair is untested, however clean the runs look),
    `EXERCISED_AND_HELD`, or `FAILED`. Runs whose rows could not be read
    are counted, never assumed clean. `T35b` is the end-to-end case on
    the real recorder code: the mono lifecycle harness's
    disconnect/reconnect run, built from `src/`, reads as exercised and
    held. Whether the operator's 1.2.2 sessions have had a disconnect
    is what the next real audit will say.

    A caveat made explicit while touching the skip paths: `CORRUPT_
    STREAM` and `IO_ERROR` reset the run's book and report the run
    skipped, but windows, fires and baseline observations produced
    *before* the failing row are not rolled back — they came from valid
    rows. `R13c` ("a partly read run leaves nothing behind") passes
    because its fixture cannot produce a window before the bad row, not
    because anything is undone. No real run has taken either path yet:
    the damaged files on the capture are caught by the pre-flight size
    check, before any row is read.

12. **God's Eye View: a read-only dashboard over the project
    (2026-09-22).** `analysis/godseye/` — registry, policy, bounded
    replay reader, exporter, local server, synthetic demo, 28 tests,
    Windows launchers, an optional Pinokio launcher and
    `GODS_EYE_README.md`. Built from a second directive, supplied as an
    upload and archived under `docs/prompts/` (hash below), after the
    operator said "stop" on the previous batch — that batch was committed
    as its own revertible commit (d650dac) before this one began.

    What it is: four views — recording health (LIVE / IDLE / STALE /
    DISCONNECTED / UNAVAILABLE / UNKNOWN, decided by the recovery tool's
    own liveness rule so the two can never disagree; an unreadable folder
    is UNAVAILABLE with its error, never zero; shared NQ+MNQ gaps shown
    beside the pair overlap because a 1.000 overlap cannot see them),
    hypothesis readiness (registry-driven statuses with reasons, counts
    quoted from the released reports, nothing ranked), data quality and
    provenance (DST-aware ET session timeline, UTC in the inspector,
    recorder / reconstructed / orphan / open / failed distinguished, gaps
    shown as gaps), and a replay of exposed sessions (session →
    instrument → approach → 10-s window → the frozen inputs, book rebuilt
    with the runner's own `KLevelBook`, a level never seen is `unknown`).

    How the blind holds, in the backend: the policy classifies every
    session EXPOSED (ledger label), BLIND (≥ 20260921 or the blind
    label), PROTECTED_UNLISTED (before the hold-out but not in the
    ledger) or UNKNOWN (missing/unreadable ledger, mixed or absent
    label), and fails closed; the exporter strips event-level fields from
    every record of a non-exposed session and then scans the whole
    document outside its `exposed` section, refusing to write on any hit;
    the server re-runs the policy on every replay request (403). December
    changes nothing by itself; the outcome-unlock file is only ever
    tested for existence. `G2`, `G2b`, `G3`, `G3b`, `G8`, `G8e`, `G10`.

    What it costs the recorder laptop: a separate process; `scandir`,
    manifests and the last 64 KB of open runs; no row scan on load; the
    demo export read 8.8 MB from 32 files in 0.43 s at 22.75 MB peak
    heap; the server sits at ~45 MB resident; a replay window is one
    bounded seek per stream, capped at 250,000 rows and saying so when
    capped (`G9`). It writes only into its own `out_dir`, refuses an
    `out_dir` inside the capture folder (`G4b`), and the capture folder's
    tree hash is identical after export, demo build and tests (`G3d`).

    Two additive flags on predecessors so nothing is recomputed:
    `mles_v12_audit.py --out` and `mrofyt_pilot.py --windows-out`
    (exposed sessions only). No detector, threshold, level, window,
    baseline or feature definition changed; `P10d` and `W7b` re-pin the
    frozen signal hash, and `G1b` shows the registry's written conditions
    reproduce every frozen detector on 20,000 random inputs.

    Discrepancies found by inspection and recorded, not changed (the
    README's §6 and the registry's `DISCREPANCIES`, pinned by `G1c`): A2
    and A6 are continuations, not fades; A5 resumes with the trend and
    has four of five inputs passed as `None`; A6 (09:30–09:45 ET, six
    open-type levels, continuation) is not W2-A4-OPEN (09:30–10:30 ET,
    three levels, reversal); z-scores need 5 prior sessions per bucket
    while the residual model needs 20 prior observations; the swing
    module exists but is not a level provider and has never run on real
    tape; the Asia labels have no code; the repository ledger exposes
    20260901–20260905 only, so a pre-hold-out date not in the ledger is
    protected here; the fourteen level ids match `ACTIVE_LEVEL_IDS`.

    Not verified here, said plainly: Pinokio (no Pinokio in this
    environment; scripts follow the documented API; `launch_godseye.bat`
    is the fallback), the `.bat` files and the Windows file-sharing
    liveness check (no Windows here — the health card names which rule
    decided liveness), and every number on real data (all verification
    is on the labelled synthetic demo). The browser render was verified
    with headless Chromium 141 on all four views.

13. **God's Eye 1.1: the Mechanism theatre, and where the study stands
    (2026-09-23).** The operator asked for a demonstration of how each
    hypothesis should work. Rather than prose, each of the fifteen
    registry entries now carries a scripted five-beat scenario
    (`godseye_registry.DEMOS`): a synthetic tape in ticks from the level,
    resting size at the level, executions, and the inputs the frozen rule
    reads appearing beat by beat; the condition checklist lights up as
    they arrive and the verdict quotes the direction rule. Each script has
    a counter-example that changes ONE thing and does not fire. None of
    it is data and every page says so. What makes it more than a story:
    `G11` runs the frozen detector itself (`mrofyt_signals.DETECTORS`,
    `mrofyt_wave2.w2_*`) on every script's final beat and asserts it fires
    in the named direction; `G11b` asserts every counter-example does not
    fire in the frozen code and fails exactly one resolved clause; `G11c`
    runs `arm_b1`/`arm_b2` on the candle arms' bars. The registry gained
    `resolve()`, which derives each wave-two family's conditions from its
    base with the registration's one change (input swapped, forced None,
    required, threshold, gate) — `G11d` shows it agrees with `mrofyt_wave2`
    on 6,000 random inputs for all six derived families — so the theatre,
    the inspector and the replay evidence are judged by one evaluator. A
    thought-experiment panel puts each input on a slider and re-evaluates
    the written conditions; it calls no frozen function and touches no
    data.

    On Recording health: a "where the study stands" rail — complete
    sessions (window passed, both instruments ≥ 95%, no shared gap over 5
    min, every manifest run audit-clean; `G12`) against the runbook's 20
    and 60 milestones, the registration's 2026-12-01 checkpoint with
    trading days left (`G12c`), NQ signal-source events per family against
    the 30-event minimum with a linear accrual projection that is a count
    and never a result, families in registry order; disk runway in
    session-days from the median finalized bytes per session-day (`G12d`);
    the next scheduled market change; alerts that call "not recording"
    critical only while the market is scheduled open and say by when
    recording must resume; an opt-in local browser notification when
    recording stops during market hours. Keyboard shortcuts throughout.
    No frozen file changed; the package suites stay 490/490; the dashboard
    suite is 36/36.

14. **Before the first real deployment: four things the real data would
    have hit (2026-09-23).** Found while writing the operator's steps
    against the capture's real numbers, not the demo's.

    *The replay file.* The first real pilot produced 44,628 windows from
    ~10 sessions; the pilot's `--windows-out` file is ~1.5 KB per window,
    so the September DEV sessions make ~100 MB. God's Eye 1.0 parsed the
    whole file on every export (284 MB peak each time, every 5 minutes if
    scheduled) and the server held all of it (183 MB) -- on the laptop
    that is recording. It is now split once per pilot run (or ledger
    change) into one piece per (session, instrument) of inspectable
    sessions, in `out_dir`; a routine export reads the ~1.5 MB index
    (0.06 s, 5.7 MB); the server holds at most four pieces (~30 MB).
    Measured on a synthetic 63,000-window, 100 MB file. `G13`-`G13b`.
    The server also re-reads the exposure ledger when it changes, so a
    weekly pilot run needs no restart (still fail-closed).

    *The repair's size.* `reconstruct()` copies every `.partial` stream
    in full as `_RECOVERED.csv` (the original is never renamed), not only
    damaged ones, and every orphan on the real folder is `.partial`: a
    `--repair` writes up to the orphans' full size (~67 GB at the last
    dry run) onto the drive the recorder resumes writing to on Sunday
    18:00 ET. Nothing checked the space. Recover 1.3 prints what
    `--repair` would write against the free space in every dry run,
    refuses a pass that would leave under 40 GB free (about three
    session-days) before writing anything, and re-checks per run.
    `V10`-`V10c`; the suite now states the drive each test simulates,
    because this sandbox itself has only ~30 GB free.

    *Complete sessions after the repair.* The auditor flags every
    reconstructed run `RECONSTRUCTED_RUN_NOT_SELF_VERIFYING` (correctly:
    such a manifest cannot verify its own file). The progress rail read
    any flag as "not complete", so after the repair the repaired DEV
    sessions would never have counted toward the 20/60 milestones even
    though the runner ingests them. A session whose only flag is that
    one now counts and is labelled "relying on N reconstructed
    manifest(s)"; any other flag still excludes it. `G12e`.

    *Memory the pilot does not need.* The pilot kept each window's level
    snapshot for blind sessions too, though `write_windows` never writes
    them; validation sessions grow every week to December. Now kept only
    for non-blind windows (`P13`); no detector, threshold, level, window
    or feature definition touched.

    Also: the Windows launcher could open the browser before the server
    listened ("site can't be reached"); the server now opens it once
    bound (`--open`, `G13c`). And the snapshot went stale 15 minutes
    after launch unless the operator set up Task Scheduler, which would
    have made the new watchdog report "stale while the market is open"
    all day; the server now re-runs the export every 5 minutes while it
    is open, as a separate below-normal-priority process, one at a time
    (`--refresh 300` in both launchers, `G13d`).

    *Addendum, the same day.* The operator's first real dry run with 1.3
    died with `OSError: [Errno 22] Invalid argument` reading the first
    line of one leftover file, while the recorder was demonstrably fine
    (the live `.partial` files were growing). Python reports many
    Windows disk errors as errno 22; the likely cause is a file cut off
    when the drive dropped on 2026-09-22. Recover 1.4 catches a read
    error on ONE file, names it with its Windows error code, sets that
    run aside as `SKIPPED_UNREADABLE_FILE` (never repaired, nothing
    written for it), and carries on; a vanished drive still stops the
    pass. The dashboard's own tail reader already survived this. `V11`.

    *Second look, the same day.* Reading the same failure again: a file
    cut off when a drive drops is often zero-filled, with no line break
    at all, and every reader here iterated lines -- `readline()` on such
    a file pulls the whole multi-GB file into memory before it can fail
    (on the recording laptop). Now every read is bounded: the header is
    read from the first 1 MB, rows come from a chunked reader that stops
    at any line over 1 MB and names the stretch, and the repair copy
    uses the same reader. `V12` asserts peak memory under 8 MB on a
    40 MB zero-filled file; `V12b` that a repair keeps every good row
    before such a stretch and writes no zero byte.

    *Replay evidence, found in a screenshot.* Two levels approached at
    the same instant share a window end time; the evidence endpoint
    matched on time only and returned the first, so the panel could
    explain a different level than the header named. It now matches the
    approach id too, and the page sends it. `G8f` (the demo has such
    twins).

    *Review pass, the same day.* Three things the dashboard did not yet
    say or show well. (1) The two files the 9/22 drive drop left
    unreadable are a drive fact the operator should see without running
    the recovery tool: the exporter now carries recover 1.4's
    `SKIPPED_UNREADABLE_FILE` verdict, with the file name and the
    Windows error, into the health section and the session timeline;
    the page raises a warn alert for it ("check the drive / cable") and
    the orphan table shows it; nothing touches the file (`G14`, the
    capture folder's tree hash is identical before and after). (2) A
    long history of overnight restarts produced one shared-gap alert
    per session and buried the ones that matter: the five largest are
    listed, then one line for the rest (`G14b`). (3) Replay level labels
    were drawn under the candles and a candle body could swallow them;
    they are now drawn last, on a dark box, still pushed apart when two
    levels sit within a text height of each other. Rendered in headless
    Chromium: no page errors, no console errors.

    *The next morning.* On the recorder laptop Windows kept raising
    "python3.13.exe - Corrupt File: ...5919a82d-R002_depth.csv.partial
    is corrupt and unreadable. Please run the Chkdsk utility": NTFS
    itself flags that file (the 9/22 drive drop), and every read of it
    raises the warning. The dashboard's refresher exports every 5
    minutes and the recovery module's readers touch the file several
    times per export. The exporter now remembers a file that failed to
    read in its own output folder (`godseye_unreadable.json`, keyed by
    size and modification time, which stat() gives without reading)
    and does not open it again until either changes -- e.g. after
    chkdsk; the verdict, the liveness check and the classification are
    the recovery tool's own code, unchanged. `G14c` counts opens: zero
    while remembered, a real read again after the file's time changes,
    and a readable file loses the mark. The recorder is unaffected by
    the warning; the file system on D: needs chkdsk (runbook).

15. **Runner: the truncated-stream guard covers every decode failure,
    and an abandoned run leaves nothing behind.** The 2026-09-19 handler
    caught `MalformedHeaderError` and `UnknownEnumError`, but the
    adapter's numeric and timestamp primitives raise a bare `ValueError`,
    so a same-byte-count row that kept all twenty columns and garbled a
    price, a sequence number or a timestamp still killed the pass. Row
    decoding now raises `CorruptStream` for any of them, and the skip
    names the file and how far the stream got. Separately, a run reported
    `events=0` was still leaving its prefix's windows, wall states,
    latency samples and open approaches in the ledger; the run is now
    wound back to a mark taken before its first event. Pinned by
    `R13f`-`R13j`.

    *Merged 2026-09-24.* The amendment above was written in a parallel
    session on 2026-09-19 and never reached this branch; it is merged
    here together with that session's ingest suite
    (`tests_mrofyt_ingest.py`) and run guide (`RUNNER_GUIDE.md`). Where
    the two lines of work met: this branch's `IO_ERROR` skip (a read
    error on one run while the folder answers) now winds the run back
    to the same mark as `CORRUPT_STREAM`, instead of only resetting the
    book (`R15e`: a late device error leaves no approach or latency
    sample of that run behind); `R15b`/`R15c` inject their device error
    at the runner's new row-reading boundary (`AD.iter_file`), since
    rows no longer pass through `AD.merge_run`; the ingest suite's `G6`
    ages its partial by an hour, because the auditor shares the
    recovery tool's liveness rule and a partial written seconds ago may
    still be recording. Runner version `MROF-YT-RUNNER-1.2.2`: ledgers
    written before this revision may still carry a skipped run's
    prefix.

16. **Recovery: a pass that stops says where and why, and never writes
    after a refusal.** The first real `--repair` on the operator's drive
    (1.4, 2026-09-26) printed nothing while it ran -- its summary comes
    at the end -- then stopped when Windows refused to create
    `...d5223c43-R001_depth_RECOVERED.csv` (errno 22) and the capture
    folder stopped listing. The only record of how far it got was the
    manifests on the drive, and its message ("the drive was disconnected
    or lost power") was a guess: Python reports several Windows disk
    errors as errno 22, including a damaged folder index on a drive that
    is still attached, and chkdsk had already found two damaged entries
    in that folder. `MROF-YT-RECOVER-1.5`:

    * a real pass prints each run as it starts (`[i/n]` session,
      contract, run, size), each phase (reading every row, writing the
      copies, checking what was written, fingerprinting and the
      manifest) and each outcome with its time (`V13`);
    * runs are taken oldest session first, then by name, so the
      development days the study needs next come before the sealed
      hold-out days; on the operator's folder that puts NQ 9/08
      (`b96e5fe5`) before the 13.9 GB 9/25 run (`V13`);
    * after a failed read or write the drive root and the folder are
      listed separately, at once, and the stop names which stopped
      answering: `DRIVE_GONE` (the root), `FOLDER_UNREADABLE` (the root
      answers, the folder does not), `WRITE_REFUSED` / `READ_REFUSED`
      (both answer) -- with each one's own Windows error and a next step
      that differs: reconnect and re-run, or do not write to the drive
      again until it has been checked (`V14`, `V14c`, `V14d`);
    * a refused write ends the pass. Where the drive still answers, the
      copies that run had started are removed, so the folder never holds
      a `_RECOVERED.csv` no manifest references (the auditor would call
      it `ORPHAN_FINALIZED_CSV`); from a vanished drive nothing can be
      removed and the next pass overwrites it. `FAILED_REPAIR` takes its
      copies back out the same way (`V14b`, `V14d`);
    * before anything is read in bulk, the folder must take a small
      check file (created, synced, read back, removed); a folder that
      refuses stops the pass with nothing read or written. The recorder
      needs the same thing each time it opens a run (`V15`, `V15b`);
    * a manifest an earlier pass wrote is checked, not trusted: one
      that does not parse, or whose files are missing or not the byte
      count it records (acknowledged writes a dropping drive lost), marks
      the run for redoing, with the reason; the dry run counts the runs
      whose manifests check out (`V13b`, `V16`, `V16b`);
    * a run the probe already found unreadable is not read a second
      time in the real pass -- every read of such a file can raise a
      Windows "Corrupt File" warning (`V16c`);
    * declared fields (declaredDepth, build, aggressor source) are
      borrowed only from a manifest the recorder wrote. A reconstructed
      one holds them second-hand or inferred, and a redone run would
      otherwise borrow from its own stale manifest; with no recorder
      sibling the value is inferred and labelled so (`V16d`). Nothing
      downstream reads the label; the auditor's minimum-row rule uses
      the same number either way.

    No original is ever opened for writing; the no-order proof, the
    outcome lock, the frozen detectors and every threshold are untouched.
    Runs rebuilt by 1.4 stay rebuilt: their manifests are re-checked,
    not rewritten. Battery: 584/584 + 46/46.

17. **Recovery 1.6: a file Windows will not even date is set aside, not
    a stop (2026-10-02).** The first 1.5 dry run of the weekend, with
    NinjaTrader closed, stopped before listing a single run:
    `READ_REFUSED` on `MLES12_MNQ_MNQ_DEC26_20261001_20260929211720256-
    7a01b30b-R003_depth.csv.partial`, Windows error 1392 ("The file or
    directory is corrupted and unreadable"), in the live-run check.
    Windows had answered that no process held the file, the tail read
    had failed quietly (`newest_recv` returns None on any read error),
    and then `os.path.getmtime` itself raised: the file's directory
    entry is damaged, not just its bytes. 1.4 set aside files whose
    bytes cannot be read, but only in the probe, which runs after the
    live check. 1.6:

    * in the live check, a stream whose modification time cannot be
      read marks its run `unreadable` with the file name and the Windows
      error, and the run is not live (Windows already said it is not
      held); `probe_run` returns it as `SKIPPED_UNREADABLE_FILE` before
      anything else is read, and the real pass never opens it (`V17`);
    * a live run's byte total no longer stats a file that cannot be
      dated.

    The auditor and the dashboard call the same check, so both now list
    the run (the auditor as `ORPHAN_PARTIAL`, the dashboard with the
    unreadable file) instead of stopping. The runner and the pilot read
    manifests only and never reached this file. No original is opened
    for writing; no detector, threshold, window, level, baseline or
    feature definition is touched. This is the second file-system error
    on this drive (the first two files on 2026-09-22), now on a run from
    the week of 2026-09-28, which is the case for copying the capture
    off the drive before any further long pass. Battery: 585/585 + 46/46.

18. **Wave three: a registered search for order-flow events that precede
    25-point moves (2026-10-03).** The operator, reading the pilot's
    A4 markouts (a +2-point typical move with a −3-point average, no
    interval excluding zero), asked for recurring order-flow events
    that produce 25+ point moves, "built the right way". The right way
    is the one this package already uses: write down what will be
    looked for, how it is scored and how many things are tried, before
    looking. `MROF_YT_WAVE3_BIGMOVE_REGISTRATION.md` was committed
    (85084ff5…) before `mrofyt_bigmove.py` existed, and the tool has not
    been run on a recorded session here (none exists in this
    environment).

    * eight patterns on the frozen runner's own grid ticks and approach
      windows, with the frozen fields unchanged: flow shock with and
      against the response, a two-tick control run, a held open break,
      a sweep-and-reclaim of a range level, a VWAP band snapback, a
      failed retest of a held break, and a 10:30 ET trend read;
    * one path score, fixed: target 100 ticks, stops 40/60/80 ticks,
      1800 s limit, a tie is a stop, mid-to-mid inside one recording
      run, no fill, spread, slippage or commission. This is the first
      wave in the package that reads a path outcome; it does so on DEV
      sessions (`<= 20260918`) only, in its own module, and feeds
      nothing back into a wave-one or wave-two threshold. The wave-one
      ledger it emits is byte-identical to the pilot's (`B9`) and the
      frozen signal module keeps its pinned hash (`B10`);
    * an hour-matched baseline (every grid tick, both directions, cells
      by instrument and ET hour), because the patterns cluster in cash
      hours where 25-point moves are routine; the lift is observed minus
      the events' own cells, with a seeded bootstrap interval and p;
    * the wave-two placebo arm for the level patterns, same seed rule
      (`B6`);
    * 24 tests under Holm, fixed in the registration; fewer than 30
      resolved NQ events is NOT TESTED;
    * the gate: every session after 20260918 is refused and listed;
      `--unblind` is the checkpoint read, announces itself, and writes
      every session read to the exposure ledger as exposed by this
      wave, monotone (`B5`, `B7`, `B7b`);
    * a census of grid-feature deciles against the share of ticks that
      reach ±100 ticks inside 1800 s, labelled diagnostic, producing no
      verdict; a rule read off it is a wave-four registration.

    Battery: 612/612 + 46/46.

19. **A folder listing Windows cannot finish is a stop, never "no
    manifest" (2026-10-03).** With 71 manifests visible to `dir`, the
    wave-two pass stopped twice with "no MLES-CAPTURE-1.2 manifest ...
    the wrong folder, or a drive that came back under another letter".
    `glob.glob` swallows an OSError raised partway through a directory
    scan and returns what it had; on a drive whose folder index carries
    two damaged entries (error 1392, Amendment 17) that is nothing, and
    nothing reads exactly like the wrong folder. `discover_manifests`
    now enumerates with `os.listdir`, which raises, and turns the error
    into `CaptureUnavailable` naming the Windows code (`T36`); every
    tool that discovers manifests (audit, runner, pilot, waves two and
    three, the dashboard's exporter through the runner) inherits it.
    The runner's "no plan" stop now counts the manifest files it saw
    and says why none gave a plan (`R16`, `R16b`). No rule, threshold
    or detector changed. Battery: 615/615 + 46/46.

20. **Wave four: a counted search of the DEV tape for what precedes
    25-point moves, and two corrections found by building it
    (2026-10-09).** The operator asked again for the search they had
    proposed on 2026-10-03 — look in the recorded order flow for
    something recurring with positive expectancy, and make that the
    hypothesis — which had been agreed and then not built.
    `MROF_YT_WAVE4_DISCOVERY_REGISTRATION.md` was committed (9d35c018…)
    before `mrofyt_discover.py` existed: fourteen causal features on the
    frozen 10 s grid, a fixed grammar of 736 rules (singles at decile
    tails, pairs at quintile tails, direction part of the rule), each
    scored at wave three's three stops — 2 208 tests, a number fixed
    before the data is seen — with session-clustered t-tests,
    Benjamini–Hochberg over all 2 208, replication in both
    chronological halves of DEV, and at most five nominated rules
    frozen with numeric cut-points and judged once on the validation
    sessions (`--evaluate --unblind`, Holm over the set). One read of
    DEV yields this report and wave three's (`F10`). It has not been
    run on a recorded session here (none exists in this environment).

    * **Direction-matched baseline (pre-run correction, waves three
      and four).** The planted-effect test — a long-only edge on one
      feature, noise elsewhere — showed that a baseline cell pooling
      both directions gives every long rule a positive lift whatever
      its feature: 27 unrelated rules passed. On real tape the same
      happens whenever the sample drifted one way. Cells are now
      (instrument, ET hour, direction) in both waves; the unrelated
      candidates fall to 2, inside a 10 % false-discovery rate, and pure
      noise yields none (`F6`, `F6b`, `B5e`). Both registrations record
      the correction; neither tool had read a recorded session.
    * **The runner's quote fields.** `st.bid, st.ask, st.bsz, st.asz =
      b, bs, a, asz` put the bid SIZE in `st.ask` and the ask PRICE in
      `st.bsz`. Nothing read either field — order-flow imbalance and the
      mid use their own correctly labelled values — so no result of any
      wave changed (the wave-one ledger is byte-identical, `B9`, `F13`).
      Wave four's spread feature read them and printed spreads of
      −60 000 ticks on synthetic tape. Assigned in order now (`R17`);
      the spread reads the quote order-flow imbalance is built from.

    Battery: 632/632 + 46/46.

21. **An abandoned run is wound back whole in waves two, three and
    four (2026-10-10).** The first real wave-two report (2026-10-10,
    27 sessions) showed W2-A4r with 1 736 raw fires against the pilot's
    1 734 A4 fires, where the two must be identical (`W1`). The two
    extra fires, and 51 more across the wave-two families (on NQ: 9
    ARM-B1 and 3 ARM-B2 raw fires; the rest MNQ), came from the two
    20260917 runs the runner skips as corrupt. The runner winds an
    abandoned run back (Amendment 15) and the pilot winds back its own
    buffers, but `Wave2Runner` kept its own fires, counters and
    per-instrument state (top-3 adds and executions, high-confidence
    trades, the residual model's history, the bar cache) outside both.
    Wave three wound back its fires and grid records but not its
    pattern state or counters; wave four not its feature history.
    Each now snapshots and restores its own state with the run (`W9`,
    `B12`, `F14`, each against a pass that never saw the run, and the
    first two with a control showing the old wind-back leaked). Wave
    two is 1.1. The 2026-10-10 wave-two report is superseded: its NQ
    W2-A4r numbers match the pilot exactly, but ARM-B's NQ counts carry
    the leaked fires, so it is re-run with 1.1 rather than corrected by
    hand. No detector, threshold or definition changed.
    Battery: 635/635 + 46/46.

22. **A refused size check is a skip or a stop, never a crash
    (2026-10-20).** The first wave-four search on the operator's drive
    died with `TypeError: Runner._skip_io_error() missing 1 required
    positional argument: 'mark'`, raised while handling
    `WinError 433: A device which does not exist was specified` from
    the runner's size pre-flight (`os.path.getsize` on a 20260914 MNQ
    stream). The drive had dropped. The pre-flight's error path called
    `_skip_io_error` without the wind-back mark that the 9/19 merge
    added to it, so instead of skipping that run (folder still
    answering) or stopping with STOPPED (folder gone), every tool on the
    runner — pilot, waves two to four — would crash there. Nothing has
    been read at the pre-flight, so the call passes no mark and
    `_skip_io_error` winds back only when it has one (`R18`, `R18b`;
    under the old code `R18` raises). No result changed: the path had
    never been reached by a completed run. Battery: 637/637 + 46/46
    (`tests_mles_v12.py` needs the Mono C# compiler `mcs`, which this
    container lacked until installed).

23. **One study across two drives (2026-10-23).** The capture drive is
    full (1 TB) and the operator bought a second 1 TB drive, which
    cannot hold a copy of the first and still record. Recording moves
    to the new drive; the old one is kept as the archive of every
    session to date. The study has to be read as ONE capture in session
    order: robust baselines look back 20 sessions per minute bucket,
    yesterday's and last week's levels come from earlier sessions, and
    wave two's residual model carries history, so two separate passes
    would start the second drive's sessions with no history and differ
    from a continuous pass. Every tool that takes a capture folder now
    accepts two separated by a semicolon,
    `"D:\\MLES_Capture;E:\\MLES_Capture"`: the auditor and the runner
    discover manifests in each and read them as one plan; a run present
    in both (a backup copy) is read once, from the first folder named,
    and reported; one folder gone is the capture gone (STOPPED). Each
    run's streams were already resolved beside its own manifest, so no
    reading code changed. The pilot, wave two and the wave-four search
    on two folders give results identical to one folder holding every
    run (checked here on synthetic tape; `T37`, `R19`). The recovery
    tool and the dashboard stay one folder at a time: repair is run per
    drive, and the dashboard watches the drive being recorded to.
    Battery: 639/639 + 46/46.

24. **Waves three and four on DEV, frozen (2026-10-24).** The
    operator's first complete wave-four search (one read of the 15 DEV
    sessions, which also wrote wave three's real-level report) is
    committed byte for byte under `frozen_dev_20261024/` with
    `MROF_YT_W3_W4_DEV_FREEZE.md`, before any validation session is
    read. Both reports list the 23 sessions 20260921 → 20261023 as
    refused, and no event in them is later than 20260918. Wave four: 0
    CANDIDATEs of 2 208 tests (best q 0.377), five LEAD nominees. That
    commit is the hypothesis set §5 requires. Wave three: Holm over 24
    rejected only L2 SWEEP_RECLAIM at the 60-tick stop (116 NQ events,
    lift +0.155, p 0.001, +5.00 points before costs), which is carried to
    the checkpoint at that stop. L1 fired on no session. A descriptive
    per-session and one-position-at-a-time read of L2's DEV events is
    recorded there as not a test: positive on all six sessions it fired
    on, 55 of 116 events on 20260916 (FOMC). No code changed; the
    package zip was unchanged then (98bc03c1…); it ships them from V26.

25. **What an intraday trader needs that the study lacked (2026-10-26).**
    The operator asked for everything a consistently profitable
    intraday order-flow trader needs that this study did not have. Four
    tools were added; nothing frozen changed (the signal module keeps
    06ce854a…; every earlier suite passes unchanged).
    - **Context** (`mrofyt_context.py`, registration
      `MROF_YT_CONTEXT_REGISTRATION.md`): long, short or neither by
      10:30 ET, from NinjaTrader one-minute exports, which reach back to
      about 2006 where the order-flow recordings reach weeks. A search
      for the registration found that this repository's earlier
      minute-bar studies already read NQ bars from 2019-06-02 to
      2026-08-25 (NQ-DIRECTION-V1 among them, which found no robust
      intraday directional mechanism), and nothing earlier. So the
      search runs on 2019-06-01 .. 2026-06-30 and the verdict comes from
      every session before 2019-06-01; each mode drops the other's bars
      the moment their session is known (`X9`, `X11`). Exports are UTC,
      end of bar; a stamp check refuses any file whose cash-open volume
      jump is not at 09:30 ET and names the fix (`X7`).
    - **Exits** (`mrofyt_exitstudy.py`, wave five, registration
      `MROF_YT_WAVE5_EXIT_REGISTRATION.md`): when price has run 20
      points and momentum looks to be dying, is holding worth less than
      usual? Eight tape signs against a plain 10-point trailing stop on
      every 20-point run of the DEV tape, plus how long each wave-one
      and wave-three signal's edge lasts (5 s to 3 h). The operator's
      own read was asked for and not supplied; the standard inventory
      was fixed instead.
    - **Costs** (`mrofyt_costs.py`): on the frozen DEV report, L2 at 60
      ticks keeps +6.15 points a trade on NQ one position at a time after
      $5 commission, a tick of spread and a tick of stop slippage, and
      +0.15 on MNQ, where commission is four times larger per point.
    - **Risk** (`mrofyt_risk.py`): resampling whole recorded sessions
      cannot show a losing streak longer than the sample's own days held
      (6 trading days for L2), and gave a flattering picture; trades are
      therefore drawn one by one, in three scenarios (as sampled, half
      the edge, no edge), and contracts are sized on the half-edge one.
    Battery: 693/693 + 46/46 (`tests_mles_v12.py` needs the Mono C#
    compiler `mcs`).

26. **Fade the failed break or follow the held one (2026-10-26).** The
    operator asked whether to add "break and reclaim" (that is L2
    itself) and how to set stops, including tight ones placed by the
    order flow. On L2's September DEV trades, half of the eventual
    winners first went 4 points or more against the entry (winners that
    never went 2 / 4 / 10 / 15 points against: 32 / 49 / 69 / 97 %), so
    a stop of a few points meets NQ's own noise; a stop placed by the
    tape is another matter, and is now registered rather than chosen.
    `MROF_YT_WAVE6_LEVELBREAK_REGISTRATION.md` fixes, before either tool
    read real data: part A (`mrofyt_levelbreak.py`) on the recordings --
    L2 with a fixed, a STRUCTURAL (beyond the sweep extreme) and a
    FLOW-INVALIDATION exit, L4 (break and retest), and L2 filtered by
    TRAPPED volume, net of costs, Holm over five, judged on a replay
    holdout folder (sessions before 2026-09-01 only) or at the
    checkpoint; part B (`mrofyt_smt.py`) on NQ and ES minute bars -- ES
    confirming or denying the break, four tests, judged on the years
    before 2019-06-01. Synthetic tape never flips its flow, so the frozen
    L2 detector never fires on it; the suite swaps in a plumbing
    detector inside the suite only and restores it. Nothing frozen
    changed (06ce854a…). Battery: 710/710 + 46/46.

27. **Review of V26–V27 before any real export is read (2026-10-26).**
    A second reading of the six new modules against their registrations
    found no leak and no registration mismatch, and one robustness gap:
    the context stamp check ranked every minute by its volume jump over
    the minute before, so on real NQ tape a thin minute with a sharp
    jump (08:30 on a news day, the Globex reopen) could outrank 09:30 and
    the tool would refuse a correctly stamped file. It now ranks only
    minutes carrying at least half the day's peak average volume
    (`X6a`); the hints for Eastern-stamped and start-stamped files are
    unchanged. Also: files are read BOM-tolerant, mrofyt_smt reads
    through mrofyt_context's one parsing loop instead of a copy, and a
    Tick export (lines that are not minute bars) stops with that reason.
    No threshold, feature, split or test changed. Battery: 711/711 +
    46/46.

28. **Order-flow levels, graded, with targets from the order flow
    (2026-10-30).** L2's September DEV result (+351 points net, 57
    trades, one position at a time) owes 260 points to one day, the
    16 September Fed day: the six daily levels it watches are reached
    on few days. The operator proposed trading the levels the order
    flow builds every day (swing highs and lows), grading each setup
    A+ / A / B / skip from the order flow at the level, and taking the
    target from the order flow too ("could be 10R, not the same every
    time"), and asked that both target ideas be registered.
    `MROF_YT_WAVE7_FLOWLEVELS_REGISTRATION.md` fixes, before the tool
    read real data: three level types (one-minute swing highs and lows,
    absorption prices, yesterday's POC / VAH / VAL), one attempt per
    level, FAILED (fade) and HELD (follow) entries 09:30-15:30 ET, five
    grade points (trapped volume, absorption at the level, a strong
    turn, a fresh level, confluence with a daily level), a structural
    stop of 12-60 ticks, and four exits judged side by side: E1 the next
    level ahead (at least 1.5 x the stop, no cap; a nearer level means no
    trade), E2 no target and an exit when 2 of 4 tape signs say the move
    is dying, E3 half and half, E4 the original 25 / 15 as the baseline.
    Nine tests (FAILED and HELD at grade A or A+ on each exit, and
    whether net R rises with the grade), Holm over nine. DEV describes
    and freezes two cuts; the replay holdout folder or the December
    checkpoint judges. Wave six and wave seven are both registered
    before anyone has read the replay folder, so each reads it once as a
    fresh test. `mrofyt_flowlevels.py` uses wave four's runner, hooks
    only (`FL10`: wave four's grid, wave three's fires and the wave-one
    ledger identical); nothing frozen changed (06ce854a…). Battery:
    731/731 + 46/46.

29. **Waves five to seven run on DEV; their cuts frozen (2026-10-31).**
    The operator ran `mrofyt_levelbreak.py`, `mrofyt_flowlevels.py` and
    `mrofyt_exitstudy.py` on the old drive: 15 DEV sessions read, 23
    later sessions refused unread. `w6_frozen.json` and
    `w7_frozen.json` are committed under `frozen_dev_20261031/` before
    any held-out read, and `MROF_YT_W6_W7_DEV_FREEZE.md` records the
    descriptive DEV results. Wave six's trapped cut is 0 on both
    instruments (the median L2 event traded nothing beyond its level),
    so T5 equals T1 as registered; it stays frozen. Wave seven shows no
    edge after costs on DEV and its grade does not order results. Wave
    five nominated no sign. No code, threshold or test changed.

30. **L2 on the first test, in the morning, both, or held five minutes
    (2026-10-31).** The operator asked whether the first test of a level
    and the 09:30-11:30 window were treated differently. They were not:
    L2 traded every approach at every hour. On the saved DEV report the
    first L2 signal at a level made +12.79 points a trade net (12 trades,
    67 %) against +4.38 for later ones, and the morning +7.25 (14) against
    +4.39 for the afternoon; wave five's half-life showed L2's move in its
    favour to 5 minutes and against it from 10. These are DEV numbers,
    seen, so `MROF_YT_WAVE8_L2VARIANTS_REGISTRATION.md` fixes four
    variants before any held-out session is read by any tool: V1 the
    first approach to the level that CME session (every approach counted,
    signal or not), V2 09:30-11:30 ET, V3 both (the operator's pick), V4
    out at the mid after 5 minutes; wave six's T1 is reported beside as
    the reference. Holm over four; nothing is frozen from DEV.
    `mrofyt_l2variants.py` numbers approaches through the hook where the
    runner opens one (`_select_wall`, called once per approach), on wave
    six's runner (`LV5`: wave six's fires, grid and the wave-one ledger
    identical). Nothing frozen changed (06ce854a…). Battery: 738/738 +
    46/46.

