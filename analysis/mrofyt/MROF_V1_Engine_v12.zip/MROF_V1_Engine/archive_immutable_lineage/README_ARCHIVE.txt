IMMUTABLE ARCHIVE LINEAGE - DO NOT INSTALL THESE FILES.
MlesV1CaptureHost.cs  (MLES-CAPTURE-1.0.0) and
MlesV11CaptureHost.cs (MLES-CAPTURE-1.1) are kept for hash-pinned
lineage only. The 1.1 recorder stops writing after the first 18:00 ET
session rollover (its Roll() killed the writer thread). The recorder
to install is 1_NinjaTrader_Recorder/MlesV12CaptureHost.cs.
