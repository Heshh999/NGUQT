MROF ENGINE PACKAGE - AUTHORITATIVE RECORDER: MLES-CAPTURE-1.2
==============================================================
THIS PACKAGE SUBMITS NO ORDERS AND DOES NOT AUTHORIZE LIVE TRADING.

INSTALL EXACTLY ONE RECORDER: MlesV12CaptureHost
------------------------------------------------
1_NinjaTrader_Recorder\MlesV12CaptureHost.cs is the file to install
(steps: 1_NinjaTrader_Recorder\SETUP_WALKTHROUGH_V12.md). It survives
the 18:00 ET session rollover and contract rolls: one permanent
capture worker keeps recording across sessions, mints a new run per
session/contract, finalizes files atomically and writes a complete
hashed manifest per run.

The files under archive_immutable_lineage\ (MlesV1CaptureHost.cs,
MlesV11CaptureHost.cs) are immutable lineage for verification only.
Do not install them; the 1.1 recorder stops writing after its first
session rollover.

WHAT TO RUN
-----------
- NinjaTrader (user side): install v1.2, attach to NQ and MNQ front
  contracts (both REQUIRED; ES optional), leave running.
- Any computer with Python 3:
    python3 2_Analysis_Engine/tests_mrof.py            # engine 42/42
    audit a capture folder:
    python3 -c "import sys; sys.path.insert(0,'2_Analysis_Engine'); \
import mles_v12_audit as AU; r=AU.audit_capture('<folder>'); \
print(r['ok'], r['failures'])"

STILL USER-SIDE (never run by Claude): real NT8 F5 compile; 5-minute
NQ+MNQ Market Replay smoke test; stop/finalize/audit; restart/
finalize/audit; first genuine 18:00 ET rollover audit.

Research classification stays: INSUFFICIENT_DATA - ZERO GENUINE
RECORDED SESSIONS. Passing software tests proves recorder behavior
only; it does not prove positive expected value.
