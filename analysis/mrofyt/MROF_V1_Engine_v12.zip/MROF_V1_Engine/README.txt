MROF ENGINE PACKAGE - AUTHORITATIVE RECORDER: MLES-CAPTURE-1.2 (build 1.2.1)
============================================================================
THIS PACKAGE SUBMITS NO ORDERS AND DOES NOT AUTHORIZE LIVE TRADING.

START HERE: OPERATING_RUNBOOK.md (install -> smoke capture -> passive
capture -> 20-session verification -> 60-session State-C).

INSTALL EXACTLY ONE RECORDER: MlesV12CaptureHost
------------------------------------------------
1_NinjaTrader_Recorder\MlesV12CaptureHost.cs is the file to install
(steps: 1_NinjaTrader_Recorder\SETUP_WALKTHROUGH_V12.md). It survives
the 18:00 ET session rollover and contract rolls: one permanent
capture worker keeps recording across sessions, mints a new run per
session/contract, finalizes files atomically and writes a complete
hashed manifest per run. Build 1.2.1 adds run-lifetime depth-level
fields to the manifest (row schema unchanged); sessions captured by
1.2.0 remain valid.

The files under archive_immutable_lineage\ (MlesV1CaptureHost.cs,
MlesV11CaptureHost.cs) are immutable lineage for verification only.
Do not install them; the 1.1 recorder stops writing after its first
session rollover.

WHAT TO RUN (any computer with Python 3; standard library only)
---------------------------------------------------------------
    python3 2_Analysis_Engine/mles_v12_audit.py "<capture folder>"
        streaming integrity audit (flat memory on 5 GB files),
        NQ/MNQ pairing over the union of runs, latency summary
    python3 2_Analysis_Engine/mrofyt_runner.py "<capture folder>" --out ledger.json
        OUTCOME-BLIND pipeline-verification runner: book/tape/bars,
        frozen levels, 20-session baselines, frozen A1-A6 detectors on
        completed 10 s windows; prints a compact ledger. Computes no
        fill/stop/target/R/P&L; --outcomes raises STATE-C LOCKED.
    python3 2_Analysis_Engine/tests_mrof.py            # engine 42/42
    python3 2_Analysis_Engine/tests_mrofyt_runner.py   # runner suite

Never send raw CSVs: manifests (KB) and the runner summary/ledger (KB)
are what move. The data stays on your machine.

STILL USER-SIDE (never run by Claude): real NT8 F5 compile of any new
build; Market Replay smoke tests; stop/restart audits on your machine.

Research classification stays: INSUFFICIENT_DATA - ZERO GENUINE
RECORDED SESSIONS. Passing software tests proves recorder behavior
only; it does not prove positive expected value.
